// Only a browser publishable key belongs here. Never add a secret/service-role key.
export const cloudConfig={url:'https://nxpvxsyiyigedmplsdnz.supabase.co',publishableKey:'sb_publishable_ETTOH2pYuKjDek4rcOFDKw_ZQFoyeiV'};

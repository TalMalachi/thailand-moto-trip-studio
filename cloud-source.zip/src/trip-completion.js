const actionable=new Set(['booking','task','gear']);
const owned=new Set(['קיים','יש','מוכן','נרכש','הושלם','ready','owned']);
const percentage=(n,total)=>total?Math.round(n/total*1000)/10:null;
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function preparationComplete(item){const p=item.payload||{};return item.kind==='booking'?['הוזמן','שולם'].includes(p.status?.trim()):item.kind==='task'?p.done===true||p.workflowStatus==='completed':item.kind==='gear'?owned.has(p.status?.trim()):false;}
export function tripCompletion(items,settings={}){
 const seen=new Set(),categories=new Map();let total=0,completed=0;
 for(const [index,item] of (items||[]).entries()){
  if(!actionable.has(item.kind))continue;const key=item.kind+':'+(item.id||item.legacy_id||index);if(seen.has(key))continue;seen.add(key);
  const p=item.payload||{},category=(item.kind==='booking'?p.type:p.category)?.trim()||(item.kind==='gear'?'ציוד':'כללי');
  if(!categories.has(category))categories.set(category,{category,total:0,completed:0,awaitingApproval:0});const c=categories.get(category);total++;c.total++;
  if(preparationComplete(item)){completed++;c.completed++;}if(p.workflowStatus==='awaiting_approval')c.awaitingApproval++;
 }
 const days=Number(settings.days)||0,covered=new Set((items||[]).filter(x=>x.kind==='stop'&&Number.isInteger(x.payload?.day)&&x.payload.day>=1&&x.payload.day<=days&&x.payload.place?.trim()).map(x=>x.payload.day)).size;
 return {total,completed,percent:percentage(completed,total),categories:[...categories.values()].map(c=>({...c,percent:percentage(c.completed,c.total)})).sort((a,b)=>a.category.localeCompare(b.category,'he')),route:{days,covered,percent:percentage(covered,days)}};
}
export function completionMarkup(items,settings={}){
 const s=tripCompletion(items,settings),value=s.percent===null?'טרם הוגדר':s.percent+'%';
 return '<section class="trip-completion" aria-label="ביצוע ההכנות לטיול"><div class="row"><h2>מצב ההכנות לטיול</h2><strong class="metric">'+value+'</strong></div><p>'+s.completed+' מתוך '+s.total+' פריטי הכנה הושלמו</p><progress max="100" value="'+(s.percent||0)+'" aria-label="אחוז ביצוע כללי"></progress><p class="muted">הזמנות נספרות כהושלמו רק כשסומנו ״הוזמן״ או ״שולם״. אישור הצעה אינו הזמנה. משימות וציוד נספרים לפי סימון הביצוע שלהם; כל רשומה נספרת פעם אחת.</p><div class="completion-categories">'+s.categories.map(c=>'<article><div class="row"><strong>'+escape(c.category)+'</strong><span>'+c.percent+'%</span></div><progress max="100" value="'+c.percent+'" aria-label="ביצוע '+escape(c.category)+'"></progress><small>'+c.completed+' מתוך '+c.total+' הושלמו'+(c.awaitingApproval?' · '+c.awaitingApproval+' ממתינים לאישור':'')+'</small></article>').join('')+'</div><p class="muted">כיסוי מסלול: '+s.route.covered+' מתוך '+s.route.days+' ימים מתוכננים. מידע על מקומות ועצירות אינו נספר כהזמנה שבוצעה.</p></section>';
}

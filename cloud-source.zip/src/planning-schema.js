// Wire contract enforced by the provider, then checked again by validatePlan.
const string={type:'string'};
const number={type:'number'};
const list=items=>({type:'array',items});
const object=properties=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const fields=names=>Object.fromEntries(names.map(name=>[name,string]));
const variant=(kind,payload)=>object({kind:{type:'string',enum:[kind]},payload:object(payload)});
export const planningResponseSchema=object({
 start:string,days:{type:'integer'},summary:string,estimatedTotal:number,warnings:list(string),
 records:list({anyOf:[
  variant('stop',{day:{type:'integer'},...fields(['place','kind','url','notes'])}),
  variant('booking',{...fields(['name','type','supplier','url','notes']),status:{type:'string',enum:['לבדיקה']},cost:number,paid:{type:'number',enum:[0]}}),
  variant('task',{...fields(['title','category']),done:{type:'boolean',enum:[false]}}),
  variant('place',fields(['name','type','area','url','notes'])),
  variant('gear',fields(['name','category','status','url','guide','notes']))
 ]}),
 sources:list(object({...fields(['url','title','excerpt']),priceType:{type:'string',enum:['indicative','estimate']}})),
 dateAlternatives:list(object({start:string,baseline:number,total:number,comparable:{type:'boolean',enum:[true]},reason:string,sourceUrls:list(string)}))
});

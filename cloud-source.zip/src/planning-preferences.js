export const preferenceGroups=[
 {key:'pace',label:'קצב הטיול',options:[['relaxed','קצב רגוע'],['balanced','קצב מאוזן'],['full','ימים מלאים ופעילים']]},
 {key:'lodging',label:'סגנון לינה',options:[['comfortable','מלונות נוחים ברמה טובה'],['boutique','מלונות בוטיק'],['luxury','מלונות מפנקים ברמה גבוהה'],['simple','לינה פשוטה ונקייה']]},
 {key:'driving',label:'משך נסיעה יומי מועדף',options:[['short','עד 3 שעות נסיעה ביום'],['medium','3–5 שעות נסיעה ביום'],['long','עד 6 שעות נסיעה ביום']]},
 {key:'interests',label:'מה מעניין אותך?',multiple:true,options:[['nature','טבע ונופים'],['viewpoints','תצפיות וצילום'],['local_food','אוכל מקומי ובתי קפה'],['culture','תרבות ומקדשים'],['beach','חופים ומנוחה'],['markets','שווקים וקניות']]},
 {key:'roads',label:'העדפות מסלול',multiple:true,options:[['scenic','כבישים נופיים'],['winding','כבישים מפותלים'],['paved','כבישים סלולים בלבד'],['avoid_highways','להימנע מכבישים מהירים']]},
 {key:'constraints',label:'אילוצים ודרישות',multiple:true,options:[['no_night','ללא רכיבה בלילה'],['frequent_rest','עצירות מנוחה תכופות'],['short_walks','ללא הליכות ארוכות'],['secure_parking','חניה מאובטחת לאופנוע'],['rest_days','לשלב ימי מנוחה ללא נסיעות']]}
];
export function readPreferences(data){
 const choices={};
 for(const group of preferenceGroups){const allowed=new Set(group.options.map(([id])=>id));choices[group.key]=group.multiple?data.getAll('preference_'+group.key).filter(id=>allowed.has(id)):allowed.has(data.get('preference_'+group.key))?data.get('preference_'+group.key):'';}
 const freeText=String(data.get('preferences')||'');
 const lines=preferenceGroups.flatMap(group=>{const picked=new Set(group.multiple?choices[group.key]:[choices[group.key]]);const labels=group.options.filter(([id])=>picked.has(id)).map(([,label])=>label);return labels.length?[group.label+': '+labels.join(', ')]:[];});
 if(freeText.trim())lines.push('העדפות נוספות בטקסט חופשי: '+freeText.trim());
 const preferences=lines.join('\n');if(preferences.length>2000)throw Error('הבחירות והטקסט החופשי יחד מוגבלים ל־2,000 תווים. יש לקצר את הטקסט.');
 return {choices,freeText,preferences};
}
export function renderPreferences(choices,freeText,escape){
 const selects=preferenceGroups.filter(g=>!g.multiple).map(g=>'<label>'+g.label+'<select name="preference_'+g.key+'"><option value="">ללא העדפה</option>'+g.options.map(([id,label])=>'<option value="'+id+'" '+(choices[g.key]===id?'selected':'')+'>'+label+'</option>').join('')+'</select></label>').join('');
 const checks=preferenceGroups.filter(g=>g.multiple).map(g=>'<fieldset class="preference-options"><legend>'+g.label+'</legend><div class="preference-choice-grid">'+g.options.map(([id,label])=>'<label class="preference-choice"><input type="checkbox" name="preference_'+g.key+'" value="'+id+'" '+((choices[g.key]||[]).includes(id)?'checked':'')+'><span>'+label+'</span></label>').join('')+'</div></fieldset>').join('');
 return '<fieldset class="planner-preferences"><legend>העדפות ואילוצים</legend><p class="muted">אפשר לבחור כמה אפשרויות בתחומי העניין, במסלול ובאילוצים. כל הבחירות אופציונליות.</p><div class="planner-grid">'+selects+'</div>'+checks+'<label>העדפות נוספות — טקסט חופשי (אופציונלי)<textarea name="preferences" maxlength="2000" placeholder="בקשות נוספות שלא מופיעות באפשרויות הבחירה">'+escape(freeText)+'</textarea></label><p class="muted">הבחירות והטקסט יוצגו יחד בסיכום לפני אישור ההרצה. אין להזין סיסמאות, פרטי תשלום או מסמכים אישיים.</p></fieldset>';
}

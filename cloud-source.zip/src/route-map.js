import L from 'leaflet';
import {popupDimensions} from './map-popup-layout.js';
import 'leaflet/dist/leaflet.css';
import './route-map.css';
import {routePoints,groupRoutePoints,navigationLinks,dailyDestination} from './route-points.js';
function element(tag,text,className){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node}
function navigation(point){const row=element('div',undefined,'row map-navigation');const urls=navigationLinks(point);for(const [provider,label] of [['google','Google Maps'],['waze','Waze']]){const a=element('a','ניווט ב־'+label,'btn');a.href=urls[provider];a.target='_blank';a.rel='noopener noreferrer';a.dataset.navigation=provider;row.append(a)}return row}
function stopSummary(point,onOpenDay){const node=element('div',undefined,'map-stop');node.append(element('strong','יום '+point.day+' · '+point.label));node.append(element('p','יעד בתוכנית היומית: '+(point.destination?.query||point.label)));if(point.precision!=='exact')node.append(element('small','סיכת המפה מציינת אזור; הניווט מחפש את יעד היום. יש לאמת כתובת לפני יציאה.','muted'));node.append(navigation(point));const open=element('button','פתח תוכנית ליום '+point.day,'btn');open.type='button';open.dataset.openDay=point.id;open.onclick=()=>onOpenDay?.(point.id);node.append(open);return node}
export function mountRouteMap(root,items,onOpenDay,destination='Thailand'){
 const stops=items.filter(x=>x.kind==='stop').sort((a,b)=>a.payload.day-b.payload.day),points=routePoints(stops,destination),groups=groupRoutePoints(points),mapped=new Set(points.map(x=>x.id));
 const summary=element('p',groups.length+' נקודות על המפה · '+points.length+' עצירות ממוקמות מתוך '+stops.length);root.append(summary);
 const container=element('div');container.id='route-map';container.setAttribute('aria-label','מפה אינטראקטיבית של נקודות המסלול');root.append(container);
 const warning=element('p','רקע המפה לא נטען. אפשר להשתמש בכפתורי הניווט ברשימת הנקודות למטה.','map-warning');warning.hidden=true;root.append(warning);
 const unmapped=stops.filter(x=>!mapped.has(x.id));if(unmapped.length){const missing=element('div');missing.id='unmapped-stops';missing.append(element('h3','עצירות ללא מיקום במפה'));missing.append(element('p','אפשר להוסיף קו רוחב וקו אורך בעריכת העצירה בתוכנית היומית.'));for(const item of unmapped)missing.append(stopSummary({id:item.id,day:item.payload.day,label:item.payload.place,destination:dailyDestination(item.payload,destination),precision:'unknown'},onOpenDay));root.append(missing)}
 const list=element('details');list.append(element('summary','כל נקודות המסלול ('+stops.length+')'));for(const item of stops)list.append(stopSummary(points.find(x=>x.id===item.id)??{day:item.payload.day,label:item.payload.place,destination:dailyDestination(item.payload,destination),precision:'unknown'},onOpenDay));root.append(list);
 root.append(element('p','בנקודות של שיט או טיסה יש לבחור את הרציף או שדה התעופה הרלוונטי.','muted'));
 if(!groups.length){container.append(element('p','כדי להציג נקודות במפה, הוסף עצירות עם מיקום בתוכנית היומית.'));return ()=>{}}
 const map=L.map(container,{scrollWheelZoom:false});map.attributionControl.setPrefix(false);
 let openedPopup=null;
 const updatePopupLimits=()=>{const size=map.getSize(),limits=popupDimensions(size.x,size.y);container.style.setProperty('--route-popup-width',limits.maxWidth+'px');container.style.setProperty('--route-popup-height',limits.maxHeight+'px');const open=openedPopup;if(open){Object.assign(open.options,limits);open.update()}return limits};
 updatePopupLimits();map.on('resize',updatePopupLimits);map.on('popupopen',event=>{openedPopup=event.popup;updatePopupLimits()});map.on('popupclose',()=>{openedPopup=null});
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'}).on('tileerror',()=>{warning.hidden=false}).addTo(map);
 for(const group of groups){const first=group.points[0],badge=element('span',String(first.day)+(group.points.length>1?'+':''));const icon=L.divIcon({className:'route-marker',html:badge,iconSize:[44,44],iconAnchor:[22,22]});const popup=element('div');popup.dir='rtl';for(const point of group.points)popup.append(stopSummary(point,onOpenDay));L.marker([group.lat,group.lng],{icon,title:group.points.map(x=>'יום '+x.day+' · '+x.label).join(' / ')}).bindPopup(popup,{...popupDimensions(map.getSize().x,map.getSize().y),className:'route-popup',autoPanPadding:[16,16],keepInView:true}).addTo(map)}
 map.fitBounds(groups.map(x=>[x.lat,x.lng]),{padding:[30,30],maxZoom:12});
 const timer=setTimeout(()=>{map.invalidateSize();container.scrollIntoView?.({block:'start',behavior:'instant'})},0),observer=typeof ResizeObserver==='function'?new ResizeObserver(()=>map.invalidateSize()):null;observer?.observe(container);
 return ()=>{clearTimeout(timer);observer?.disconnect();map.remove()};
}

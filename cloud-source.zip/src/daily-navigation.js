import {navigationLinks} from './route-points.js';
import {escapeHtml} from './ui-components.js';
export function lodgingForDay(stop,items){
 const match=String(stop.payload.notes||'').match(/(?:^|\n)לינה:\s*([^\n.]+)(?:\.|$)/);
 if(!match||/^ללא\b|^ללא\s/.test(match[1].trim()))return null;
 const label=match[1].trim(),name=label.split(/\s+[–—]\s+/)[0].trim();
 const booking=items.find(x=>x.kind==='booking'&&x.payload.type==='מלון'&&(x.payload.supplier===name||x.payload.name?.startsWith(name+' –')));
 return {label,query:name+' '+(booking?.payload.name?.split(/\s+[–—]\s+/).slice(1).join(' ')||stop.payload.place)+' Thailand',status:booking?.payload.status||'לבדיקה'};
}
export function lodgingMarkup(stop,items){
 const lodging=lodgingForDay(stop,items);if(!lodging)return '';
 const links=navigationLinks({...lodging,precision:'unknown'});
 return '<div class="daily-lodging"><h4>לינה בסיום היום</h4><p>'+escapeHtml(lodging.label)+' <span class="badge">'+escapeHtml(lodging.status)+'</span></p><div class="row">'+[['google','Google Maps'],['waze','Waze']].map(([key,name])=>'<a class="btn" data-lodging-navigation="'+key+'" href="'+escapeHtml(links[key])+'" target="_blank" rel="noopener noreferrer">ניווט ללינה ב־'+name+'</a>').join('')+'</div><small>חיפוש מקום הלינה הרשום בתכנון; יש לאמת את הנכס והכתובת לפני יציאה.</small></div>';
}

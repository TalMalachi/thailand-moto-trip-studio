export const countryName=name=>({'תאילנד':'Thailand','וייטנאם':'Vietnam','ויאטנם':'Vietnam','וייטנם':'Vietnam'}[name]||name||'Thailand');
export function dailyDestination(payload,destination='Thailand'){
 let query='';
 try{const u=new URL(payload.url);if(['www.google.com','maps.google.com','google.com'].includes(u.hostname)&&u.pathname.startsWith('/maps'))query=u.searchParams.get('query')||u.searchParams.get('destination')||u.searchParams.get('q')||''}catch{}
 return {label:payload.place,query:query||payload.place+' '+countryName(destination)};
}
// General destination locations are a map overview, never a verified address.
const areas=[
 {aliases:['צ׳אנג מאי','צ’אנג מאי','צאנג מאי','chiang mai'],lat:18.7883,lng:98.9853,query:'Chiang Mai, Thailand'},
 {aliases:['chom thong','צ׳ום תונג'],lat:18.419,lng:98.68,query:'Chom Thong, Chiang Mai, Thailand'},
 {aliases:['דוי אינתנון','doi inthanon'],lat:18.588,lng:98.487,query:'Doi Inthanon National Park, Thailand'},
 {aliases:['מה הונג סון','mae hong son'],lat:19.3003,lng:97.9654,query:'Mae Hong Son, Thailand'},
 {aliases:['מה סריאנג','מאה סריאנג','mae sariang'],lat:18.162,lng:97.933,query:'Mae Sariang, Thailand'},
 {aliases:['פאי','pai'],lat:19.359,lng:98.441,query:'Pai, Mae Hong Son, Thailand'},
 {aliases:['ריילי','railay'],lat:8.012,lng:98.837,query:'Railay Beach, Krabi, Thailand'},
 {aliases:['איי הונג','hong island'],lat:8.079,lng:98.68,query:'Hong Island, Krabi, Thailand'},
 {aliases:['או נאנג','ao nang'],lat:8.032,lng:98.824,query:'Ao Nang, Krabi, Thailand'},
 {aliases:['קראבי','krabi'],lat:8.063,lng:98.916,query:'Krabi, Thailand'},
 {aliases:['בנגקוק','bangkok'],lat:13.7563,lng:100.5018,query:'Bangkok, Thailand'}
];
function pair(lat,lng){if(lat===undefined||lng===undefined||String(lat).trim()===''||String(lng).trim()==='')return null;lat=Number(lat);lng=Number(lng);return Number.isFinite(lat)&&Number.isFinite(lng)&&Math.abs(lat)<=90&&Math.abs(lng)<=180?{lat,lng}:null}
function position(payload,destination='Thailand'){
 const explicit=pair(payload.lat,payload.lng);if(explicit)return {...explicit,precision:'exact'};
 try{const url=new URL(payload.url),query=url.searchParams.get('query')??url.searchParams.get('q');if(query&&query.toLowerCase().includes('suvarnabhumi'))return {lat:13.69,lng:100.75,precision:'area',query:'Suvarnabhumi Airport, Thailand'};if(query&&/^-?\d+(?:\.\d+)?\s*,\s*-?\d+(?:\.\d+)?$/.test(query)){const p=pair(...query.split(','));if(p)return {...p,precision:'exact'}}}catch{}
 if(countryName(destination)!=='Thailand')return null;
 const name=String(payload.place??'').toLowerCase(),area=areas.find(x=>x.aliases.some(alias=>name.includes(alias)));return area?{lat:area.lat,lng:area.lng,query:area.query,precision:'area'}:null;
}
export function routePoints(items,destination='Thailand'){return items.filter(x=>x.kind==='stop').map(x=>{const p=position(x.payload,destination);return p?{...p,id:x.id,day:x.payload.day,label:x.payload.place,kind:x.payload.kind,destination:dailyDestination(x.payload,destination)}:null}).filter(Boolean).sort((a,b)=>a.day-b.day)}
export function groupRoutePoints(points){const groups=new Map();for(const point of points){const key=point.lat.toFixed(6)+','+point.lng.toFixed(6);if(!groups.has(key))groups.set(key,{lat:point.lat,lng:point.lng,points:[]});groups.get(key).points.push(point)}return [...groups.values()]}
export function navigationLinks(point){
 const exact=point.precision==='exact'&&pair(point.lat,point.lng),target=exact?point.lat+','+point.lng:(point.destination?.query||point.query||point.label);
 const google=new URL('https://www.google.com/maps/dir/');google.searchParams.set('api','1');google.searchParams.set('destination',target);google.searchParams.set('dir_action','navigate');
 const waze=new URL('https://waze.com/ul');if(exact){waze.searchParams.set('ll',target);waze.searchParams.set('navigate','yes')}else waze.searchParams.set('q',target);
 return {google:google.href,waze:waze.href};
}

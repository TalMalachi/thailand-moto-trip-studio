export function createAuth(client,redirectTo){return {
  async requestLink(email){email=email.trim();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('כתובת מייל לא תקינה');const {error}=await client.auth.signInWithOtp({email,options:{shouldCreateUser:false,emailRedirectTo:redirectTo}});if(error)throw Error(error.message)},
  async session(){const {data,error}=await client.auth.getSession();if(error)throw Error(error.message);return data.session},
  async signOut(){const {error}=await client.auth.signOut();if(error)throw Error(error.message)},
  onChange(callback){return client.auth.onAuthStateChange((_event,session)=>{setTimeout(()=>callback(session),0)}).data.subscription}
}}

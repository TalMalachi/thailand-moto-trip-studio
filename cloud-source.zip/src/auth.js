export function createAuth(client,redirectTo){return {
  async requestLink(email){email=email.trim();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('כתובת מייל לא תקינה');const {error}=await client.auth.signInWithOtp({email,options:{shouldCreateUser:false,emailRedirectTo:redirectTo}});if(error)throw Error(error.message)},
  async signUp(email,password,profile){if(password.length<12)throw Error('נדרשת סיסמה באורך 12 תווים לפחות');const {error}=await client.auth.signUp({email:email.trim(),password,options:{emailRedirectTo:redirectTo,data:{profile}}});if(error)throw Error(error.message)},
  async signOutLocal(){const {error}=await client.auth.signOut({scope:'local'});if(error)throw Error(error.message)},
  async signInAdmin(username,password){const {data,error}=await client.functions.invoke('admin-auth',{body:{action:'signin',username:username.trim().toLowerCase(),password}});if(error||data?.error||!data?.access_token||!data?.refresh_token)throw Error('שם המשתמש או הסיסמה שגויים, החשבון אינו פעיל או שיש להמתין לפני ניסיון נוסף');const result=await client.auth.setSession({access_token:data.access_token,refresh_token:data.refresh_token});if(result.error)throw Error('לא ניתן להשלים כניסת מנהל')},
  async requestAdminReset(username){const {error}=await client.functions.invoke('admin-auth',{body:{action:'reset',username:username.trim().toLowerCase()}});if(error)throw Error('לא ניתן לשלוח קישור כרגע')},
  async signIn(email,password){const {error}=await client.auth.signInWithPassword({email:email.trim(),password});if(error)throw Error(error.message)},
  async changePassword(password){const {error}=await client.auth.updateUser({password});if(error)throw Error(error.message)},
  async requestReset(email){const {error}=await client.auth.resetPasswordForEmail(email.trim(),{redirectTo});if(error)throw Error(error.message)},
  async session(){const {data,error}=await client.auth.getSession();if(error)throw Error(error.message);return data.session},
  async signOut(){const {error}=await client.auth.signOut();if(error)throw Error(error.message)},
  onChange(callback){return client.auth.onAuthStateChange((event,session)=>{setTimeout(()=>callback(session,event),0)}).data.subscription}
}}

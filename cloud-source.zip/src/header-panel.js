export function mountHeaderPanel(doc,win,isEnabled){
 const header=doc.querySelector('.site-header'),account=doc.querySelector('#account');
 if(!header||!account)return;
 const panel=doc.createElement('div');panel.id='floating-header';header.before(panel);panel.append(header,account);
 const toggle=doc.createElement('button');toggle.type='button';toggle.className='header-toggle';toggle.setAttribute('aria-controls',panel.id);doc.body.append(toggle);
 let collapsed=false,previous=win.scrollY||0,openedAt=previous;
 function update(value){collapsed=value;panel.classList.toggle('is-collapsed',value);panel.inert=value;toggle.setAttribute('aria-expanded',String(!value));toggle.textContent=value?'הצג כותרת ⌄':'מזער כותרת ⌃';toggle.classList.toggle('is-collapsed',value);}
 toggle.onclick=()=>{update(!collapsed);openedAt=win.scrollY||0};
 win.addEventListener('scroll',()=>{const y=win.scrollY||0;if(!isEnabled()||y<20)update(false);else if(y>previous&&y>80&&y-openedAt>30)update(true);previous=y},{passive:true});
 update(false);
}

import {preferenceGroups,readPreferences} from './planning-preferences.js';
export const draftSteps=['destination','dates','budget','travelers','style','interests','constraints','safety'];
const includes=['flights','lodging','transport','food','activities','insurance'];
export function preferenceText(choices,freeText){return readPreferences({get:k=>k==='preferences'?freeText:choices[k.replace('preference_','')],getAll:k=>choices[k.replace('preference_','')]||[]}).preferences}
export function recoverPreferences(value=''){
 const choices={},remaining=[];let free=false;
 for(const line of String(value).split('\n')){if(line.startsWith('העדפות נוספות בטקסט חופשי: ')){remaining.push(line.slice('העדפות נוספות בטקסט חופשי: '.length));free=true;continue}if(free){remaining.push(line);continue}const group=preferenceGroups.find(g=>line.startsWith(g.label+': '));if(!group){if(line)remaining.push(line);continue}const labels=line.slice(group.label.length+2).split(', '),picked=group.options.filter(([,label])=>labels.includes(label)).map(([id])=>id);choices[group.key]=group.multiple?picked:picked[0]||'';const unknown=labels.filter(label=>!group.options.some(([,known])=>known===label));if(unknown.length)remaining.push(group.label+': '+unknown.join(', '));}
 return {choices,freeText:remaining.join('\n')};
}
export function validatePlanningDraft(raw){
 if(!raw||raw.schemaVersion!==1||!raw.input||typeof raw.input!=='object'||Array.isArray(raw.input)||!raw.choices||typeof raw.choices!=='object'||Array.isArray(raw.choices)||typeof raw.freeText!=='string'||raw.freeText.length>2000||!Array.isArray(raw.reviewed)||raw.reviewed.some(x=>!draftSteps.includes(x)))throw Error('הגדרות התכנון אינן תקינות');
 const input={},choices={};
 for(const [k,min,max,integer] of [['days',1,365,true],['earlierDays',0,60,true],['laterDays',0,60,true],['shorterDays',0,30,true],['longerDays',0,30,true],['travelers',1,20,true],['rooms',1,20,true],['runLimitAgorot',1,500,true],['budget',0,1000000,false],['budgetDeviationPct',0,100,false]]){const v=raw.input[k];if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max||integer&&!Number.isInteger(v))throw Error('ערך לא תקין בהגדרות התכנון: '+k);input[k]=v;}
 for(const [key,max] of [['start',10],['departure',100]]){const v=raw.input[key];if(typeof v!=='string'||v.length>max)throw Error('נתוני תכנון לא תקינים');input[key]=v.trim()}
 if(input.start&&(!/^\d{4}-\d{2}-\d{2}$/.test(input.start)||!Number.isFinite(Date.parse(input.start))||new Date(input.start).toISOString().slice(0,10)!==input.start))throw Error('תאריך לא תקין');
 if(!['motorcycle','car','public','mixed'].includes(raw.input.transport)||!Array.isArray(raw.input.includes)||raw.input.includes.some(x=>!includes.includes(x)))throw Error('בחירות תכנון לא תקינות');input.transport=raw.input.transport;input.includes=[...new Set(raw.input.includes)];
 for(const g of preferenceGroups){const allowed=g.options.map(([id])=>id),v=raw.choices[g.key]??(g.multiple?[]:'');if(g.multiple){if(!Array.isArray(v)||v.some(id=>!allowed.includes(id)))throw Error('העדפה לא תקינה');choices[g.key]=[...new Set(v)]}else{if(typeof v!=='string'||v!==''&&!allowed.includes(v))throw Error('העדפה לא תקינה');choices[g.key]=v}}
 const freeText=raw.freeText;input.preferences=preferenceText(choices,freeText);return {schemaVersion:1,input,choices,freeText,reviewed:[...new Set(raw.reviewed)]};
}
export function planningDraft(settings={},previousInput=null){
 const saved=settings.planningDraft;
 const defaults={start:'',days:21,earlierDays:0,laterDays:0,shorterDays:0,longerDays:0,budget:0,budgetDeviationPct:0,travelers:1,rooms:1,departure:'',transport:'motorcycle',includes,preferences:'',runLimitAgorot:500};
 const recovered=recoverPreferences(previousInput?.preferences);
 return validatePlanningDraft({schemaVersion:1,input:{...defaults,...(previousInput||{}),...(saved?.input||{}),start:settings.start??'',days:settings.days??21,budget:settings.budget??0},choices:saved?.choices||recovered.choices,freeText:saved?.freeText??recovered.freeText,reviewed:saved?.reviewed||(previousInput?draftSteps:[])});
}

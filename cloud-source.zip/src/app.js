import {workflowStatuses,workflowStatus,statisticsMarkup} from './workflow.js';
import {mountHeaderPanel} from './header-panel.js';
import {createClient} from '@supabase/supabase-js';
import {cloudConfig} from './cloud-config.js';
import {createAuth} from './auth.js';
import {createRepository} from './trip-repository.js';
import {parseBackup,previewImport,exportTrip} from './backup.js';
import {lodgingMarkup} from './daily-navigation.js';
import {mountRouteMap} from './route-map.js';
import {icon,navigationMarkup,recordCard,formatMoney} from './ui-components.js';
import './ui.css';

const client=createClient(cloudConfig.url,cloudConfig.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'thailand-cloud-auth'}});
const auth=createAuth(client,'https://talmalachi.github.io/thailand-moto-trip-studio/'),repo=createRepository(client);
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tabs=[['dashboard','סקירה'],['booking','הזמנות'],['stop','מסלול'],['place','מקומות ושירותים'],['gear','ציוד והדרכות'],['task','משימות'],['settings','הגדרות וגיבוי']];
const fields={booking:[['name','תיאור הזמנה'],['type','סוג'],['status','מצב הזמנה / תשלום'],['workflowStatus','סטטוס טיפול','workflow'],['supplier','ספק'],['cost','מחיר כולל ₪','number'],['paid','שולם ₪','number'],['ref','מספר אישור / הזמנה'],['url','קישור להזמנה','url'],['notes','הערות','textarea']],stop:[['day','יום בטיול','number'],['place','מקום / יעד'],['kind','סוג עצירה'],['url','קישור לניווט','url'],['notes','תכנון והערות','textarea'],['lat','קו רוחב (Latitude) – אופציונלי'],['lng','קו אורך (Longitude) – אופציונלי']],place:[['name','שם המקום'],['type','סוג'],['area','אזור'],['url','קישור למפות / אתר','url'],['notes','הערות / טלפון / שעות','textarea']],gear:[['name','פריט'],['category','קטגוריה'],['status','סטטוס'],['url','קישור לרכישה','url'],['guide','קישור להדרכת שימוש','url'],['notes','הערות','textarea']],task:[['title','משימה'],['category','קטגוריה'],['workflowStatus','סטטוס טיפול','workflow']]};
let session=null,trip=null,tab='stop',categories={place:null,booking:null,task:null},routeView='map',routeCleanup=null,busy=false,epoch=0,viewEpoch=0,authVersion=0;
let workViews={booking:'current',task:'current'},statusFilters={booking:'',task:''};
mountHeaderPanel(document,window,()=>Boolean(session&&trip));
function status(text){$('#message').textContent=text;const feedback=$('#editor').querySelector('[data-dialog-status]');if(feedback)feedback.textContent=text;}
const money=formatMoney;
function field(k,label,value='',type='text'){if(type==='workflow')return '<label>'+esc(label)+'<select name="'+k+'">'+workflowStatuses.map(([id,text])=>'<option value="'+id+'" '+(id===value?'selected':'')+'>'+text+'</option>').join('')+'</select></label>';return '<label>'+esc(label)+(type==='textarea'?'<textarea name="'+k+'">'+esc(value)+'</textarea>':'<input autocomplete="off" name="'+k+'" type="'+type+'" value="'+esc(value)+'" '+(['lat','lng'].includes(k)?'inputmode="decimal" ':'')+(type==='number'?'min="0" step="any"':'')+'>')+'</label>'}
function safeLink(url){try{const u=new URL(url);return ['https:','http:'].includes(u.protocol)?'<a href="'+esc(u.href)+'" target="_blank" rel="noopener noreferrer">פתח קישור ↗</a>':''}catch{return ''}}
function lock(value){busy=value;document.querySelectorAll('button').forEach(x=>x.disabled=value)}
function wipe(){routeCleanup?.();routeCleanup=null;routeView='map';epoch++;viewEpoch++;session=null;trip=null;workViews={booking:'current',task:'current'};statusFilters={booking:'',task:''};categories={place:null,booking:null,task:null};busy=false;$('#editor').close();$('#editor').innerHTML='';$('#tabs').innerHTML='';$('#account').innerHTML='';$('#view').innerHTML='';status('')}
function login(){
  $('#view').innerHTML='<section class="login"><div class="login-intro"><span class="login-symbol">'+icon('route')+'</span><h2>כניסה לטיול הפרטי שלך</h2><p>כל התכנון שלך במקום אחד, מסונכרן בין האייפון למחשב.</p></div><form id="login">'+field('email','כתובת מייל','','email')+field('password','סיסמה','','password')+'<button type="submit">כניסה עם סיסמה</button><button type="button" id="resetpassword">הגדרת סיסמה ראשונה / שכחתי סיסמה</button></form><div class="login-privacy">'+icon('shield')+'<span>הכניסה לחשבון שהוגדר מראש בלבד. להגדרת סיסמה ראשונה יש לפתוח קישור מאובטח שנשלח למייל.</span></div></section>';
  $('#login input[name=email]').autocomplete='username';
  $('#login input[name=email]').spellcheck=false;
  $('#login input[name=email]').setAttribute('autocapitalize','none');
  $('#login input[name=password]').autocomplete='current-password';
  $('#login').querySelectorAll('input').forEach(x=>x.required=true);
  $('#login').onsubmit=async e=>{e.preventDefault();const form=e.target,email=form.elements.email.value,password=form.elements.password.value;form.elements.password.value='';lock(true);status('מתחבר…');try{await auth.signIn(email,password);status('הכניסה הצליחה')}catch(err){status('הכניסה נכשלה: '+err.message)}finally{lock(false)}};
  $('#resetpassword').onclick=async()=>{const input=$('#login input[name=email]');if(!input.reportValidity())return;lock(true);try{await auth.requestReset(input.value);status('אם החשבון קיים ומותר לשלוח אליו מייל, יישלח קישור להגדרת סיסמה. פתח רק את ההודעה החדשה ביותר.')}catch(e){status('לא ניתן לשלוח קישור להגדרת סיסמה: '+e.message)}finally{lock(false)}};
}
function passwordEditor(){
 viewEpoch++;
 $('#editor').innerHTML='<form id="passwordform"><h2>הגדרת סיסמה חדשה</h2>'+field('password','סיסמה חדשה','','password')+field('confirm','אימות סיסמה','','password')+'<button type="submit">שמור סיסמה חדשה</button><button type="button" id="cancelpassword">ביטול</button><p id="passworderror" role="status"></p></form>';
 const form=$('#passwordform');form.querySelectorAll('input').forEach(x=>{x.required=true;x.minLength=12;x.autocomplete='new-password'});
 $('#cancelpassword').onclick=()=>$('#editor').close();
 form.onsubmit=async e=>{e.preventDefault();if(form.elements.password.value!==form.elements.confirm.value){$('#passworderror').textContent='הסיסמאות אינן זהות';return}const password=form.elements.password.value;lock(true);try{await auth.changePassword(password);form.reset();$('#editor').close();status('הסיסמה עודכנה')}catch(err){form.reset();$('#passworderror').textContent='העדכון נכשל: '+err.message}finally{lock(false)}};
 $('#editor').showModal();
}
function account(){
  $('#account').innerHTML='<div class="account-identity"><span class="account-avatar">'+icon('shield')+'</span><div><strong>הטיול שלי</strong><small dir="auto">'+esc(session.user.email)+'</small></div></div><div class="account-tools"><button id="refresh">'+icon('refresh')+'רענן מהענן</button><details class="account-menu"><summary>חשבון'+icon('chevron')+'</summary><div><button id="changepassword">שינוי סיסמה</button><button id="signout" class="danger">יציאה מהחשבון</button></div></details></div>';
  $('#refresh').onclick=()=>{if(tab==='settings'&&!confirm('הרענון יחליף שינויים שלא נשמרו בטופס ההגדרות. להמשיך?'))return;load().catch(showLoadError)};
  $('#changepassword').onclick=passwordEditor;
  $('#signout').onclick=async()=>{lock(true);try{await auth.signOut();wipe();login();status('יצאת מהחשבון')}catch(e){status('היציאה לא הושלמה: '+e.message)}finally{lock(false)}};
  $('#account').querySelectorAll('button').forEach(b=>b.disabled=busy);
}
function showLoadError(err){trip=null;$('#tabs').innerHTML='';$('#view').innerHTML='<section><h2>לא ניתן לטעון את הטיול</h2><p>'+esc(err.message)+'</p><button id="retry">נסה שוב</button></section>';$('#retry').onclick=()=>load().catch(showLoadError);status('המידע מהענן לא נטען.');}
async function load(){if(!session||busy||$('#editor').open)return;const run=++epoch,view=viewEpoch,user=session.user.id;const current=()=>run===epoch&&view===viewEpoch&&session?.user.id===user;status('טוען מהענן…');try{const loaded=await repo.getTrip();if(!current())return;trip=loaded;render();status('נטען מהענן • '+new Date().toLocaleTimeString('he-IL'))}catch(e){if(current())throw e}}
async function saveOperation(operation){if(busy)return false;const run=epoch;lock(true);status('שומר בענן…');try{await operation();if(run!==epoch||!session)return false;status('נשמר בענן');return true}catch(e){if(run===epoch)status('לא נשמר: '+e.message);return false}finally{lock(false)}}
async function afterSave(){try{await load();status('נשמר בענן')}catch(e){showLoadError(e);status('השינוי נשמר בענן, אך הרענון נכשל. נסה לרענן שוב.')}}
function focusView(){const heading=$('#view h2');if(heading){heading.tabIndex=-1;heading.focus()}}
function render(){
 routeCleanup?.();routeCleanup=null;
 if(!trip||!session)return;
 viewEpoch++;
 $('#tabs').innerHTML=navigationMarkup(tabs,tab);
 $('#tabs').querySelectorAll('button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render();focusView()});
 if(tab==='dashboard'){
  const bookings=trip.items.filter(x=>x.kind==='booking').map(x=>x.payload),tasks=trip.items.filter(x=>x.kind==='task');
  $('#view').innerHTML='<div class="cards">'+[['תקציב יעד',(trip.settings.budget?money(trip.settings.budget):'טרם נקבע')],['שולם בפועל',money(bookings.reduce((s,x)=>s+Number(x.paid||0),0))],['התחייבויות',money(bookings.filter(x=>['הוזמן','שולם'].includes(x.status)).reduce((s,x)=>s+Number(x.cost||0),0))],['משימות שבוצעו',tasks.filter(x=>x.payload.done).length+'/'+tasks.length]].map(([k,v])=>'<section><small>'+k+'</small><div class="metric">'+v+'</div></section>').join('')+'</div><section><h2>תמונת מצב</h2><p>משך הטיול: '+esc(trip.settings.days)+' ימים | יציאה: '+esc(trip.settings.start||'טרם נקבע')+'</p><p>הנתונים נטענים מחשבונך בענן. חזור לאפליקציה או לחץ על רענן כדי לקבל עדכונים ממכשיר אחר.</p></section>';return;
 }
 if(tab==='settings'){settings();return}
 let items=trip.items.filter(x=>x.kind===tab);if(tab==='stop')items.sort((a,b)=>a.payload.day-b.payload.day);
 let categoryMenu='',categoryOptions=[];
 if(tab==='stop'){
  categoryMenu='<div class="row" role="group" aria-label="תצוגת מסלול" style="margin:12px 0">'+[['map','מפה'],['list','תוכנית יומית']].map(([id,label])=>'<button type="button" data-route-view="'+id+'" aria-pressed="'+(routeView===id)+'" class="'+(routeView===id?'active':'')+'">'+label+'</button>').join('')+'</div>';
  if(routeView==='map'){
   $('#view').innerHTML='<section><div class="row"><h2>מסלול</h2><button id="add">+ הוסף עצירה</button></div>'+categoryMenu+'<div id="route-map-panel"></div></section>';
   $('#view').querySelectorAll('[data-route-view]').forEach(b=>b.onclick=()=>{routeView=b.dataset.routeView;render();focusView()});
   $('#add').onclick=()=>edit('stop');routeCleanup=mountRouteMap($('#route-map-panel'),items,id=>{routeView='list';render();const card=[...$('#view').querySelectorAll('[data-id]')].find(x=>x.dataset.id===id);const heading=card?.querySelector('h3');if(heading){heading.tabIndex=-1;heading.focus();heading.scrollIntoView?.({block:'start'})}});return;
  }
 }
 if(['place','booking','task'].includes(tab)){
  const category=x=>(tab==='task'?x.payload.category:x.payload.type)?.trim()||(tab==='task'?'כללי':'ללא קטגוריה'),counts=new Map();
  items.forEach(x=>counts.set(category(x),(counts.get(category(x))||0)+1));
  if(categories[tab]!==null&&!counts.has(categories[tab]))categories[tab]=null;
  categoryOptions=[null,...[...counts.keys()].sort((a,b)=>a.localeCompare(b,'he'))];
  categoryMenu='<div class="place-filter-bar"><label for="place-category">קטגוריה</label><select id="place-category" aria-label="קטגוריות '+esc(tabs.find(x=>x[0]===tab)[1])+'">'+categoryOptions.map((name,index)=>'<option value="'+index+'" '+(categories[tab]===name?'selected':'')+'>'+esc(name??'הכול')+' ('+(name===null?items.length:counts.get(name))+')</option>').join('')+'</select></div>';
  if(categories[tab]!==null)items=items.filter(x=>category(x)===categories[tab]);
 }
 let workflowMenu='',recordsMarkup='';
 const managed=['booking','task'].includes(tab),statistics=managed&&workViews[tab]==='stats';
 if(managed){workflowMenu='<div class="workflow-views" role="group" aria-label="תצוגת '+esc(tabs.find(x=>x[0]===tab)[1])+'">'+[['current','מצב נוכחי'],['stats','סטטיסטיקות']].map(([id,label])=>'<button type="button" data-work-view="'+id+'" aria-pressed="'+(workViews[tab]===id)+'" class="'+(workViews[tab]===id?'active':'')+'">'+label+'</button>').join('')+'</div>';
 if(statistics)recordsMarkup=statisticsMarkup(items);
 else {workflowMenu+='<div class="place-filter-bar"><label for="workflow-filter">סטטוס</label><select id="workflow-filter"><option value="">כל הסטטוסים</option>'+workflowStatuses.map(([id,label])=>'<option value="'+id+'" '+(statusFilters[tab]===id?'selected':'')+'>'+label+' ('+items.filter(x=>workflowStatus(x)===id).length+')</option>').join('')+'</select></div>';if(statusFilters[tab])items=items.filter(x=>workflowStatus(x)===statusFilters[tab]);}
 }
 if(!statistics)recordsMarkup='<div class="cards">'+items.map(x=>recordCard(x,fields[tab],tab==='stop'?lodgingMarkup(x,trip.items):'')).join('')+'</div>'+(items.length?'':'<p>אין פריטים להצגה בסינון הנוכחי.</p>');
 $('#view').innerHTML='<section><div class="row"><h2>'+tabs.find(x=>x[0]===tab)[1]+'</h2><button id="add">+ הוסף פריט</button></div>'+workflowMenu+categoryMenu+recordsMarkup+'</section>';
 $('#view').querySelectorAll('[data-route-view]').forEach(b=>b.onclick=()=>{routeView=b.dataset.routeView;render();focusView()});
 $('#view').querySelectorAll('[data-work-view]').forEach(b=>b.onclick=()=>{workViews[tab]=b.dataset.workView;render();$('#view [data-work-view][aria-pressed=true]')?.focus()});
 const statusSelect=$('#workflow-filter');if(statusSelect)statusSelect.onchange=()=>{statusFilters[tab]=statusSelect.value;render();$('#workflow-filter')?.focus()};
 const categorySelect=$('#place-category');if(categorySelect)categorySelect.onchange=()=>{categories[tab]=categoryOptions[Number(categorySelect.value)];render();$('#place-category')?.focus({preventScroll:true})};
 $('#add').onclick=()=>edit(tab);
 $('#view').querySelectorAll('[data-id]').forEach(card=>{const item=items.find(x=>x.id===card.dataset.id);card.querySelector('[data-action=edit]').onclick=()=>edit(item.kind,item);card.querySelector('[data-action=delete]').onclick=async()=>{if(!confirm('למחוק את הפריט מהענן ומכל המכשירים?'))return;if(await saveOperation(()=>repo.deleteItem(item.id,item.version)))await afterSave()};const cb=card.querySelector('input[type=checkbox]');if(cb)cb.onchange=async()=>{const done=cb.checked;if(await saveOperation(()=>repo.updateItem(item.id,item.version,item.kind,{...item.payload,done,workflowStatus:done?'completed':'opened',workflowUpdatedAt:new Date().toISOString(),workflowUpdatedBy:'user'})))await afterSave();else cb.checked=workflowStatus(item)==='completed'}});
}
function edit(kind,existing){
 viewEpoch++;
 const item=existing?structuredClone(existing):{id:crypto.randomUUID(),kind,payload:['place','booking','task'].includes(kind)&&categories[kind]!==null?{[kind==='task'?'category':'type']:categories[kind]==='ללא קטגוריה'?'':categories[kind]}:{}};
 $('#editor').innerHTML='<form><h2>'+(existing?'עריכת פריט':'הוספת פריט')+'</h2>'+fields[kind].map(([k,t,type])=>field(k,t,item.payload[k]??(type==='workflow'?workflowStatus(item):(type==='number'?(k==='day'?1:0):'')),type)).join('')+'<div class="row form-actions"><button type="submit">שמור בענן</button><button type="button" id="cancel">ביטול</button></div><p data-dialog-status role="status" aria-live="polite"></p><p class="form-hint">השינויים יישמרו בחשבונך בענן.</p></form>';
 $('#cancel').onclick=()=>$('#editor').close();
 $('#editor form').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target),payload={...item.payload};for(const [k,t,type] of fields[kind])payload[k]=type==='number'?Number(fd.get(k)):fd.get(k);if(['booking','task'].includes(kind)){if(!existing||payload.workflowStatus!==workflowStatus(item)){payload.workflowUpdatedAt=new Date().toISOString();payload.workflowUpdatedBy='user';}if(kind==='task')payload.done=payload.workflowStatus==='completed';}const okay=await saveOperation(()=>existing?repo.updateItem(item.id,item.version,kind,payload):repo.createItem(trip.id,{...item,payload}));if(okay){$('#editor').close();await afterSave()}};
 $('#editor').showModal();
}
function download(text){const url=URL.createObjectURL(new Blob([text],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='thailand-moto-trip-backup.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function preview(parsed){
 const plan=previewImport(trip.items,parsed.items);const tripId=trip.id;
 $('#editor').innerHTML='<h2>תצוגה מקדימה לייבוא</h2><p>פריטים חדשים: '+plan.add.length+' | פריטים קיימים שיישארו ללא שינוי: '+plan.skip.length+'</p><p>הגדרות הטיול והמידע הקיים לא יוחלפו.</p><ul>'+plan.add.map(x=>'<li>'+esc(x.payload.place??x.payload.name??x.payload.title)+'</li>').join('')+'</ul><div class="row"><button id="confirmimport">הוסף פריטים לענן</button><button id="cancelimport">ביטול</button></div>';
 $('#cancelimport').onclick=()=>$('#editor').close();$('#confirmimport').onclick=async()=>{if(await saveOperation(()=>repo.importItems(tripId,plan.add))){$('#editor').close();await afterSave()}};$('#editor').showModal();
}
function settings(){
 $('#view').innerHTML='<section><h2>הגדרות הטיול</h2><form id="settingsform">'+field('start','תאריך יציאה מתוכנן',trip.settings.start,'date')+field('days','מספר ימים',trip.settings.days,'number')+field('budget','תקציב כולל ₪',trip.settings.budget,'number')+'<button type="submit">שמור הגדרות בענן</button></form></section><section><h2>גיבוי והעברת נתונים</h2><p>המידע נשמר בחשבונך בענן. מומלץ להוריד גיבוי לפני שינויים גדולים.</p><button id="export">יצוא גיבוי JSON</button><label>יבוא גיבוי JSON<input id="import" type="file" accept="application/json,.json"></label><button id="localimport">העבר נתונים מהגרסה המקומית במכשיר זה</button><p>הייבוא מוסיף פריטים חדשים לאחר תצוגה מקדימה. הוא אינו מוחק או מחליף פריטים קיימים.</p></section>';
 $('#settingsform').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target),settings={start:fd.get('start'),days:Number(fd.get('days')),budget:Number(fd.get('budget')),currency:'ILS'};if(await saveOperation(()=>repo.updateSettings(trip.id,trip.version,settings)))await afterSave()};
 $('#export').onclick=()=>download(exportTrip(trip));
 $('#import').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>5_000_000)throw Error('קובץ גדול מדי');preview(parseBackup(await f.text()))}catch(err){status('הייבוא לא בוצע: '+err.message)}finally{e.target.value=''}};
 $('#localimport').onclick=()=>{try{const old=localStorage.getItem('thailand_moto_trip_v1');if(!old)throw Error('לא נמצאו נתונים מקומיים במכשיר זה');preview(parseBackup(old))}catch(e){status('הייבוא לא בוצע: '+e.message)}};
}
async function applySession(next){const previous=session?.user.id;if(!next){wipe();login();return}if(previous!==next.user.id){wipe();tab='stop'}session=next;account();if(!trip){$('#view').textContent='טוען מהענן…';try{await load()}catch(e){showLoadError(e)}}}
auth.onChange((next,event)=>{authVersion++;applySession(next).then(()=>{if(event==='PASSWORD_RECOVERY'&&session)passwordEditor()}).catch(e=>status(e.message))});
document.addEventListener('input',()=>viewEpoch++);
$('#editor').addEventListener('cancel',e=>{if(busy)e.preventDefault()});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&session&&!busy&&tab!=='settings'&&!$('#editor').open)load().catch(showLoadError)});
auth.session().then(next=>{if(authVersion===0)return applySession(next)}).catch(e=>{if(authVersion!==0)return;wipe();login();status('בדיקת ההתחברות נכשלה: '+e.message)});

if(typeof ResizeObserver==='function'){
 const navigationObserver=new ResizeObserver(entries=>{const height=entries[0]?.borderBoxSize?.[0]?.blockSize??$('#tabs').getBoundingClientRect().height;document.documentElement.style.setProperty('--navigation-space',Math.ceil(height)+28+'px')});
 navigationObserver.observe($('#tabs'));
}

// Refresh agent status updates while a managed view is open; never replace an editor draft.
window.setInterval(()=>{if(session&&trip&&!busy&&['booking','task'].includes(tab)&&!$('#editor').open&&document.visibilityState==='visible')load().catch(e=>status('לא ניתן לרענן סטטוסים: '+e.message))},30000);

import {mountAgentHub} from './agent-hub.js';
import {completionMarkup} from './trip-completion.js';
import {openPlanning} from './planning-ui.js';
import {createPlanningApi} from './planning-api.js';
import {policyFields,policyFormMarkup,policiesMarkup,validatePolicy} from './booking-policies.js';
import {workflowStatuses,workflowStatus,statisticsMarkup} from './workflow.js';
import {mountHeaderPanel} from './header-panel.js';
import {createClient} from '@supabase/supabase-js';
import {cloudConfig} from './cloud-config.js';
import {createAuth} from './auth.js';
import {createRepository} from './trip-repository.js';
import {parseBackup,previewImport,exportTrip} from './backup.js';
import {lodgingMarkup} from './daily-navigation.js';
import {mountRouteMap} from './route-map.js';
import {icon,navigationMarkup,recordCard,formatMoney} from './ui-components.js';
import './ui.css';

const client=createClient(cloudConfig.url,cloudConfig.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'thailand-cloud-auth'}});
const auth=createAuth(client,new URL('./',window.location.href).href),repo=createRepository(client);
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tabs=[['dashboard','סקירה'],['agent','סוכן, אישורים ודו״חות'],['booking','הזמנות'],['stop','מסלול'],['place','מקומות ושירותים'],['gear','ציוד והדרכות'],['task','משימות'],['settings','גיבוי ונתונים']];
const fields={booking:[['name','תיאור הזמנה'],['type','סוג'],['status','מצב הזמנה / תשלום'],['workflowStatus','סטטוס טיפול','workflow'],['supplier','ספק'],['cost','מחיר כולל ₪','number'],['paid','שולם ₪','number'],['ref','מספר אישור / הזמנה'],['url','קישור להזמנה','url'],['notes','הערות','textarea']],stop:[['day','יום בטיול','number'],['place','מקום / יעד'],['kind','סוג עצירה'],['url','קישור לניווט','url'],['notes','תכנון והערות','textarea'],['lat','קו רוחב (Latitude) – אופציונלי'],['lng','קו אורך (Longitude) – אופציונלי']],place:[['name','שם המקום'],['type','סוג'],['area','אזור'],['url','קישור למפות / אתר','url'],['notes','הערות / טלפון / שעות','textarea']],gear:[['name','פריט'],['category','קטגוריה'],['status','סטטוס'],['url','קישור לרכישה','url'],['guide','קישור להדרכת שימוש','url'],['notes','הערות','textarea']],task:[['title','משימה'],['category','קטגוריה'],['workflowStatus','סטטוס טיפול','workflow']]};
let session=null,trip=null,tab='stop',categories={place:null,booking:null,task:null},routeView='map',routeCleanup=null,busy=false,epoch=0,viewEpoch=0,authVersion=0;
let selectedTripId=null,destinations=[],policyReviewDirty=false;
let workViews={booking:'stats',task:'stats'},statusFilters={booking:'',task:''};
mountHeaderPanel(document,window,()=>Boolean(session&&trip));
function status(text){$('#message').textContent=text;const feedback=$('#editor').querySelector('[data-dialog-status]');if(feedback)feedback.textContent=text;}
const money=formatMoney;
function field(k,label,value='',type='text'){if(type==='workflow')return '<label>'+esc(label)+'<select name="'+k+'">'+workflowStatuses.map(([id,text])=>'<option value="'+id+'" '+(id===value?'selected':'')+'>'+text+'</option>').join('')+'</select></label>';return '<label>'+esc(label)+(type==='textarea'?'<textarea name="'+k+'">'+esc(value)+'</textarea>':'<input autocomplete="off" name="'+k+'" type="'+type+'" value="'+esc(value)+'" '+(['lat','lng'].includes(k)?'inputmode="decimal" ':'')+(type==='number'?'min="0" step="any"':'')+'>')+'</label>'}
function safeLink(url){try{const u=new URL(url);return ['https:','http:'].includes(u.protocol)?'<a href="'+esc(u.href)+'" target="_blank" rel="noopener noreferrer">פתח קישור ↗</a>':''}catch{return ''}}
function lock(value){busy=value;document.querySelectorAll('button').forEach(x=>x.disabled=value)}
function wipe(){routeCleanup?.();routeCleanup=null;routeView='map';epoch++;viewEpoch++;session=null;trip=null;selectedTripId=null;destinations=[];workViews={booking:'stats',task:'stats'};statusFilters={booking:'',task:''};categories={place:null,booking:null,task:null};busy=false;$('#editor').close();$('#editor').innerHTML='';$('#tabs').innerHTML='';$('#account').innerHTML='';$('#view').innerHTML='';status('')}
function login(){
  $('#view').innerHTML='<section class="login"><div class="login-intro"><span class="login-symbol">'+icon('route')+'</span><h2>כניסה ל־Motor Trip Studio</h2><p>כל היעדים והטיולים שלך במקום אחד, מסונכרנים בין האייפון למחשב.</p></div><form id="login">'+field('email','כתובת מייל','','email')+field('password','סיסמה','','password')+'<button type="submit">כניסה עם סיסמה</button><button type="button" id="resetpassword">הגדרת סיסמה ראשונה / שכחתי סיסמה</button></form><div class="login-privacy">'+icon('shield')+'<span>הכניסה לחשבון שהוגדר מראש בלבד. להגדרת סיסמה ראשונה יש לפתוח קישור מאובטח שנשלח למייל.</span></div></section>';
  $('#login input[name=email]').autocomplete='username';
  $('#login input[name=email]').spellcheck=false;
  $('#login input[name=email]').setAttribute('autocapitalize','none');
  $('#login input[name=password]').autocomplete='current-password';
  $('#login').querySelectorAll('input').forEach(x=>x.required=true);
  $('#login').onsubmit=async e=>{e.preventDefault();const form=e.target,email=form.elements.email.value,password=form.elements.password.value;form.elements.password.value='';lock(true);status('מתחבר…');try{await auth.signIn(email,password);status('הכניסה הצליחה')}catch(err){status('הכניסה נכשלה: '+err.message)}finally{lock(false)}};
  $('#resetpassword').onclick=async()=>{const input=$('#login input[name=email]');if(!input.reportValidity())return;lock(true);try{await auth.requestReset(input.value);status('אם החשבון קיים ומותר לשלוח אליו מייל, יישלח קישור להגדרת סיסמה. פתח רק את ההודעה החדשה ביותר.')}catch(e){status('לא ניתן לשלוח קישור להגדרת סיסמה: '+e.message)}finally{lock(false)}};
}
function passwordEditor(){
 viewEpoch++;
 $('#editor').innerHTML='<form id="passwordform"><h2>הגדרת סיסמה חדשה</h2>'+field('password','סיסמה חדשה','','password')+field('confirm','אימות סיסמה','','password')+'<button type="submit">שמור סיסמה חדשה</button><button type="button" id="cancelpassword">ביטול</button><p id="passworderror" role="status"></p></form>';
 const form=$('#passwordform');form.querySelectorAll('input').forEach(x=>{x.required=true;x.minLength=12;x.autocomplete='new-password'});
 $('#cancelpassword').onclick=()=>$('#editor').close();
 form.onsubmit=async e=>{e.preventDefault();if(form.elements.password.value!==form.elements.confirm.value){$('#passworderror').textContent='הסיסמאות אינן זהות';return}const password=form.elements.password.value;lock(true);try{await auth.changePassword(password);form.reset();$('#editor').close();status('הסיסמה עודכנה')}catch(err){form.reset();$('#passworderror').textContent='העדכון נכשל: '+err.message}finally{lock(false)}};
 $('#editor').showModal();
}
function account(){
  $('#account').innerHTML='<div class="account-identity"><span class="account-avatar">'+icon('shield')+'</span><div><strong>'+esc(trip?.destination_name||'Motor Trip Studio')+'</strong><small dir="auto">'+esc(session.user.email)+'</small></div></div><div class="account-tools"><button id="destinations-home">יעדים</button><button id="refresh">'+icon('refresh')+'רענן מהענן</button><details class="account-menu"><summary>חשבון'+icon('chevron')+'</summary><div>'+(trip?'<button id="edit-current-destination">עריכת יעד</button>':'')+'<button id="changepassword">שינוי סיסמה</button><button id="signout" class="danger">יציאה מהחשבון</button></div></details></div>';
  $('#destinations-home').onclick=()=>{if(busy)return;$('#editor').close();routeCleanup?.();routeCleanup=null;selectedTripId=null;trip=null;epoch++;viewEpoch++;load().catch(showLoadError)};
  $('#refresh').onclick=()=>{if(policyReviewDirty&&!confirm('רענון יחליף בחירות שטרם אושרו. להמשיך?'))return;policyReviewDirty=false;load().catch(showLoadError)};
  const editCurrent=$('#edit-current-destination');if(editCurrent)editCurrent.onclick=()=>destinationEditor(trip);
  $('#changepassword').onclick=passwordEditor;
  $('#signout').onclick=async()=>{lock(true);try{await auth.signOut();wipe();login();status('יצאת מהחשבון')}catch(e){status('היציאה לא הושלמה: '+e.message)}finally{lock(false)}};
  $('#account').querySelectorAll('button').forEach(b=>b.disabled=busy);
}
function showLoadError(err){trip=null;$('#tabs').innerHTML='';$('#view').innerHTML='<section><h2>לא ניתן לטעון את הטיול</h2><p>'+esc(err.message)+'</p><button id="retry">נסה שוב</button></section>';$('#retry').onclick=()=>load().catch(showLoadError);status('המידע מהענן לא נטען.');}
async function load(){if(!session||busy||$('#editor').open)return;const run=++epoch,view=viewEpoch,user=session.user.id;const current=()=>run===epoch&&view===viewEpoch&&session?.user.id===user;status('טוען מהענן…');try{if(!selectedTripId){const rows=await repo.listDestinations();if(!current())return;destinations=rows;trip=null;destinationHome();account();}else{const loaded=await repo.getTrip(selectedTripId);if(!current())return;trip=loaded;render();account();}status('נטען מהענן • '+new Date().toLocaleTimeString('he-IL'))}catch(e){if(current())throw e}}
async function saveOperation(operation){if(busy)return false;const run=epoch;lock(true);status('שומר בענן…');try{await operation();if(run!==epoch||!session)return false;status('נשמר בענן');return true}catch(e){if(run===epoch)status('לא נשמר: '+e.message);return false}finally{lock(false)}}
async function afterSave(){try{await load();status('נשמר בענן')}catch(e){showLoadError(e);status('השינוי נשמר בענן, אך הרענון נכשל. נסה לרענן שוב.')}}
function destinationHome(){
 routeCleanup?.();routeCleanup=null;window.dispatchEvent(new Event('scroll'));$('#tabs').innerHTML='';document.documentElement.style.setProperty('--navigation-space','24px');
 $('#view').innerHTML='<section class="destination-home"><div class="row"><div><h2>לאן יוצאים?</h2><p class="muted">בחר יעד לתכנון המסלול, ההזמנות והמשימות שלך</p></div><button id="add-destination">+ יעד חדש</button></div><div class="destination-grid">'+destinations.map(d=>'<article class="destination-card '+(d.is_active===false?'destination-inactive':'')+'"><span class="badge">'+(d.is_active===false?'לא פעיל':'פעיל')+'</span><h3>'+esc(d.destination_name||d.title)+'</h3><p>'+esc(d.settings.days)+' ימים'+(d.settings.start?' · '+esc(d.settings.start):' · תאריך טרם נקבע')+'</p><div class="row"><button data-destination-open="'+esc(d.id)+'" class="primary">פתח תכנון</button><button data-destination-edit="'+esc(d.id)+'">עריכת יעד</button></div></article>').join('')+'</div>'+(destinations.length?'':'<p>הוסף את היעד הראשון שלך כדי להתחיל.</p>')+'</section>';
 $('#add-destination').onclick=()=>destinationEditor();
 $('#view').querySelectorAll('[data-destination-open]').forEach(b=>b.onclick=()=>{if(busy)return;selectedTripId=b.dataset.destinationOpen;trip=null;tab='stop';categories={place:null,booking:null,task:null};workViews={booking:'stats',task:'stats'};statusFilters={booking:'',task:''};routeView='map';epoch++;viewEpoch++;load().catch(showLoadError)});
 $('#view').querySelectorAll('[data-destination-edit]').forEach(b=>b.onclick=()=>destinationEditor(destinations.find(d=>d.id===b.dataset.destinationEdit)));
}
function destinationEditor(existing){
 viewEpoch++;$('#editor').innerHTML='<form id="destination-form"><h2>'+(existing?'עריכת יעד':'יעד חדש')+'</h2>'+field('destination','שם היעד',existing?.destination_name||'')+field('start','תאריך יציאה',existing?.settings.start||'','date')+field('days','משך הטיול בימים',existing?.settings.days??21,'number')+field('budget','תקציב הטיול הכולל בש״ח',existing?.settings.budget??0,'number')+'<label class="destination-active"><input name="active" type="checkbox" '+(existing?.is_active===false?'':'checked')+'> יעד פעיל</label><p class="muted">יעד לא פעיל נשמר, ואפשר לחזור לתכנון שלו בכל עת. השמירה פותחת את שאלון התכנון; הסוכן יופעל רק לאחר אישור ההרצה.</p><div class="row"><button type="submit" id="plan-destination" class="primary">שמור והמשך לתכנון</button><button type="button" id="cancel-destination">ביטול</button></div><p data-dialog-status role="status" aria-live="polite"></p></form>';
 const form=$('#destination-form');form.elements.destination.required=true;form.elements.destination.maxLength=100;form.elements.days.min=1;form.elements.days.max=365;form.elements.days.step=1;form.elements.days.required=true;form.elements.budget.required=true;
 $('#cancel-destination').onclick=()=>$('#editor').close();
 const saveDestination=async(planning=true)=>{
  const user=session?.user.id,view=++viewEpoch;
  const name=form.elements.destination.value.trim(),active=form.elements.active.checked,settings={...(existing?.settings||{}),start:form.elements.start.value,days:Number(form.elements.days.value),budget:Number(form.elements.budget.value),currency:'ILS'};
  if(!name)return;
  const unchanged=existing&&name===existing.destination_name&&active===existing.is_active&&settings.start===existing.settings.start&&settings.days===existing.settings.days&&settings.budget===existing.settings.budget;
  let savedDestination=existing;
  const okay=planning&&unchanged?true:await saveOperation(async()=>{savedDestination=await(existing?repo.updateDestination(existing.id,existing.version,name,active,settings):repo.createDestination(user,name,active,settings));return savedDestination;});
  if(!okay||session?.user.id!==user||view!==viewEpoch)return;
  existing=savedDestination;
  if(planning){
   const destination=await repo.getTrip(savedDestination.id);
   if(session?.user.id!==user||view!==viewEpoch)return;
   openPlanning({dialog:$('#editor'),destination,api:createPlanningApi(client),onBack:()=>destinationEditor(destination),onPublished:afterSave});
  }else{$('#editor').close();await load();status('היעד נשמר')}
 };
 form.onsubmit=async e=>{e.preventDefault();if(form.reportValidity())try{await saveDestination(true)}catch(err){status(err.message)}};
 $('#editor').showModal();
}
function focusView(){const heading=$('#view h2');if(heading){heading.tabIndex=-1;heading.focus()}}
function render(){
 policyReviewDirty=false;
 routeCleanup?.();routeCleanup=null;
 if(!trip||!session)return;
 viewEpoch++;
 $('#tabs').innerHTML=navigationMarkup(tabs,tab);
 $('#tabs').querySelectorAll('button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render();focusView()});
 if(tab==='agent'){routeCleanup=mountAgentHub({container:$('#view'),trip,api:createPlanningApi(client)});return;}
 if(tab==='dashboard'){
  const bookings=trip.items.filter(x=>x.kind==='booking').map(x=>x.payload),tasks=trip.items.filter(x=>x.kind==='task');
  $('#view').innerHTML='<div class="cards">'+[['תקציב יעד',(trip.settings.budget?money(trip.settings.budget):'טרם נקבע')],['שולם בפועל',money(bookings.reduce((s,x)=>s+Number(x.paid||0),0))],['התחייבויות',money(bookings.filter(x=>['הוזמן','שולם'].includes(x.status)).reduce((s,x)=>s+Number(x.cost||0),0))],['משימות שבוצעו',tasks.filter(x=>x.payload.done).length+'/'+tasks.length]].map(([k,v])=>'<section><small>'+k+'</small><div class="metric">'+v+'</div></section>').join('')+'</div><section><h2>תמונת מצב</h2><p>משך הטיול: '+esc(trip.settings.days)+' ימים | יציאה: '+esc(trip.settings.start||'טרם נקבע')+'</p><p>הנתונים נטענים מחשבונך בענן. חזור לאפליקציה או לחץ על רענן כדי לקבל עדכונים ממכשיר אחר.</p></section>'+completionMarkup(trip.items,trip.settings);return;
 }
 if(tab==='settings'){settings();return}
 let items=trip.items.filter(x=>x.kind===tab);if(tab==='stop')items.sort((a,b)=>a.payload.day-b.payload.day);
 let categoryMenu='',categoryOptions=[];
 if(tab==='stop'){
  categoryMenu='<div class="row" role="group" aria-label="תצוגת מסלול" style="margin:12px 0">'+[['map','מפה'],['list','תוכנית יומית']].map(([id,label])=>'<button type="button" data-route-view="'+id+'" aria-pressed="'+(routeView===id)+'" class="'+(routeView===id?'active':'')+'">'+label+'</button>').join('')+'</div>';
  if(routeView==='map'){
   $('#view').innerHTML='<section><div class="row"><h2>מסלול</h2><button id="add">+ הוסף עצירה</button></div>'+categoryMenu+'<div id="route-map-panel"></div></section>';
   $('#view').querySelectorAll('[data-route-view]').forEach(b=>b.onclick=()=>{routeView=b.dataset.routeView;render();focusView()});
   $('#add').onclick=()=>edit('stop');routeCleanup=mountRouteMap($('#route-map-panel'),items,id=>{routeView='list';render();const card=[...$('#view').querySelectorAll('[data-id]')].find(x=>x.dataset.id===id);const heading=card?.querySelector('h3');if(heading){heading.tabIndex=-1;heading.focus();heading.scrollIntoView?.({block:'start'})}},trip.destination_name);return;
  }
 }
 if(['place','booking','task'].includes(tab)){
  const category=x=>(tab==='task'?x.payload.category:x.payload.type)?.trim()||(tab==='task'?'כללי':'ללא קטגוריה'),counts=new Map();
  items.forEach(x=>counts.set(category(x),(counts.get(category(x))||0)+1));
  if(tab==='booking')for(const p of [...(trip.settings.bookingPolicies||[]),...(trip.settings.bookingPolicyProposals||[])])if(!counts.has(p.category))counts.set(p.category,0);
  if(categories[tab]!==null&&!counts.has(categories[tab]))categories[tab]=null;
  categoryOptions=[null,...[...counts.keys()].sort((a,b)=>a.localeCompare(b,'he'))];
  categoryMenu='<div class="place-filter-bar"><label for="place-category">קטגוריה</label><select id="place-category" aria-label="קטגוריות '+esc(tabs.find(x=>x[0]===tab)[1])+'">'+categoryOptions.map((name,index)=>'<option value="'+index+'" '+(categories[tab]===name?'selected':'')+'>'+esc(name??'הכול')+' ('+(name===null?items.length:counts.get(name))+')</option>').join('')+'</select></div>';
  if(categories[tab]!==null)items=items.filter(x=>category(x)===categories[tab]);
 }
 let workflowMenu='',recordsMarkup='';
 const managed=['booking','task'].includes(tab),statistics=managed&&workViews[tab]==='stats',policyView=tab==='booking'&&workViews.booking==='policies';
 if(managed){workflowMenu='<div class="workflow-views" role="group" aria-label="תצוגת '+esc(tabs.find(x=>x[0]===tab)[1])+'">'+[['current','מצב נוכחי'],['stats','סטטיסטיקות'],...(tab==='booking'?[['policies','מדיניות הזמנה']]:[])].map(([id,label])=>'<button type="button" data-work-view="'+id+'" aria-pressed="'+(workViews[tab]===id)+'" class="'+(workViews[tab]===id?'active':'')+'">'+label+'</button>').join('')+'</div>';
 if(policyView)recordsMarkup=policiesMarkup(trip.items,trip.settings.bookingPolicies||[],categories.booking,trip.settings);
 else if(statistics)recordsMarkup=statisticsMarkup(items);
 else {workflowMenu+='<div class="place-filter-bar"><label for="workflow-filter">סטטוס</label><select id="workflow-filter"><option value="">כל הסטטוסים</option>'+workflowStatuses.map(([id,label])=>'<option value="'+id+'" '+(statusFilters[tab]===id?'selected':'')+'>'+label+' ('+items.filter(x=>workflowStatus(x)===id).length+')</option>').join('')+'</select></div>';if(statusFilters[tab])items=items.filter(x=>workflowStatus(x)===statusFilters[tab]);}
 }
 if(!statistics&&!policyView)recordsMarkup='<div class="cards">'+items.map(x=>recordCard(x,fields[tab],tab==='stop'?lodgingMarkup(x,trip.items,trip.destination_name):tab==='booking'?'<button type="button" data-booking-policy="'+esc(x.payload.type?.trim()||'ללא קטגוריה')+'">אפשרויות מדיניות לאישור</button>':'')).join('')+'</div>'+(items.length?'':'<p>אין פריטים להצגה בסינון הנוכחי.</p>');
 $('#view').innerHTML='<section><div class="row"><h2>'+tabs.find(x=>x[0]===tab)[1]+'</h2><button id="add">'+(policyView?'+ הנחיות לקטגוריה':'+ הוסף פריט')+'</button></div>'+workflowMenu+categoryMenu+recordsMarkup+'</section>';
 $('#view').querySelectorAll('[data-route-view]').forEach(b=>b.onclick=()=>{routeView=b.dataset.routeView;render();focusView()});
 $('#view').querySelectorAll('[data-stat-drill]').forEach(b=>b.onclick=()=>{if(b.dataset.drillCategory!==undefined)categories[tab]=b.dataset.drillCategory;statusFilters[tab]=b.dataset.drillStatus||'';workViews[tab]='current';render();focusView();$('#view h2')?.scrollIntoView?.({block:'start'})});
 $('#view').querySelectorAll('[data-work-view]').forEach(b=>b.onclick=()=>{workViews[tab]=b.dataset.workView;render();$('#view [data-work-view][aria-pressed=true]')?.focus()});
 const statusSelect=$('#workflow-filter');if(statusSelect)statusSelect.onchange=()=>{statusFilters[tab]=statusSelect.value;render();$('#workflow-filter')?.focus()};
 const categorySelect=$('#place-category');if(categorySelect)categorySelect.onchange=()=>{categories[tab]=categoryOptions[Number(categorySelect.value)];render();$('#place-category')?.focus({preventScroll:true})};
 $('#view').querySelectorAll('[data-booking-policy]').forEach(b=>b.onclick=()=>{categories.booking=b.dataset.bookingPolicy;workViews.booking='policies';render();focusView()});
 $('#view').querySelectorAll('[data-policy-review]').forEach(form=>{form.onchange=()=>{policyReviewDirty=true};const review=async(decision)=>{const ids=[...form.querySelectorAll('input[name=option]:checked')].map(x=>x.value);if(decision==='approved'&&!ids.length){form.querySelector('[data-policy-feedback]').textContent='בחר לפחות אפשרות אחת לאישור';return}const okay=await saveOperation(()=>repo.reviewPolicy(trip.id,trip.version,form.dataset.policyReview,ids,decision));if(okay)await afterSave();else form.querySelector('[data-policy-feedback]').textContent=$('#message').textContent;};form.onsubmit=e=>{e.preventDefault();review('approved')};const reject=form.querySelector('[data-reject-policy]');if(reject)reject.onclick=()=>review('rejected')});
 $('#view').querySelectorAll('[data-policy-category]').forEach(b=>b.onclick=()=>policyEditor(b.dataset.policyCategory));
 $('#add').onclick=()=>policyView?policyEditor():edit(tab);
 $('#view').querySelectorAll('[data-id]').forEach(card=>{const item=items.find(x=>x.id===card.dataset.id);card.querySelector('[data-action=edit]').onclick=()=>edit(item.kind,item);card.querySelector('[data-action=delete]').onclick=async()=>{if(!confirm('למחוק את הפריט מהענן ומכל המכשירים?'))return;if(await saveOperation(()=>repo.deleteItem(item.id,item.version)))await afterSave()};const cb=card.querySelector('input[type=checkbox]');if(cb)cb.onchange=async()=>{const done=cb.checked;if(await saveOperation(()=>repo.updateItem(item.id,item.version,item.kind,{...item.payload,done,workflowStatus:done?'completed':'opened',workflowUpdatedAt:new Date().toISOString(),workflowUpdatedBy:'user'})))await afterSave();else cb.checked=workflowStatus(item)==='completed'}});
}
function policyEditor(category=''){
 viewEpoch++;const existing=(trip.settings.bookingPolicies||[]).find(p=>p.category===category);const tripId=trip.id,version=trip.version,settings=structuredClone(trip.settings);
 $('#editor').innerHTML='<form id="policy-form"><h2>הנחיות ראשוניות לסוכן</h2>'+field('category','קטגוריה',category)+'<div id="policy-fields">'+policyFormMarkup(category,existing)+'</div><p class="muted">הסוכן ימצא אפשרויות לפי ההנחיות, ויציג אותן לאישורך. התקציב נגזר מתקציב הטיול הכולל.</p><div class="row form-actions"><button type="submit">שמור הנחיות</button><button type="button" id="cancel-policy">ביטול</button></div><p data-dialog-status role="status" aria-live="polite"></p></form>';
 const form=$('#policy-form');form.elements.category.required=true;form.elements.category.maxLength=100;if(existing)form.elements.category.readOnly=true;
 const read=()=>{const fd=new FormData(form),input={category:fd.get('category').trim(),updatedAt:new Date().toISOString()};for(const f of policyFields(input.category)){const v=fd.get(f.key);input[f.key]=f.type==='number'?(v===null||v===''?null:Number(v)):v??''}return input};
 form.elements.category.onchange=()=>{const values=read();$('#policy-fields').innerHTML=policyFormMarkup(form.elements.category.value,values)};
 $('#cancel-policy').onclick=()=>$('#editor').close();form.onsubmit=async e=>{e.preventDefault();let policy;try{policy=validatePolicy(read())}catch(err){status(err.message);return}const policies=structuredClone(settings.bookingPolicies||[]);const match=policies.findIndex(p=>p.category.toLowerCase()===policy.category.toLowerCase());if(!existing&&match>=0){status('כבר קיימת מדיניות לקטגוריה זו. פתח אותה לעריכה.');return}if(match>=0)policies[match]=policy;else policies.push(policy);if(await saveOperation(()=>repo.updateSettings(tripId,version,{...settings,bookingPolicies:policies}))){$('#editor').close();await afterSave()}};$('#editor').showModal();
}
function edit(kind,existing){
 viewEpoch++;
 const item=existing?structuredClone(existing):{id:crypto.randomUUID(),kind,payload:['place','booking','task'].includes(kind)&&categories[kind]!==null?{[kind==='task'?'category':'type']:categories[kind]==='ללא קטגוריה'?'':categories[kind]}:{}};
 $('#editor').innerHTML='<form><h2>'+(existing?'עריכת פריט':'הוספת פריט')+'</h2>'+fields[kind].map(([k,t,type])=>field(k,t,item.payload[k]??(type==='workflow'?workflowStatus(item):(type==='number'?(k==='day'?1:0):'')),type)).join('')+'<div class="row form-actions"><button type="submit">שמור בענן</button><button type="button" id="cancel">ביטול</button></div><p data-dialog-status role="status" aria-live="polite"></p><p class="form-hint">השינויים יישמרו בחשבונך בענן.</p></form>';
 $('#cancel').onclick=()=>$('#editor').close();
 $('#editor form').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target),payload={...item.payload};for(const [k,t,type] of fields[kind])payload[k]=type==='number'?Number(fd.get(k)):fd.get(k);if(['booking','task'].includes(kind)){if(!existing||payload.workflowStatus!==workflowStatus(item)){payload.workflowUpdatedAt=new Date().toISOString();payload.workflowUpdatedBy='user';}if(kind==='task')payload.done=payload.workflowStatus==='completed';}const okay=await saveOperation(()=>existing?repo.updateItem(item.id,item.version,kind,payload):repo.createItem(trip.id,{...item,payload}));if(okay){$('#editor').close();await afterSave()}};
 $('#editor').showModal();
}
function download(text){const url=URL.createObjectURL(new Blob([text],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='motor-trip-'+(trip?.destination_name||'destination')+'-backup.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function preview(parsed){
 const plan=previewImport(trip.items,parsed.items);const tripId=trip.id;
 $('#editor').innerHTML='<h2>תצוגה מקדימה לייבוא</h2><p>פריטים חדשים: '+plan.add.length+' | פריטים קיימים שיישארו ללא שינוי: '+plan.skip.length+'</p><p>הגדרות הטיול והמידע הקיים לא יוחלפו.</p><ul>'+plan.add.map(x=>'<li>'+esc(x.payload.place??x.payload.name??x.payload.title)+'</li>').join('')+'</ul><div class="row"><button id="confirmimport">הוסף פריטים לענן</button><button id="cancelimport">ביטול</button></div>';
 $('#cancelimport').onclick=()=>$('#editor').close();$('#confirmimport').onclick=async()=>{if(await saveOperation(()=>repo.importItems(tripId,plan.add))){$('#editor').close();await afterSave()}};$('#editor').showModal();
}
function settings(){
 $('#view').innerHTML='<section><h2>גיבוי והעברת נתונים</h2><p>המידע נשמר בחשבונך בענן. מומלץ להוריד גיבוי לפני שינויים גדולים.</p><button id="export">יצוא גיבוי JSON</button><label>יבוא גיבוי JSON<input id="import" type="file" accept="application/json,.json"></label><button id="localimport">העבר נתונים מהגרסה המקומית במכשיר זה</button><p>הייבוא מוסיף פריטים חדשים לאחר תצוגה מקדימה. הוא אינו מוחק או מחליף פריטים קיימים.</p></section>'; $('#export').onclick=()=>download(exportTrip(trip));
 $('#import').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>5_000_000)throw Error('קובץ גדול מדי');preview(parseBackup(await f.text()))}catch(err){status('הייבוא לא בוצע: '+err.message)}finally{e.target.value=''}};
 $('#localimport').onclick=()=>{try{const old=localStorage.getItem('thailand_moto_trip_v1');if(!old)throw Error('לא נמצאו נתונים מקומיים במכשיר זה');preview(parseBackup(old))}catch(e){status('הייבוא לא בוצע: '+e.message)}};
}
async function applySession(next){const previous=session?.user.id;if(!next){wipe();login();return}if(previous!==next.user.id){wipe();tab='stop'}session=next;account();if(!trip){$('#view').textContent='טוען מהענן…';try{await load()}catch(e){showLoadError(e)}}}
auth.onChange((next,event)=>{authVersion++;applySession(next).then(()=>{if(event==='PASSWORD_RECOVERY'&&session)passwordEditor()}).catch(e=>status(e.message))});
document.addEventListener('input',()=>viewEpoch++);
$('#editor').addEventListener('cancel',e=>{if(busy)e.preventDefault()});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&!policyReviewDirty&&session&&!busy&&tab!=='settings'&&!$('#editor').open)load().catch(showLoadError)});
auth.session().then(next=>{if(authVersion===0)return applySession(next)}).catch(e=>{if(authVersion!==0)return;wipe();login();status('בדיקת ההתחברות נכשלה: '+e.message)});

if(typeof ResizeObserver==='function'){
 const navigationObserver=new ResizeObserver(entries=>{const height=entries[0]?.borderBoxSize?.[0]?.blockSize??$('#tabs').getBoundingClientRect().height;document.documentElement.style.setProperty('--navigation-space',Math.ceil(height)+28+'px')});
 navigationObserver.observe($('#tabs'));
}

// Refresh agent status updates while a managed view is open; never replace an editor draft.
window.setInterval(()=>{if(session&&trip&&!policyReviewDirty&&!busy&&['booking','task'].includes(tab)&&!$('#editor').open&&document.visibilityState==='visible')load().catch(e=>status('לא ניתן לרענן סטטוסים: '+e.message))},30000);

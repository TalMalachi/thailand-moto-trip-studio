export function popupDimensions(width,height){
 const maxWidth=Math.max(80,Math.min(340,(width||320)-70)),maxHeight=Math.max(80,(height||340)-110);
 return {maxWidth,maxHeight,minWidth:Math.min(120,maxWidth)};
}

export const collections={booking:'bookings',stop:'stops',place:'places',gear:'gear',task:'tasks'};
const keys={booking:['name','type','status','supplier','cost','paid','ref','url','notes'],stop:['day','place','kind','url','notes','lat','lng'],place:['name','type','area','url','notes'],gear:['name','category','status','url','guide','notes'],task:['title','done']};
export function validatePayload(kind,input){
  if(!keys[kind]||!input||typeof input!=='object'||Array.isArray(input))throw Error('Invalid item');
  const out={};
  for(const key of keys[kind]){
    const v=input[key];
    if(key==='lat'||key==='lng')continue;
    if(key==='done'){if(v!==undefined&&typeof v!=='boolean')throw Error('Invalid task state');out[key]=v??false;continue}
    if(['day','cost','paid'].includes(key)){const n=v??(key==='day'?1:0);if(typeof n!=='number'||!Number.isFinite(n)||n<0||(key==='day'&&(!Number.isInteger(n)||n<1||n>365)))throw Error('Invalid number');out[key]=n;continue}
    if(v!==undefined&&typeof v!=='string')throw Error('Invalid text');out[key]=v??'';
    if(out[key].length>10000)throw Error('Text too long');
    if(['url','guide'].includes(key)&&out[key]){let u;try{u=new URL(out[key])}catch{throw Error('Invalid URL')}if(!['https:','http:'].includes(u.protocol))throw Error('Unsafe URL')}
  }
  if(kind==='stop'){const lat=input.lat??'',lng=input.lng??'';if(typeof lat!=='string'||typeof lng!=='string')throw Error('Invalid coordinates');if(lat.trim()||lng.trim()){if(!lat.trim()||!lng.trim()||!Number.isFinite(Number(lat))||!Number.isFinite(Number(lng))||Math.abs(Number(lat))>90||Math.abs(Number(lng))>180)throw Error('קואורדינטות לא תקינות');out.lat=lat.trim();out.lng=lng.trim()}}
  const title=kind==='stop'?out.place:kind==='task'?out.title:out.name;
  if(!title?.trim())throw Error('Missing item title');
  return out;
}
export function validateSettings(s){
  if(!s||typeof s!=='object'||Array.isArray(s))throw Error('Invalid settings');
  const {start='',days=21,budget=0,currency='ILS'}=s;
  if(typeof start!=='string'||(start&&!/^\d{4}-\d{2}-\d{2}$/.test(start))||!Number.isInteger(days)||days<1||days>365||typeof budget!=='number'||!Number.isFinite(budget)||budget<0||currency!=='ILS')throw Error('Invalid settings');
  return {start,days,budget,currency};
}
export function parseBackup(text){
  if(typeof text!=='string'||text.length>5_000_000)throw Error('Backup too large');
  const p=JSON.parse(text);if(!p||typeof p!=='object'||Array.isArray(p))throw Error('Invalid backup');
  if(p.schemaVersion!==undefined&&![1,2].includes(p.schemaVersion))throw Error('Unsupported version');
  const d=p.data??p;const settings=validateSettings(d.settings);let items=[];
  if(p.schemaVersion===2){if(!Array.isArray(d.items))throw Error('Invalid items');items=d.items.map(x=>({kind:x.kind,legacy_id:x.legacy_id??x.id,payload:validatePayload(x.kind,x.payload)}))}
  else for(const [kind,name] of Object.entries(collections)){if(!Array.isArray(d[name]))throw Error('Missing collection');items.push(...d[name].map(x=>({kind,legacy_id:x?.id,payload:validatePayload(kind,x)})))}
  if(items.length>5000)throw Error('Too many items');const seen=new Set();
  for(const x of items){if(typeof x.legacy_id!=='string'||!x.legacy_id.length||x.legacy_id.length>200)throw Error('Invalid source ID');const id=JSON.stringify([x.kind,x.legacy_id]);if(seen.has(id))throw Error('Duplicate source ID');seen.add(id)}
  return {settings,items};
}
export function previewImport(existing,incoming){const ids=new Set(existing.map(x=>JSON.stringify([x.kind,x.legacy_id??x.id])));return {add:incoming.filter(x=>!ids.has(JSON.stringify([x.kind,x.legacy_id]))),skip:incoming.filter(x=>ids.has(JSON.stringify([x.kind,x.legacy_id])))}}
export function exportTrip(trip){return JSON.stringify({schemaVersion:2,exportedAt:new Date().toISOString(),data:{settings:trip.settings,items:trip.items.map(x=>({id:x.id,legacy_id:x.legacy_id??x.id,kind:x.kind,payload:x.payload}))}},null,2)}

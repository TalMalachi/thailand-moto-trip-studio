alter table app_private.admin_auth_attempts add column client_key text not null default '';
alter table app_private.admin_auth_attempts drop constraint admin_auth_attempts_pkey;
alter table app_private.admin_auth_attempts add primary key(slot,kind,client_key);
drop function public.admin_auth_target(text,text);
drop function app_private.admin_auth_target(text,text);
create function app_private.admin_auth_target(p_username text,p_action text,p_client_key text) returns jsonb language plpgsql security definer set search_path='' as $$declare slot_key timestamptz;attempts integer;maximum integer;result jsonb;begin
 if p_client_key is null or p_client_key !~ '^[0-9a-f]{64}$' then raise check_violation;end if;
 if p_action not in ('signin','reset') or p_action is null then raise check_violation;end if;
 slot_key=to_timestamp(floor(extract(epoch from now())/case when p_action='reset' then 3600 else 900 end)*case when p_action='reset' then 3600 else 900 end);maximum=case when p_action='reset' then 3 else 10 end;
 delete from app_private.admin_auth_attempts where slot<now()-interval '2 days';
 insert into app_private.admin_auth_attempts(slot,kind,hits,client_key) values(slot_key,p_action,1,p_client_key) on conflict(slot,kind,client_key) do update set hits=admin_auth_attempts.hits+1 returning hits into attempts;
 if attempts>maximum then return null;end if;
 select jsonb_build_object('userId',u.id,'email',u.email) into result from app_private.admin_login_aliases x join app_private.superusers s on s.user_id=x.user_id join public.account_access a on a.user_id=s.user_id join auth.users u on u.id=s.user_id where x.username=lower(trim(p_username)) and a.status='active' and u.email_confirmed_at is not null;
 return result;end $$;
create function public.admin_auth_target(p_username text,p_action text,p_client_key text) returns jsonb language sql security invoker set search_path='' as $$select app_private.admin_auth_target(p_username,p_action,p_client_key)$$;
revoke all on function app_private.admin_auth_target(text,text,text),public.admin_auth_target(text,text,text) from public,anon,authenticated;
grant execute on function app_private.admin_auth_target(text,text,text),public.admin_auth_target(text,text,text) to service_role;

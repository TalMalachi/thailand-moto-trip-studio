create or replace function public.review_booking_policy(p_trip_id uuid,p_expected_version bigint,p_proposal_id text,p_selected_ids jsonb,p_decision text)
returns setof public.trips language plpgsql security invoker set search_path='' as $$
declare t public.trips; proposal jsonb; proposals jsonb; category text; share numeric; other_shares numeric;
begin
 if p_decision not in ('approved','rejected') then raise exception 'Invalid policy decision';end if;
 select * into t from public.trips where id=p_trip_id and version=p_expected_version for update;
 if not found then return;end if;
 proposals=coalesce(t.settings->'bookingPolicyProposals','[]'::jsonb);
 if (select count(*) from jsonb_array_elements(proposals) p where p->>'id'=p_proposal_id)<>1 then raise exception 'Policy proposal not found';end if;
 select p into proposal from jsonb_array_elements(proposals) p where p->>'id'=p_proposal_id;
 if proposal->>'state' not in ('policy_updated','awaiting_approval') then raise exception 'Policy proposal already reviewed';end if;
 category=proposal->>'category';
 if (select p->>'id' from jsonb_array_elements(proposals) with ordinality x(p,n) where p->>'category'=category order by n desc limit 1)<>p_proposal_id then raise exception 'Policy proposal superseded';end if;
 if exists(select 1 from jsonb_array_elements_text(coalesce(proposal->'bookingIds','[]'::jsonb)) b where not exists(select 1 from public.trip_items i where i.id::text=b and i.trip_id=p_trip_id and i.kind='booking' and coalesce(nullif(trim(i.payload->>'type'),''),'ללא קטגוריה')=category)) then raise exception 'Proposal booking does not match destination and category';end if;
 if p_decision='approved' then
  if jsonb_typeof(p_selected_ids)<>'array' or jsonb_array_length(p_selected_ids)=0 then raise exception 'Select at least one option';end if;
  if exists(select 1 from jsonb_array_elements_text(p_selected_ids) s where not exists(select 1 from jsonb_array_elements(proposal->'options') o where o->>'id'=s)) then raise exception 'Unknown policy option';end if;
  if (select count(*) from jsonb_array_elements_text(p_selected_ids))<>(select count(distinct s) from jsonb_array_elements_text(p_selected_ids) s) then raise exception 'Duplicate selected option';end if;
  share=nullif(proposal->>'budgetSharePct','')::numeric;
  if share is not null and (share<0 or share>100) then raise exception 'Invalid budget share';end if;
  select coalesce(sum(nullif(p->>'budgetSharePct','')::numeric),0) into other_shares from (select distinct on (p->>'category') p from jsonb_array_elements(proposals) with ordinality x(p,n) where p->>'category'<>category and p->>'state'='approved' order by p->>'category',n desc) latest;
  if coalesce(share,0)+other_shares>100 then raise exception 'Category allocations exceed 100 percent of the trip budget';end if;
 else p_selected_ids='[]'::jsonb;end if;
 proposal=proposal||jsonb_build_object('state',p_decision,'approvedOptionIds',p_selected_ids,'reviewedAt',now());
 select jsonb_agg(case when p->>'id'=p_proposal_id then proposal else p end order by n) into proposals from jsonb_array_elements(proposals) with ordinality x(p,n);
 update public.trips set settings=jsonb_set(settings,'{bookingPolicyProposals}',proposals),version=version+1 where id=p_trip_id;
 update public.trip_items set payload=payload||jsonb_build_object('workflowStatus',case when p_decision='approved' then 'updated' else 'rejected' end,'workflowUpdatedBy','user','workflowUpdatedAt',now()),version=version+1 where trip_id=p_trip_id and kind='booking' and id::text in(select jsonb_array_elements_text(coalesce(proposal->'bookingIds','[]'::jsonb))) and payload->>'workflowStatus' in ('policy_updated','awaiting_approval');
 return query select * from public.trips where id=p_trip_id;
end $$;
revoke all on function public.review_booking_policy(uuid,bigint,text,jsonb,text) from public,anon;
grant execute on function public.review_booking_policy(uuid,bigint,text,jsonb,text) to authenticated;

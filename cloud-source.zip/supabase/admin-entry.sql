create table app_private.admin_login_aliases(username text primary key check(username='admin'),user_id uuid not null unique references app_private.superusers(user_id) on delete cascade);
alter table app_private.admin_login_aliases enable row level security;
revoke all on app_private.admin_login_aliases from public,anon,authenticated;
grant all on app_private.admin_login_aliases to service_role;
do $$begin
 if (select count(*) from app_private.superusers s join public.account_access a on a.user_id=s.user_id where a.status='active')<>1 then raise exception 'Explicit administrator alias selection required';end if;
 insert into app_private.admin_login_aliases(username,user_id) select 'admin',s.user_id from app_private.superusers s join public.account_access a on a.user_id=s.user_id where a.status='active';end $$;
create function app_private.admin_finance() returns jsonb language plpgsql security definer set search_path='' as $$begin
 perform app_private.admin_uid();return jsonb_build_object('accounts',(select count(*) from public.account_access),'activeAccounts',(select count(*) from public.account_access where status='active'),'pendingAccounts',(select count(*) from public.account_access where status='pending'),'paidOrders',(select count(*) from app_private.orders where state='paid'),'revenueAgorot',(select coalesce(sum(v.price_agorot),0) from app_private.orders o join app_private.package_versions v on v.id=o.package_id where o.state='paid'),'monthAiSpentAgorot',(select coalesce(sum(spent_agorot),0) from planner_private.monthly_budget where month=planner_private.month_key()),'monthAiReservedAgorot',(select coalesce(sum(reserved_agorot),0) from planner_private.monthly_budget where month=planner_private.month_key()),'orders',(select coalesce(jsonb_agg(x),'[]') from (select o.id,u.email,t.destination_name,o.state,v.price_agorot,v.ai_runs,o.created_at,o.paid_at from app_private.orders o join app_private.package_versions v on v.id=o.package_id join auth.users u on u.id=o.owner_id join public.trips t on t.id=o.trip_id order by o.created_at desc,o.id limit 50)x));end $$;
create function public.admin_finance_overview() returns jsonb language sql security invoker set search_path='' as $$select app_private.admin_finance()$$;
revoke all on function app_private.admin_finance(),public.admin_finance_overview() from public,anon;
grant execute on function app_private.admin_finance(),public.admin_finance_overview() to authenticated;

create table app_private.admin_auth_attempts(slot timestamptz not null,kind text not null,hits integer not null,client_key text not null,primary key(slot,kind,client_key));
alter table app_private.admin_auth_attempts enable row level security;
revoke all on app_private.admin_auth_attempts from public,anon,authenticated;
grant all on app_private.admin_auth_attempts to service_role;
create function app_private.admin_auth_target(p_username text,p_action text,p_client_key text) returns jsonb language plpgsql security definer set search_path='' as $$declare slot_key timestamptz;attempts integer;maximum integer;result jsonb;begin
 if p_client_key is null or p_client_key !~ '^[0-9a-f]{64}$' then raise check_violation;end if;
 if p_action not in ('signin','reset') or p_action is null then raise check_violation;end if;
 slot_key=to_timestamp(floor(extract(epoch from now())/case when p_action='reset' then 3600 else 900 end)*case when p_action='reset' then 3600 else 900 end);maximum=case when p_action='reset' then 3 else 10 end;
 delete from app_private.admin_auth_attempts where slot<now()-interval '2 days';
 insert into app_private.admin_auth_attempts(slot,kind,hits,client_key) values(slot_key,p_action,1,p_client_key) on conflict(slot,kind,client_key) do update set hits=admin_auth_attempts.hits+1 returning hits into attempts;
 if attempts>maximum then return null;end if;
 select jsonb_build_object('userId',u.id,'email',u.email) into result from app_private.admin_login_aliases x join app_private.superusers s on s.user_id=x.user_id join public.account_access a on a.user_id=s.user_id join auth.users u on u.id=s.user_id where x.username=lower(trim(p_username)) and a.status='active' and u.email_confirmed_at is not null;
 return result;end $$;
create function public.admin_auth_target(p_username text,p_action text,p_client_key text) returns jsonb language sql security invoker set search_path='' as $$select app_private.admin_auth_target(p_username,p_action,p_client_key)$$;
revoke all on function app_private.admin_auth_target(text,text,text),public.admin_auth_target(text,text,text) from public,anon,authenticated;
grant execute on function app_private.admin_auth_target(text,text,text),public.admin_auth_target(text,text,text) to service_role;

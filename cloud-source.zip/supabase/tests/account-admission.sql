begin;
do $$declare uid uuid;begin
 select s.user_id into uid from app_private.superusers s join public.account_access a on a.user_id=s.user_id where a.status='active' limit 1;
 perform set_config('request.jwt.claim.sub',uid::text,true);
 perform app_private.active_uid();
 if not exists(select 1 from pg_locks where pid=pg_backend_pid() and relation='public.account_access'::regclass and mode='RowShareLock' and granted) then raise exception 'Run admission does not retain account row lock against concurrent suspension';end if;
end $$;
rollback;
select 'PASS active admission retains account lock until transaction completion' result;

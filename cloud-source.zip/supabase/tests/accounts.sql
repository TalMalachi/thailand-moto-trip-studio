begin;
insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data) values
 ('71000000-0000-4000-8000-000000000001','account-fixture@example.invalid',now(),'{"role":"superuser","status":"active"}'),
 ('71000000-0000-4000-8000-000000000002','account-other@example.invalid',now(),'{}');
insert into public.trips(id,owner_id,destination_name) values('72000000-0000-4000-8000-000000000001','71000000-0000-4000-8000-000000000001','account fixture');
set local role authenticated;
select set_config('request.jwt.claim.sub','71000000-0000-4000-8000-000000000001',true);
do $$begin
 if public.account_state()->>'status'<>'pending' then raise exception 'Metadata granted activation';end if;
 if (public.account_state()->>'isSuperuser')::boolean then raise exception 'Metadata granted superuser';end if;
 if exists(select 1 from public.trips) then raise exception 'Pending account read business data';end if;
 begin perform public.account_assert_active();raise exception 'Pending assert allowed';exception when insufficient_privilege then null;end;
 begin perform public.admin_accounts(0,'');raise exception 'Non-admin listed accounts';exception when insufficient_privilege then null;end;
 begin perform public.planner_overview('72000000-0000-4000-8000-000000000001');raise exception 'Pending planner definer allowed';exception when insufficient_privilege then null;end;
 begin update public.account_access set status='active' where user_id=auth.uid();raise exception 'Self activation allowed';exception when insufficient_privilege then null;end;
 if (select count(*) from public.account_access)<>1 then raise exception 'Foreign status leaked';end if;
end $$;
reset role;
update public.account_access set status='active' where user_id='71000000-0000-4000-8000-000000000001';
set local role authenticated;
do $$begin
 if (select count(*) from public.trips)<>1 then raise exception 'Active owner isolation failed';end if;
 perform public.account_assert_active();
end $$;
reset role;
update public.account_access set status='suspended' where user_id='71000000-0000-4000-8000-000000000001';
set local role authenticated;
do $$begin
 if exists(select 1 from public.trips) then raise exception 'Old JWT retained business access';end if;
 begin perform public.planner_overview('72000000-0000-4000-8000-000000000001');raise exception 'Suspended planner allowed';exception when insufficient_privilege then null;end;
 begin insert into public.trips(owner_id,destination_name) values(auth.uid(),'blocked');raise exception 'Suspended insert allowed';exception when insufficient_privilege then null;end;
end $$;
reset role;
do $$declare uid uuid;v bigint;begin
 select s.user_id,a.version into uid,v from app_private.superusers s join public.account_access a on a.user_id=s.user_id where a.status='active' limit 1;
 perform set_config('request.jwt.claim.sub',uid::text,true);
 begin perform public.admin_account_status(uid,v,'suspended','fixture');raise exception 'Last admin lockout allowed';exception when check_violation then null;end;
 if has_function_privilege('anon','public.account_state()','execute') then raise exception 'Anon account RPC allowed';end if;
 if has_table_privilege('authenticated','app_private.superusers','select') then raise exception 'Private roles exposed';end if;
end $$;
rollback;
select 'PASS account status, old JWT, owner isolation, metadata escalation, last admin, and RPC gates; fixtures rolled back' result;

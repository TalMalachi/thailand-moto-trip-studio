begin;
do $$declare t public.trips;uid uuid;inp jsonb;r public.planner_runs;b public.trip_items;c uuid;q uuid;failed boolean;localday date=(now() at time zone 'Asia/Jerusalem')::date;begin
 select * into t from public.trips where exists(select 1 from public.planner_runs where trip_id=trips.id and purpose='plan') order by created_at limit 1;uid=t.owner_id;
 perform set_config('request.jwt.claim.sub',uid::text,true);perform set_config('request.jwt.claims',jsonb_build_object('sub',uid)::text,true);
 perform planner_private.daily_control(t.id,'enable',t.version);
 -- Enabling before08 must still wait for tomorrow, matching the UI promise.
 update public.agent_daily_settings set updated_at=((localday::text||' 07:00 Asia/Jerusalem')::timestamptz) where trip_id=t.id;
 perform planner_private.daily_tick_at((localday::text||' 08:00 Asia/Jerusalem')::timestamptz);
 if exists(select 1 from public.agent_daily_checks where trip_id=t.id) then raise exception 'Enabled at07 but ran same-day08 despite tomorrow promise';end if;
 update public.agent_daily_settings set updated_at=now()-interval '3 days' where trip_id=t.id;
 update planner_private.runtime set ready_until=now()-interval '1 day' where singleton;
 if not planner_private.daily_due((localday::text||' 08:00 Asia/Jerusalem')::timestamptz) then raise exception 'Expired readiness prevents autonomous wake';end if;
 update planner_private.runtime set ready_until=now()+interval '1 hour' where singleton;
 perform planner_private.daily_tick_at((localday::text||' 08:00 Asia/Jerusalem')::timestamptz);
 select * into r from public.planner_runs where trip_id=t.id and purpose='daily' order by created_at desc limit 1;
 if r.id is null then raise exception 'Need daily run';end if;select id into c from public.agent_daily_checks where run_id=r.id;
 select * into b from public.trip_items where trip_id=t.id and kind='booking' and coalesce(payload->>'status','') not in ('הוזמן','שולם') limit 1;
 -- Completed research may not produce fresh approvals after sitting paused for days.
 update public.planner_runs set state='ready',artifact=jsonb_build_object('kind','daily_review','researchedAt',(now()-interval '2 days')::text,'summary','TEST','checks',jsonb_build_array(jsonb_build_object('bookingId',b.id,'bookingVersion',b.version,'category','TEST','offers',jsonb_build_array(jsonb_build_object('totalCost',1,'url','https://example.com','sourceUrl','https://example.com'))))) where id=r.id;
 perform planner_private.daily_finalize(r.id);
 if exists(select 1 from public.agent_booking_requests where check_id=c) then raise exception 'Old paused research became a fresh approval';end if;
 -- Trip edits fence both materialization and approval, even when the booking row is unchanged.
 update public.planner_runs set state='ready',artifact=jsonb_set(artifact,'{researchedAt}',to_jsonb(now()::text)) where id=r.id;
 update public.agent_daily_checks set state='queued' where id=c;
 update public.trips set settings=settings||jsonb_build_object('start','2027-02-01'),version=version+1 where id=t.id;
 perform planner_private.daily_finalize(r.id);
 if exists(select 1 from public.agent_booking_requests where check_id=c) then raise exception 'Published research for outdated trip dates';end if;
 -- Recreate a request from before the edit; owner review must reject it.
 insert into public.agent_booking_requests(trip_id,owner_id,check_id,booking_id,booking_version,trip_version,offer) values(t.id,uid,c,b.id,b.version,t.version,jsonb_build_object('totalCost',1)) returning id into q;
 failed=false;begin perform planner_private.daily_review(q,1,'approved');exception when others then failed=true;end;if not failed then raise exception 'Approved outdated trip dates';end if;
 -- Cancellation may be reported before provider settlement; later accounting must refresh the same report.
 update public.planner_runs set state='cancelled',spent_agorot=0,reserved_agorot=445 where id=r.id;
 update public.agent_daily_checks set state='queued' where id=c;perform planner_private.daily_finalize(r.id);
 update public.planner_runs set spent_agorot=9,reserved_agorot=0,message='בוטל; העלות אומתה' where id=r.id;perform planner_private.daily_finalize(r.id);
 if (select (report->>'spentAgorot')::integer from public.agent_daily_checks where id=c)<>9 or (select (report->>'reservedAgorot')::integer from public.agent_daily_checks where id=c)<>0 then raise exception 'Cancellation report accounting frozen before settlement';end if;
end $$;
select 'PASS: tomorrow activation, autonomous readiness bootstrap, expired research, trip revision fences, late cancellation cost settlement' result;
rollback;

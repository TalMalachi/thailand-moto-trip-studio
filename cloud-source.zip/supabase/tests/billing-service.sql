begin;
insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data) values('91000000-0000-4000-8000-000000000001','service-fixture@example.invalid',now(),'{"profile":{"name":"fixture","phone":"0500000000","street":"fixture","city":"fixture","postcode":"12345","country":"ישראל"}}');
insert into app_private.package_versions(id,name,price_agorot,ai_runs,created_by) values('92000000-0000-4000-8000-000000000001','fixture',100,1,'91000000-0000-4000-8000-000000000001');
update app_private.billing_config set gateway_enabled=true,package_id='92000000-0000-4000-8000-000000000001' where singleton;
set local role service_role;
do $$declare o jsonb;oid uuid;lp uuid=gen_random_uuid();c jsonb;begin
 o=public.billing_prepare('91000000-0000-4000-8000-000000000001','92000000-0000-4000-8000-000000000001',null,'service fixture','per-trip-v1');oid=(o->'order'->>'id')::uuid;
 perform public.billing_page(oid,lp,'https://secure.cardcom.solutions/EA/fixture');c=public.billing_claim(oid,lp,null);
 perform public.billing_confirm(oid,(c->>'fence')::uuid,lp,'991100003',100);
end $$;
reset role;
rollback;
select 'PASS real service_role can create, verify and settle payment without broad auth.users privileges; fixtures rolled back' result;

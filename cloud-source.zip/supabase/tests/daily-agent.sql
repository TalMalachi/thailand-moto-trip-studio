begin;
-- Every fixture uses an existing owner only inside this rolled-back transaction.
do $$declare uid uuid;t public.trips;inp jsonb;r public.planner_runs;b public.trip_items;checkid uuid;q uuid;otherq uuid;v jsonb;cost numeric;due timestamptz;failed boolean;begin
 select * into t from public.trips where exists(select 1 from public.planner_runs where trip_id=trips.id and purpose='plan') order by created_at limit 1;
 uid=t.owner_id;select input into inp from public.planner_runs where trip_id=t.id and purpose='plan' order by created_at desc limit 1;
 perform set_config('request.jwt.claim.sub',uid::text,true);perform set_config('request.jwt.claims',jsonb_build_object('sub',uid)::text,true);
 if planner_private.daily_overview(t.id)->'schedule'<>'null'::jsonb then raise exception 'Fixture requires schedule stopped';end if;
 perform planner_private.daily_control(t.id,'enable',t.version);
 update public.agent_daily_settings set updated_at=now()-interval '3 days' where trip_id=t.id;
 due=date_trunc('day',now() at time zone 'Asia/Jerusalem') at time zone 'Asia/Jerusalem';
 perform planner_private.daily_tick_at(due+interval '7 hours 59 minutes');
 if exists(select 1 from public.agent_daily_checks where trip_id=t.id) then raise exception 'Ran before 08:00';end if;
 -- Force readiness only for a rollback fixture; never call scheduler_tick/net/provider.
 update planner_private.runtime set ready_until=now()+interval '1 hour' where singleton;
 perform planner_private.daily_tick_at(due+interval '8 hours');
 select * into r from public.planner_runs where trip_id=t.id and purpose='daily' order by created_at desc limit 1;
 if r.id is null or r.state<>'queued' then raise exception 'Daily start failed: %',(select report from public.agent_daily_checks where trip_id=t.id);end if;
 select id into checkid from public.agent_daily_checks where run_id=r.id;
 perform planner_private.daily_tick_at(due+interval '8 hours 1 minute');
 if (select count(*) from public.agent_daily_checks where trip_id=t.id)<>1 then raise exception 'Duplicate daily report';end if;
 if (select count(*) from public.planner_runs where trip_id=t.id and purpose='daily')<>1 then raise exception 'Duplicate paid reservation';end if;
 if planner_private.overview(t.id)->'run'->>'purpose'<>'plan' then raise exception 'Daily artifact leaked into plan wizard';end if;
 select * into b from public.trip_items where trip_id=t.id and kind='booking' and coalesce(payload->>'status','') not in ('הוזמן','שולם') limit 1;
 if b.id is null then raise exception 'Need outstanding booking fixture';end if;
 update public.planner_runs set state='ready',artifact=jsonb_build_object('kind','daily_review','summary','TEST ONLY','checks',jsonb_build_array(jsonb_build_object('bookingId',b.id,'bookingVersion',b.version,'category','test','offers',jsonb_build_array(jsonb_build_object('supplier','TEST','label','TEST','totalCost',1,'url','https://example.com','sourceUrl','https://example.com','details','TEST'))))) where id=r.id;
 perform planner_private.daily_control(t.id,'pause',t.version);perform planner_private.daily_finalize(r.id);
 if exists(select 1 from public.agent_booking_requests where check_id=checkid) then raise exception 'Published during pause';end if;
 if (select state from public.agent_daily_checks where id=checkid)<>'awaiting_resume' then raise exception 'Lost paused result';end if;
 perform planner_private.daily_control(t.id,'resume',t.version);perform planner_private.daily_finalize(r.id);perform planner_private.daily_finalize(r.id);
 if (select count(*) from public.agent_booking_requests where check_id=checkid)<>1 then raise exception 'Finalizer not idempotent';end if;
 select id into q from public.agent_booking_requests where check_id=checkid;
 -- Stale and expired decisions rejected.
 update public.agent_booking_requests set booking_version=booking_version+1 where id=q;failed=false;begin perform planner_private.daily_review(q,1,'approved');exception when others then failed=true;end;if not failed then raise exception 'Stale approval accepted';end if;
 update public.agent_booking_requests set booking_version=b.version,expires_at=now()-interval '1 minute' where id=q;failed=false;begin perform planner_private.daily_review(q,1,'approved');exception when others then failed=true;end;if not failed then raise exception 'Expired approval accepted';end if;
 update public.agent_booking_requests set expires_at=now()+interval '1 hour',offer=offer||jsonb_build_object('totalCost',1e9) where id=q;failed=false;begin perform planner_private.daily_review(q,1,'approved');exception when others then failed=true;end;if not failed then raise exception 'Budget overflow accepted';end if;
 update public.agent_booking_requests set offer=offer||jsonb_build_object('totalCost',1) where id=q;
 perform planner_private.daily_review(q,1,'approved');
 if (select payload from public.trip_items where id=b.id)<>b.payload or (select version from public.trip_items where id=b.id)<>b.version then raise exception 'Approval altered booking';end if;
 failed=false;begin perform planner_private.publish_run(r.id,t.version);exception when others then failed=true;end;if not failed then raise exception 'Daily run passed full-plan publication';end if;
 perform set_config('request.jwt.claim.sub',gen_random_uuid()::text,true);failed=false;begin perform planner_private.daily_overview(t.id);exception when insufficient_privilege then failed=true;end;if not failed then raise exception 'Foreign user saw daily data';end if;
 perform set_config('request.jwt.claim.sub',uid::text,true);perform planner_private.daily_control(t.id,'stop',t.version);
 if (select state from public.agent_daily_settings where trip_id=t.id)<>'stopped' then raise exception 'Stop failed';end if;
 -- A full monthly budget creates one truthful blocked report on each Israel calendar day.
 perform planner_private.daily_control(t.id,'enable',t.version);
 update public.agent_daily_settings set updated_at=now()-interval '3 days' where trip_id=t.id;
 update planner_private.monthly_budget set spent_agorot=2000,reserved_agorot=0 where owner_id=uid and month=planner_private.month_key();
 perform planner_private.daily_tick_at(due+interval '1 day 8 hours');
 if not exists(select 1 from public.agent_daily_checks where trip_id=t.id and report_date=(due at time zone 'Asia/Jerusalem')::date+1 and state='skipped' and report->>'noProviderCall'='true' and report->>'summary' ~ 'תקציב|יתרה') then raise exception 'Missing budget-blocked report';end if;
 -- DST boundaries use local wall time, with no report before08 and only one afterwards.
 foreach v in array array[jsonb_build_object('before','2027-03-26 07:59 Asia/Jerusalem','after','2027-03-26 08:00 Asia/Jerusalem'),jsonb_build_object('before','2027-10-31 07:59 Asia/Jerusalem','after','2027-10-31 08:00 Asia/Jerusalem')] loop
 perform planner_private.daily_tick_at((v->>'before')::timestamptz);
 if exists(select 1 from public.agent_daily_checks where trip_id=t.id and report_date=((v->>'before')::timestamptz at time zone 'Asia/Jerusalem')::date) then raise exception 'DST ran before08';end if;
 perform planner_private.daily_tick_at((v->>'after')::timestamptz);perform planner_private.daily_tick_at((v->>'after')::timestamptz+interval '1 minute');
 if (select count(*) from public.agent_daily_checks where trip_id=t.id and report_date=((v->>'after')::timestamptz at time zone 'Asia/Jerusalem')::date)<>1 then raise exception 'DST duplicate/missing report';end if;end loop;
 if has_function_privilege('authenticated','public.agent_daily_finalize(uuid)','EXECUTE') or has_function_privilege('authenticated','planner_private.daily_tick_at(timestamptz)','EXECUTE') or has_table_privilege('authenticated','public.agent_booking_requests','UPDATE') then raise exception 'Client can finalize/write privileged data';end if;

end $$;
select 'PASS: clock, unique daily dispatch, plan isolation, pause/resume, idempotent finalization, stale/expired/over-budget review, no booking mutation, owner isolation, stop, blocked-day budget, DST and service privileges' result;
rollback;

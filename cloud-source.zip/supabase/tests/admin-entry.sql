begin;
set local role anon;
do $$begin
 begin perform public.admin_auth_target('admin','signin',repeat('a',64));raise exception 'Anonymous alias disclosure';exception when insufficient_privilege then null;end;
 begin perform public.admin_finance_overview();raise exception 'Anonymous financial access';exception when insufficient_privilege then null;end;
end $$;
reset role;
do $$declare uid uuid=gen_random_uuid();owner uuid;data jsonb;begin
 insert into auth.users(id,email,email_confirmed_at) values(uid,'non-admin-'||uid||'@example.invalid',now());update public.account_access set status='active' where user_id=uid;
 perform set_config('request.jwt.claim.sub',uid::text,true);
 begin perform public.admin_finance_overview();raise exception 'Ordinary user financial access';exception when insufficient_privilege then null;end;
 select user_id into owner from app_private.admin_login_aliases where username='admin';
 perform set_config('request.jwt.claim.sub',owner::text,true);data=public.admin_finance_overview();
 if data->>'revenueAgorot' is null or jsonb_array_length(data->'orders')>50 or data::text like '%provider_token%' then raise exception 'Invalid financial overview';end if;
 update public.account_access set status='suspended' where user_id=owner;
 if public.admin_auth_target('admin','signin',repeat('a',64)) is not null then raise exception 'Blocked admin alias resolved';end if;
 begin perform public.admin_finance_overview();raise exception 'Blocked admin financial access';exception when insufficient_privilege then null;end;
end $$;
rollback;
select 'PASS administrator login alias, unknown user, anon/ordinary/blocked finance denial and bounded owner overview' result;

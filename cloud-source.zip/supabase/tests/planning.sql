begin;
-- All fixtures rolled back. No provider calls.
do $$ declare uid uuid; tid uuid; otherid uuid; run jsonb; rid uuid; token uuid; overview jsonb; count_before bigint; begin
 select owner_id,id into uid,tid from public.trips where owner_id is not null order by created_at limit 1;
 if uid is null then raise exception 'An existing owner is required';end if;
 perform set_config('request.jwt.claim.sub',uid::text,true);
 update planner_private.runtime set ready_until=now()+interval '5 minutes',cost_bound_agorot=100 where singleton;
 insert into public.trips(owner_id,destination_name,title) values(uid,'planner-test-'||gen_random_uuid(),'planner test') returning id into otherid;
 run=planner_private.start_run(otherid,1,'{"start":"2027-01-20","days":2,"earlierDays":0,"laterDays":0,"shorterDays":0,"longerDays":0,"budget":20000,"budgetDeviationPct":0,"travelers":1,"rooms":1,"departure":"TLV","transport":"motorcycle","includes":["lodging"],"preferences":"","runLimitAgorot":500}'::jsonb,gen_random_uuid());
 rid=(run->>'id')::uuid;
 if (select reserved_agorot from planner_private.monthly_budget where owner_id=uid and month=planner_private.month_key())<>100 then raise exception 'Reservation missing';end if;
 begin perform planner_private.start_run(otherid,1,run->'input',gen_random_uuid());raise exception 'Allowed concurrent run';exception when check_violation then null;end;
 perform set_config('request.jwt.claim.sub',gen_random_uuid()::text,true);
 begin perform planner_private.cancel_run(rid);raise exception 'Foreign cancel allowed';exception when insufficient_privilege then null;end;
 perform set_config('request.jwt.claim.sub',uid::text,true);
 perform planner_private.cancel_run(rid);
 if (select reserved_agorot from planner_private.monthly_budget where owner_id=uid and month=planner_private.month_key())<>0 then raise exception 'Queued reservation not released';end if;
 update planner_private.monthly_budget set spent_agorot=1950 where owner_id=uid and month=planner_private.month_key();
 begin perform planner_private.start_run(otherid,1,run->'input',gen_random_uuid());raise exception 'Exceeded monthly cap';exception when check_violation then null;end;
 if has_table_privilege('authenticated','planner_private.worker_nonces','SELECT') then raise exception 'Client can read worker authorizations';end if;
 if has_table_privilege('authenticated','planner_private.monthly_budget','UPDATE') then raise exception 'Client can write budget';end if;
 if has_function_privilege('authenticated','public.planner_worker_claim()','EXECUTE') then raise exception 'Client can claim work';end if;
 if has_table_privilege('authenticated','public.planner_runs','UPDATE') then raise exception 'Client can change run';end if;
 raise notice 'PASS: reservations, monthly cap, owner isolation, cancellation and server-only ledger';
end $$;
rollback;

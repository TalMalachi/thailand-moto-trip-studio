begin;
do $$declare uid uuid=gen_random_uuid();admin uuid;tid uuid;rid uuid;f uuid=gen_random_uuid();q text;begin
 select s.user_id into admin from app_private.superusers s join public.account_access a on a.user_id=s.user_id where a.status='active' limit 1;
 insert into auth.users(id,email,email_confirmed_at) values(uid,'blocked-worker-'||uid||'@example.invalid',now());
 update public.account_access set status='active' where user_id=uid;
 insert into app_private.superusers(user_id) values(uid); -- fixture quota exemption, rolled back
 insert into public.trips(owner_id,destination_name) values(uid,'blocked worker fixture') returning id into tid;
 insert into planner_private.monthly_budget(owner_id,month,reserved_agorot) values(uid,current_date,100);
 insert into public.planner_runs(owner_id,trip_id,request_key,state,input,trip_version,snapshot,month,reserved_agorot) values(uid,tid,gen_random_uuid(),'queued','{}',1,'{}',current_date,100) returning id into rid;
 insert into planner_private.calls(run_id,fence,lease_until) values(rid,f,now()+interval '90 seconds');
 insert into public.agent_daily_settings(trip_id,owner_id,state,input) values(tid,uid,'active','{}');
 perform set_config('request.jwt.claim.sub',admin::text,true);
 perform public.admin_account_status(uid,1,'suspended','security fixture');
 if (select state from public.agent_daily_settings where trip_id=tid)<>'stopped' then raise exception 'Suspension kept schedule active';end if;
 if (select state from public.planner_runs where id=rid)<>'cancelled' then raise exception 'Suspension kept queued run';end if;
 if (select reserved_agorot from planner_private.monthly_budget where owner_id=uid)<>0 then raise exception 'Suspension leaked queued cost hold';end if;
 if public.planner_worker_dispatch(rid,f,'{}') then raise exception 'Old worker claim dispatched after suspension';end if;
 if not exists(select 1 from app_private.account_audit where target=uid and actor=admin and new_status='suspended') then raise exception 'No account audit';end if;
 begin perform public.admin_account_status(uid,1,'active','stale update');raise exception 'Stale admin update allowed';exception when serialization_failure then null;end;
 perform set_config('request.jwt.claim.sub',uid::text,true);
 foreach q in array array[
 format('select planner_private.start_run(%L,1,''{}'',gen_random_uuid())',tid),
 format('select planner_private.overview(%L)',tid),
 format('select planner_private.cancel_run(%L)',rid),
 format('select planner_private.publish_run(%L,1)',rid),
 format('select planner_private.control_run(%L,''resume'')',rid),
 format('select planner_private.daily_control(%L,''enable'',1)',tid),
 format('select planner_private.daily_overview(%L)',tid),
 format('select planner_private.daily_review(%L,1,''approved'')',rid)] loop
 begin execute q;raise exception 'Suspended definer allowed: %',q;exception when insufficient_privilege then null;end;
 end loop;
end $$;
rollback;
select 'PASS admin audit/version, schedule stop, queue cancellation, retained-claim dispatch denial and all eight planner definer gates; fixtures rolled back' result;

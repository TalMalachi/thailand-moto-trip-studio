begin;
insert into auth.users(id,email) values ('10000000-0000-4000-8000-000000000001','test-owner@example.invalid'),('10000000-0000-4000-8000-000000000002','test-other@example.invalid');
insert into public.trips(id,owner_id) values ('20000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001'),('20000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000002');
insert into public.trip_items(id,trip_id,kind,payload) values('30000000-0000-4000-8000-000000000001','20000000-0000-4000-8000-000000000001','task','{"title":"private","done":false}');
set local role authenticated;
select set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000001',true);
do $$ begin
 if (select count(*) from public.trips)<>1 then raise exception 'Owner isolation failed';end if;
 if (select count(*) from public.trip_items)<>1 then raise exception 'Owner read failed';end if;
 if (select count(*) from public.update_trip_item('30000000-0000-4000-8000-000000000001',1,'{"title":"updated","done":true}'))<>1 then raise exception 'Owner write failed';end if;
 if (select count(*) from public.update_trip_item('30000000-0000-4000-8000-000000000001',1,'{"title":"stale"}'))<>0 then raise exception 'Stale write overwrote row';end if;
 begin
  update public.trips set owner_id='10000000-0000-4000-8000-000000000002',version=version+1 where id='20000000-0000-4000-8000-000000000001';
  raise exception 'Ownership reassignment allowed';
 exception when insufficient_privilege then null;
 end;
 begin
  insert into public.trip_items(trip_id,kind,payload) values('20000000-0000-4000-8000-000000000002','task','{}');
  raise exception 'Foreign insert allowed';
 exception when insufficient_privilege then null;
 end;
end $$;
select set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000002',true);
do $$ begin
 if (select count(*) from public.trip_items)<>0 then raise exception 'Other user read private item';end if;
 if (select count(*) from public.update_trip_item('30000000-0000-4000-8000-000000000001',2,'{}'))<>0 then raise exception 'Other user updated item';end if;
 if (select count(*) from public.delete_trip_item('30000000-0000-4000-8000-000000000001',2))<>0 then raise exception 'Other user deleted item';end if;
end $$;
set local role anon;
do $$ begin
 begin
  perform 1 from public.trip_items;
  raise exception 'Anon read allowed';
 exception when insufficient_privilege then null;
 end;
end $$;
reset role;
rollback;
select 'PASS owner isolation, ownership reassignment denied, foreign writes denied, stale writes denied, anon denied; fixtures rolled back' as result;

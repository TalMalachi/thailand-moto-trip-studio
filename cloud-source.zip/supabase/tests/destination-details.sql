begin;
insert into auth.users(id,email) values ('12000000-0000-4000-8000-000000000001','details-owner@example.invalid'),('12000000-0000-4000-8000-000000000002','details-other@example.invalid');
update public.account_access set status='active' where user_id in ('12000000-0000-4000-8000-000000000001','12000000-0000-4000-8000-000000000002');
insert into public.trips(id,owner_id,settings) values ('22000000-0000-4000-8000-000000000001','12000000-0000-4000-8000-000000000001','{"start":"","days":21,"budget":0,"currency":"ILS","bookingPolicies":[{"category":"מלון","freeText":"preserve"}]}');
set local role authenticated;
select set_config('request.jwt.claim.sub','12000000-0000-4000-8000-000000000002',true);
do $$ begin if(select count(*) from public.update_trip_destination_details('22000000-0000-4000-8000-000000000001',1,'test',false,'{"budget":20000}'))<>0 then raise exception 'Foreign destination update allowed';end if;end $$;
select set_config('request.jwt.claim.sub','12000000-0000-4000-8000-000000000001',true);
do $$ begin
 if(select count(*) from public.update_trip_destination_details('22000000-0000-4000-8000-000000000001',1,'תאילנד',false,'{"start":"2027-01-20","days":28,"budget":20000,"currency":"ILS"}'))<>1 then raise exception 'Details update failed';end if;
 if(select settings#>>'{bookingPolicies,0,freeText}' from public.trips where id='22000000-0000-4000-8000-000000000001')<>'preserve' then raise exception 'Policy overwritten';end if;
 if(select (settings->>'budget')::int from public.trips where id='22000000-0000-4000-8000-000000000001')<>20000 then raise exception 'Budget not updated';end if;
 if(select count(*) from public.update_trip_destination_details('22000000-0000-4000-8000-000000000001',1,'old',true,'{}'))<>0 then raise exception 'Stale update accepted';end if;
end $$;
reset role;
rollback;
select 'PASS atomic destination details, settings and policy preservation, owner isolation, stale write denial; fixtures rolled back' as result;

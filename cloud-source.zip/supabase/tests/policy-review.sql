begin;
insert into auth.users(id,email) values ('11000000-0000-4000-8000-000000000001','review-owner@example.invalid'),('11000000-0000-4000-8000-000000000002','review-other@example.invalid');
insert into public.trips(id,owner_id,destination_name,settings) values ('21000000-0000-4000-8000-000000000001','11000000-0000-4000-8000-000000000001','Policy test','{"start":"","days":21,"budget":10000,"currency":"ILS","bookingPolicyProposals":[{"id":"review-1","category":"מלון","state":"awaiting_approval","bookingIds":["31000000-0000-4000-8000-000000000001"],"budgetSharePct":30,"options":[{"id":"a","label":"Free cancellation"},{"id":"b","label":"Breakfast"}]}]}');
insert into public.trip_items(id,trip_id,kind,payload) values ('31000000-0000-4000-8000-000000000001','21000000-0000-4000-8000-000000000001','booking','{"name":"Test","type":"מלון","workflowStatus":"awaiting_approval"}');
set local role authenticated;
select set_config('request.jwt.claim.sub','11000000-0000-4000-8000-000000000002',true);
do $$ begin if (select count(*) from public.review_booking_policy('21000000-0000-4000-8000-000000000001',1,'review-1','["a"]','approved'))<>0 then raise exception 'Foreign approval allowed';end if;end $$;
select set_config('request.jwt.claim.sub','11000000-0000-4000-8000-000000000001',true);
do $$ begin
 begin perform public.review_booking_policy('21000000-0000-4000-8000-000000000001',1,'review-1','["missing"]','approved');raise exception 'Invalid selection accepted';exception when raise_exception then if sqlerrm<>'Unknown policy option' then raise;end if;end;
 begin
  update public.trips set settings=jsonb_set(settings,'{bookingPolicyProposals}',(settings->'bookingPolicyProposals')||'[{"id":"newer","category":"מלון","state":"awaiting_approval","bookingIds":[],"options":[{"id":"a","label":"New terms"}]}]'::jsonb),version=version+1 where id='21000000-0000-4000-8000-000000000001';
  perform public.review_booking_policy('21000000-0000-4000-8000-000000000001',2,'review-1','["a"]','approved');raise exception 'Superseded approval accepted';
 exception when raise_exception then if sqlerrm<>'Policy proposal superseded' then raise;end if;end;
 if (select count(*) from public.review_booking_policy('21000000-0000-4000-8000-000000000001',1,'review-1','["a"]','approved'))<>1 then raise exception 'Owner approval failed';end if;
 if (select payload->>'workflowStatus' from public.trip_items where id='31000000-0000-4000-8000-000000000001')<>'updated' then raise exception 'Booking status not updated atomically';end if;
 if (select settings#>>'{bookingPolicyProposals,0,approvedOptionIds,0}' from public.trips where id='21000000-0000-4000-8000-000000000001')<>'a' then raise exception 'Selections not saved';end if;
 if (select count(*) from public.review_booking_policy('21000000-0000-4000-8000-000000000001',1,'review-1','["b"]','approved'))<>0 then raise exception 'Stale approval allowed';end if;
end $$;
update public.trips set settings=jsonb_set(settings,'{bookingPolicyProposals}',(settings->'bookingPolicyProposals')||'[{"id":"review-2","category":"טיסה","state":"awaiting_approval","bookingIds":[],"budgetSharePct":80,"options":[{"id":"a","label":"Flight"}]}]'::jsonb),version=version+1 where id='21000000-0000-4000-8000-000000000001';
do $$ begin begin perform public.review_booking_policy('21000000-0000-4000-8000-000000000001',3,'review-2','["a"]','approved');raise exception 'Budget overflow accepted';exception when raise_exception then if sqlerrm<>'Category allocations exceed 100 percent of the trip budget' then raise;end if;end;end $$;
reset role;
rollback;
select 'PASS atomic approval, exact selections, owner isolation, stale version rejection and derived budget allocation; fixtures rolled back' as result;

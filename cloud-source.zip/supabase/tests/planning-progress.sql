begin;
do $$ declare uid uuid=gen_random_uuid();tid uuid;rid uuid;f uuid=gen_random_uuid();begin
 insert into auth.users(id,email) values(uid,'progress-'||uid||'@example.invalid');
 update public.account_access set status='active' where user_id=uid;insert into app_private.superusers(user_id) values(uid);
 insert into public.trips(owner_id,destination_name) values(uid,'Progress fixture') returning id into tid;
 insert into public.planner_runs(owner_id,trip_id,request_key,state,input,trip_version,snapshot,month,reserved_agorot) values(uid,tid,gen_random_uuid(),'researching','{}',1,'{}',current_date,0) returning id into rid;
 insert into planner_private.calls(run_id,fence,lease_until) values(rid,f,now()+interval '90 seconds');
 if public.planner_worker_progress(rid,gen_random_uuid(),'provider_working','in_progress',0,0,true) then raise exception 'Stale fence accepted';end if;
 if not public.planner_worker_progress(rid,f,'provider_working','in_progress',0,0,true) then raise exception 'Progress rejected';end if;
 if not public.planner_worker_progress(rid,f,'provider_working','in_progress',0,0,true) then raise exception 'Heartbeat rejected';end if;
 if (select jsonb_array_length(progress->'events') from public.planner_runs where id=rid)<>1 then raise exception 'Repeated heartbeat duplicated event';end if;
 if not exists(select 1 from planner_private.calls where run_id=rid and lease_until<=now()+interval '11 seconds') then raise exception 'Polling lease not released';end if;
 update public.planner_runs set state='cancelled' where id=rid;
 if public.planner_worker_progress(rid,f,'drafting','in_progress',0,0,false) then raise exception 'Cancelled work resurrected';end if;
 if has_function_privilege('authenticated','public.planner_worker_progress(uuid,uuid,text,text,integer,integer,boolean)','execute') or has_function_privilege('anon','public.planner_worker_progress(uuid,uuid,text,text,integer,integer,boolean)','execute') then raise exception 'Client can forge progress';end if;
end $$;
rollback;
select 'PASS progress heartbeat, deduplication, stale fence, cancellation, server-only writes and fixtures rolled back' as result;

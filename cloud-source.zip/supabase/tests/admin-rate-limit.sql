begin;
do $$declare k text=repeat('a',64);i integer;begin
 for i in 1..11 loop perform public.admin_auth_target('unknown','signin',k);end loop;
 if public.admin_auth_target('admin','signin',repeat('b',64)) is null then raise exception 'Other caller exhausted administrator login quota';end if;
 if public.admin_auth_target('admin','signin',k) is not null then raise exception 'Caller quota not enforced';end if;
end $$;
rollback;
select 'PASS per-caller login limits do not block another administrator caller' result;

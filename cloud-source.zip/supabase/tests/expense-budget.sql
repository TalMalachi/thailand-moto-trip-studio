begin;
do $$declare t public.trips;b public.trip_items;checkid uuid;q uuid;blocked boolean=false;begin
 select * into t from public.trips where exists(select 1 from public.planner_runs where trip_id=trips.id and purpose='plan') order by created_at limit 1;
 perform set_config('request.jwt.claim.sub',t.owner_id::text,true);perform set_config('request.jwt.claims',jsonb_build_object('sub',t.owner_id)::text,true);
 perform planner_private.daily_control(t.id,'enable',t.version);
 update public.trips set settings=settings||jsonb_build_object('expenses',jsonb_build_array(jsonb_build_object('id','test-cost','name','TEST','category','TEST','cost',(t.settings->>'budget')::numeric*2,'paid',0,'notes',''))),version=version+1 where id=t.id returning * into t;
 select * into b from public.trip_items where trip_id=t.id and kind='booking' and coalesce(payload->>'status','') not in ('הוזמן','שולם') limit 1;
 insert into public.agent_daily_checks(trip_id,owner_id,report_date,state) values(t.id,t.owner_id,'2099-01-01','finished') returning id into checkid;
 insert into public.agent_booking_requests(trip_id,owner_id,check_id,booking_id,booking_version,trip_version,offer) values(t.id,t.owner_id,checkid,b.id,b.version,t.version,'{"totalCost":1}') returning id into q;
 begin perform planner_private.daily_review(q,1,'approved');exception when others then if sqlerrm ~ 'תקציב' then blocked=true;else raise;end if;end;
 if not blocked or (select state from public.agent_booking_requests where id=q)<>'pending' then raise exception 'Manual expenses did not constrain approval';end if;
 if not exists(select 1 from public.update_trip_settings(t.id,t.version,t.settings) where settings->'expenses'=t.settings->'expenses') then raise exception 'Expense settings failed owner RPC';end if;
end $$;
select 'PASS: owner expense settings save and manual costs block over-budget approvals; no provider call' result;
rollback;

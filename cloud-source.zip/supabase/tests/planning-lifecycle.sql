begin;
do $$ declare uid uuid;tid uuid; r jsonb; rid uuid; job jsonb; f uuid; body jsonb; before_count bigint;inp jsonb='{"start":"2027-01-20","days":2,"earlierDays":0,"laterDays":0,"shorterDays":0,"longerDays":0,"budget":20000,"budgetDeviationPct":0,"travelers":1,"rooms":1,"departure":"TLV","transport":"motorcycle","includes":["lodging"],"preferences":"","runLimitAgorot":500}'; key uuid=gen_random_uuid();begin
 select owner_id into uid from public.trips where owner_id is not null limit 1;
 update planner_private.monthly_budget set spent_agorot=0,reserved_agorot=0 where owner_id=uid and month=planner_private.month_key();
 perform set_config('request.jwt.claim.sub',uid::text,true);
 update planner_private.runtime set ready_until=now()+interval '5 minutes',cost_bound_agorot=100 where singleton;
 insert into public.trips(owner_id,destination_name,title) values(uid,'lifecycle-'||gen_random_uuid(),'test') returning id into tid;
 r=planner_private.start_run(tid,1,inp,key);rid=(r->>'id')::uuid;
 if (planner_private.start_run(tid,1,inp,key)->>'id')::uuid<>rid then raise exception 'Not idempotent';end if;
 job=public.planner_worker_claim();if job->'run'->>'id'<>rid::text then raise exception 'Wrong claimed fixture';end if;f=(job->'call'->>'fence')::uuid;
 if public.planner_worker_dispatch(rid,gen_random_uuid(),'{}') then raise exception 'Stale fence dispatched';end if;
 if not public.planner_worker_dispatch(rid,f,'{}') then raise exception 'Dispatch failed';end if;
 if public.planner_worker_dispatch(rid,f,'{}') then raise exception 'Duplicate paid dispatch';end if;
 body='{"start":"2027-01-20","days":2,"estimatedTotal":10000,"summary":"draft","warnings":[],"sources":[],"dateAlternatives":[],"records":[{"kind":"stop","payload":{"day":1,"place":"day1"}},{"kind":"stop","payload":{"day":2,"place":"day2"}},{"kind":"booking","payload":{"name":"hotel","type":"מלון","paid":0,"status":"לבדיקה","workflowStatus":"opened"}},{"kind":"task","payload":{"title":"book hotel","done":false,"workflowStatus":"opened"}}]}'::jsonb;
 if public.planner_worker_finish(rid,gen_random_uuid(),'ready',body,10,'bad') then raise exception 'Stale worker completed';end if;
 if not public.planner_worker_finish(rid,f,'ready',body,10,'ready') then raise exception 'Finish failed';end if;
 if (select spent_agorot from planner_private.monthly_budget where owner_id=uid and month=planner_private.month_key())<>10 then raise exception 'Usage not settled';end if;
 if (select count(*) from public.trip_items where trip_id=tid)<>0 then raise exception 'Published before approval';end if;
 perform planner_private.publish_run(rid,1);perform planner_private.publish_run(rid,1);
 if (select count(*) from public.trip_items where trip_id=tid)<>4 then raise exception 'Non-atomic/idempotent publication';end if;
 if (select version from public.trips where id=tid)<>2 then raise exception 'Trip version missing';end if;
 -- Changed item versions invalidate a second draft without deleting anything.
 r=planner_private.start_run(tid,2,inp,gen_random_uuid());rid=(r->>'id')::uuid;job=public.planner_worker_claim();f=(job->'call'->>'fence')::uuid;perform public.planner_worker_dispatch(rid,f,'{}');perform public.planner_worker_finish(rid,f,'ready',body,10,'ready');
 update public.trip_items set payload=payload||'{"notes":"owner edit"}',version=version+1 where trip_id=tid;
 begin perform planner_private.publish_run(rid,2);raise exception 'Published over owner edit';exception when check_violation then null;end;
 if (select count(*) from public.trip_items where trip_id=tid)<>4 then raise exception 'Failed publication altered items';end if;
 perform planner_private.cancel_run(rid);
 -- Cancellation of an in-flight call prevents publication and retains accounting.
 r=planner_private.start_run(tid,2,inp,gen_random_uuid());rid=(r->>'id')::uuid;job=public.planner_worker_claim();f=(job->'call'->>'fence')::uuid;perform public.planner_worker_dispatch(rid,f,'{}');perform planner_private.cancel_run(rid);perform public.planner_worker_finish(rid,f,'ready',body,10,'late');
 if (select state from public.planner_runs where id=rid)<>'cancelled' or (select artifact from public.planner_runs where id=rid) is not null then raise exception 'Late completion resurrected cancellation';end if;
 if (select reserved_agorot from planner_private.monthly_budget where owner_id=uid and month=planner_private.month_key())<>0 then raise exception 'Hold not settled';end if;
 perform set_config('request.jwt.claim.sub',gen_random_uuid()::text,true);
 execute 'set local role authenticated';
 if exists(select 1 from public.planner_runs where trip_id=tid) then raise exception 'RLS exposed another owner';end if;
 execute 'reset role';
end $$;
rollback;
select 'PASS: durable dispatch, stale fences, idempotent publication, owner-edit conflict, cancellation, RLS' as result;

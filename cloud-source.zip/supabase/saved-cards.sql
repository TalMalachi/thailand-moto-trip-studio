alter table app_private.billing_config add column card_setup_enabled boolean not null default false;
create table app_private.card_setups(id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users on delete cascade,state text not null default 'creating' check(state in ('creating','pending','attention','completed','expired')),low_profile_id uuid unique,url text,fence uuid,verify_after timestamptz,created_at timestamptz not null default now());
create unique index card_setup_open on app_private.card_setups(owner_id) where state in ('creating','pending','attention');
create table app_private.payment_methods(id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users on delete cascade,setup_id uuid not null unique references app_private.card_setups,provider_token uuid unique,terminal integer not null,last4 text check(last4 ~ '^[0-9]{4}$'),expiry_month integer not null check(expiry_month between 1 and 12),expiry_year integer not null check(expiry_year between 2026 and 2200),token_expires date not null,created_at timestamptz not null default now(),removed_at timestamptz);
create function app_private.card_owner(p_user uuid) returns void language plpgsql security definer set search_path='' as $$begin
 perform 1 from public.account_access where user_id=p_user and status in ('pending','active') for share;
 if not found or not exists(select 1 from auth.users where id=p_user and email_confirmed_at is not null) then raise insufficient_privilege;end if;end $$;
create function app_private.card_methods() returns jsonb language plpgsql security definer set search_path='' as $$declare uid uuid=auth.uid();begin
 perform app_private.card_owner(uid);
 return jsonb_build_object('cardSetupEnabled',(select card_setup_enabled and gateway_enabled from app_private.billing_config where singleton),'paymentMethods',(select coalesce(jsonb_agg(jsonb_build_object('id',id,'last4',last4,'expiry_month',expiry_month,'expiry_year',expiry_year,'created_at',created_at)),'[]') from app_private.payment_methods where owner_id=uid and removed_at is null),'cardSetups',(select coalesce(jsonb_agg(jsonb_build_object('id',id,'state',state)),'[]') from app_private.card_setups where owner_id=uid and state in ('creating','pending','attention') and created_at>now()-interval '24 hours'));end $$;
create function app_private.card_remove(p_id uuid) returns void language plpgsql security definer set search_path='' as $$declare uid uuid=auth.uid();begin
 perform app_private.card_owner(uid);
 update app_private.payment_methods set provider_token=null,removed_at=coalesce(removed_at,now()) where id=p_id and owner_id=uid;if not found then raise insufficient_privilege;end if;end $$;
create function public.account_card_methods() returns jsonb language sql security invoker set search_path='' as $$select app_private.card_methods()$$;
create function public.account_card_remove(p_id uuid) returns void language sql security invoker set search_path='' as $$select app_private.card_remove(p_id)$$;
create function app_private.card_prepare(p_user uuid,p_consent text) returns jsonb language plpgsql security definer set search_path='' as $$declare s app_private.card_setups;begin
 perform 1 from public.account_access where user_id=p_user for update;perform app_private.card_owner(p_user);
 if p_consent is distinct from 'store-card-only-v1' or not exists(select 1 from app_private.billing_config where singleton and gateway_enabled and card_setup_enabled) then raise check_violation;end if;
 if (select count(*) from app_private.payment_methods where owner_id=p_user and removed_at is null)>=5 then raise check_violation;end if;
 update app_private.card_setups set state='expired' where owner_id=p_user and state in ('creating','pending','attention') and created_at<=now()-interval '24 hours';
 select * into s from app_private.card_setups where owner_id=p_user and state in ('creating','pending','attention');
 if found then if s.state<>'pending' then raise check_violation;end if;return jsonb_build_object('setupId',s.id,'url',s.url,'new',false);end if;
 insert into app_private.card_setups(owner_id) values(p_user) returning * into s;return jsonb_build_object('setupId',s.id,'new',true);end $$;
create function app_private.card_page(p_setup uuid,p_low_profile uuid,p_url text) returns void language plpgsql security definer set search_path='' as $$begin
 if p_low_profile is null or p_url !~ '^https://secure[.]cardcom[.]solutions/[^[:space:]]+$' then raise check_violation;end if;
 update app_private.card_setups set low_profile_id=p_low_profile,url=p_url,state='pending' where id=p_setup and state='creating';
 if not found and not exists(select 1 from app_private.card_setups where id=p_setup and state='completed' and low_profile_id=p_low_profile) then raise check_violation;end if;end $$;
create function app_private.card_attention(p_setup uuid) returns void language sql security definer set search_path='' as $$update app_private.card_setups set state='attention' where id=p_setup and state='creating'$$;
create function app_private.card_claim(p_setup uuid,p_low_profile uuid,p_user uuid) returns jsonb language plpgsql security definer set search_path='' as $$declare s app_private.card_setups;f uuid=gen_random_uuid();begin
 perform 1 from public.account_access where user_id=(select owner_id from app_private.card_setups where id=p_setup and (p_user is null or owner_id=p_user)) for share;
 select * into s from app_private.card_setups where id=p_setup and (p_user is null or owner_id=p_user) for update;if not found then return null;end if;
 perform app_private.card_owner(s.owner_id);
 if s.state='completed' then return jsonb_build_object('completed',true);end if;
 if s.state='expired' or s.created_at<=now()-interval '24 hours' then return null;end if;
 if s.low_profile_id is not null and p_low_profile is not null and s.low_profile_id<>p_low_profile then return null;end if;
 if coalesce(s.low_profile_id,p_low_profile) is null then return null;end if;
 if s.verify_after>now() then return jsonb_build_object('busy',true);end if;
 update app_private.card_setups set fence=f,verify_after=now()+interval '30 seconds' where id=s.id;
 return jsonb_build_object('setupId',s.id,'lowProfileId',coalesce(s.low_profile_id,p_low_profile),'fence',f);end $$;
create function app_private.card_confirm(p_setup uuid,p_fence uuid,p_low_profile uuid,p_token uuid,p_terminal integer,p_last4 text,p_month integer,p_year integer,p_expires date) returns jsonb language plpgsql security definer set search_path='' as $$declare s app_private.card_setups;begin
 perform 1 from public.account_access where user_id=(select owner_id from app_private.card_setups where id=p_setup) for update;
 select * into s from app_private.card_setups where id=p_setup for update;if not found then raise insufficient_privilege;end if;perform app_private.card_owner(s.owner_id);
 if s.state='completed' then return jsonb_build_object('completed',true);end if;
 if s.state not in ('pending','creating','attention') or s.created_at<=now()-interval '24 hours' or p_fence is null or s.fence is distinct from p_fence or p_low_profile is null or s.low_profile_id is not null and s.low_profile_id<>p_low_profile or p_token is null or p_expires<current_date then raise check_violation;end if;
 insert into app_private.payment_methods(owner_id,setup_id,provider_token,terminal,last4,expiry_month,expiry_year,token_expires) values(s.owner_id,s.id,p_token,p_terminal,p_last4,p_month,p_year,p_expires);
 update app_private.card_setups set state='completed',low_profile_id=p_low_profile where id=s.id;return jsonb_build_object('completed',true);end $$;
-- Expose only narrow invoker wrappers; provider tokens are never client-readable.
do $$declare t text;f record;args text;begin
 foreach t in array array['card_setups','payment_methods'] loop execute format('alter table app_private.%I enable row level security',t);execute format('revoke all on app_private.%I from public,anon,authenticated',t);execute format('grant all on app_private.%I to service_role',t);end loop;
 for f in select p.oid,p.proname,pg_get_function_identity_arguments(p.oid) arguments from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='app_private' and p.proname like 'card_%' loop
 execute format('revoke all on function app_private.%I(%s) from public,anon,authenticated',f.proname,f.arguments);execute format('grant execute on function app_private.%I(%s) to service_role',f.proname,f.arguments);
 if f.proname in ('card_prepare','card_page','card_attention','card_claim','card_confirm') then
 select string_agg(trim(split_part(a,' ',1)),',') into args from unnest(string_to_array(f.arguments,', '))a;
 execute format('create function public.%I(%s) returns %s language sql security invoker set search_path='''' as %L',f.proname,f.arguments,pg_get_function_result(f.oid),'select app_private.'||f.proname||'('||args||')');execute format('revoke all on function public.%I(%s) from public,anon,authenticated',f.proname,f.arguments);execute format('grant execute on function public.%I(%s) to service_role',f.proname,f.arguments);end if;end loop;
end $$;
grant execute on function app_private.card_methods(),app_private.card_remove(uuid) to authenticated;
revoke all on function public.account_card_methods(),public.account_card_remove(uuid) from public,anon;
grant execute on function public.account_card_methods(),public.account_card_remove(uuid) to authenticated;

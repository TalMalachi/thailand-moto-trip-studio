-- Additive planning subsystem. No existing trip data is rewritten.
create schema if not exists planner_private;
revoke all on schema planner_private from public,anon,authenticated;
grant usage on schema planner_private to authenticated,service_role;
create table planner_private.runtime(singleton boolean primary key default true check(singleton),ready_until timestamptz,cost_bound_agorot integer not null default 500 check(cost_bound_agorot between 1 and 500));
insert into planner_private.runtime(singleton) values(true);
create table planner_private.monthly_budget(owner_id uuid references auth.users(id) on delete cascade,month date,spent_agorot integer not null default 0 check(spent_agorot>=0),reserved_agorot integer not null default 0 check(reserved_agorot>=0),primary key(owner_id,month),check(spent_agorot+reserved_agorot<=2000));
create table public.planner_runs(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),trip_id uuid not null references public.trips(id),request_key uuid not null,
 state text not null check(state in ('queued','researching','ready','completed','cancelled','failed','budget_exhausted','needs_details')),
 input jsonb not null,trip_version bigint not null,snapshot jsonb not null,artifact jsonb,
 month date not null,reserved_agorot integer not null check(reserved_agorot between 0 and 500),spent_agorot integer not null default 0 check(spent_agorot>=0),
 message text not null default '',created_at timestamptz not null default now(),updated_at timestamptz not null default now(),unique(owner_id,request_key)
);
create index planner_runs_owner_time on public.planner_runs(owner_id,created_at desc);
create index planner_runs_trip on public.planner_runs(trip_id,created_at desc);
create unique index planner_one_active on public.planner_runs(owner_id) where state in ('queued','researching');
create table planner_private.calls(run_id uuid primary key references public.planner_runs(id),fence uuid,lease_until timestamptz,dispatched_at timestamptz,response_id text,pricing jsonb,settled boolean not null default false);
alter table public.planner_runs enable row level security;
alter table planner_private.runtime enable row level security;
alter table planner_private.monthly_budget enable row level security;
alter table planner_private.calls enable row level security;
revoke all on public.planner_runs from public,anon,authenticated;
grant select on public.planner_runs to authenticated;
create policy planner_owner_read on public.planner_runs for select to authenticated using(owner_id=(select auth.uid()));
grant all on public.planner_runs to service_role;
grant all on all tables in schema planner_private to service_role;
alter table public.trip_items add column if not exists planner_run_id uuid references public.planner_runs(id);
create unique index planner_item_identity on public.trip_items(trip_id,legacy_id) where planner_run_id is not null;
create function planner_private.month_key() returns date language sql stable set search_path='' as $$select date_trunc('month',now() at time zone 'Asia/Jerusalem')::date$$;
create function planner_private.start_run(p_trip uuid,p_version bigint,p_input jsonb,p_key uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare uid uuid=auth.uid(); t public.trips; r public.planner_runs; amount integer; mon date=planner_private.month_key(); n text; begin
 if uid is null then raise insufficient_privilege;end if;
 select * into r from public.planner_runs where owner_id=uid and request_key=p_key;if found then if r.trip_id<>p_trip or r.input<>p_input then raise check_violation using message='Idempotency conflict';end if;return to_jsonb(r);end if;
 -- Serialize starts against trip edits and account-level reservations.
 select * into t from public.trips where id=p_trip and owner_id=uid for update;if not found then raise insufficient_privilege;end if;
 if t.version<>p_version then raise exception 'Version conflict';end if;
 if p_key is null or p_input is null or jsonb_typeof(p_input)<>'object' or octet_length(p_input::text)>10000 then raise check_violation using message='Invalid planning input';end if;
 if not exists(select 1 from planner_private.runtime where singleton and ready_until>now()) then raise check_violation using message='הסוכן עדיין אינו מחובר לספק AI';end if;
 for n in select unnest(array['days','earlierDays','laterDays','shorterDays','longerDays','travelers','rooms','runLimitAgorot','budget','budgetDeviationPct']) loop
 if jsonb_typeof(p_input->n) is distinct from 'number' then raise check_violation using message='Invalid numeric input';end if;end loop;
 if (p_input->>'days')::numeric not between 1 and 90 or (p_input->>'runLimitAgorot')::numeric not between 1 and 500 or (p_input->>'budget')::numeric<=0 or (p_input->>'budgetDeviationPct')::numeric not between 0 and 100 or coalesce(p_input->>'start','') !~ '^\d{4}-\d{2}-\d{2}$' then raise check_violation using message='Invalid planning limits';end if;
 -- Every full input is independently revalidated by the worker before any provider call.
 select cost_bound_agorot into amount from planner_private.runtime where singleton;
 if amount>(p_input->>'runLimitAgorot')::numeric then raise check_violation using message='תקרת ההרצה נמוכה מעלותה המרבית';end if;
 insert into planner_private.monthly_budget(owner_id,month) values(uid,mon) on conflict do nothing;
 perform 1 from planner_private.monthly_budget where owner_id=uid and month=mon for update;
 if exists(select 1 from public.planner_runs where owner_id=uid and state in ('queued','researching')) then raise check_violation using message='כבר קיימת הרצה פעילה בחשבון';end if;
 update planner_private.monthly_budget set reserved_agorot=reserved_agorot+amount where owner_id=uid and month=mon and spent_agorot+reserved_agorot+amount<=2000;
 if not found then raise check_violation using message='אין מספיק יתרה בתקציב הסוכן החודשי';end if;
 insert into public.planner_runs(owner_id,trip_id,request_key,state,input,trip_version,snapshot,month,reserved_agorot)
 values(uid,p_trip,p_key,'queued',p_input,t.version,jsonb_build_object('destination_name',t.destination_name,'settings',t.settings,'items',(select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'version',i.version,'kind',i.kind,'title',coalesce(i.payload->>'name',i.payload->>'title',i.payload->>'place'),'day',i.payload->'day','category',coalesce(i.payload->>'type',i.payload->>'category'),'status',i.payload->>'status','cost',i.payload->'cost','paid',i.payload->'paid')),'[]'::jsonb) from public.trip_items i where i.trip_id=p_trip)),mon,amount) returning * into r;
 insert into planner_private.calls(run_id) values(r.id);return to_jsonb(r);
end $$;
create function planner_private.overview(p_trip uuid) returns jsonb language plpgsql security definer set search_path='' as $$declare uid uuid=auth.uid(); r jsonb; b planner_private.monthly_budget; begin
 if uid is null or not exists(select 1 from public.trips where id=p_trip and owner_id=uid) then raise insufficient_privilege;end if;
 select * into b from planner_private.monthly_budget where owner_id=uid and month=planner_private.month_key();
 select to_jsonb(x) into r from (select * from public.planner_runs where trip_id=p_trip and owner_id=uid order by created_at desc,id desc limit 1)x;
 return jsonb_build_object('monthlyLimitAgorot',2000,'runLimitAgorot',500,'spentAgorot',coalesce(b.spent_agorot,0),'reservedAgorot',coalesce(b.reserved_agorot,0),'month',planner_private.month_key(),'run',r,'ready',exists(select 1 from planner_private.runtime where singleton and ready_until>now()));end $$;
create function planner_private.cancel_run(p_run uuid) returns jsonb language plpgsql security definer set search_path='' as $$declare r public.planner_runs;c planner_private.calls;begin
 select * into r from public.planner_runs where id=p_run and owner_id=auth.uid() for update;if not found then raise insufficient_privilege;end if;
 if r.state in ('completed','cancelled','failed','budget_exhausted','needs_details') then return to_jsonb(r);end if;
 select * into c from planner_private.calls where run_id=r.id for update;
 if c.dispatched_at is null then update planner_private.monthly_budget set reserved_agorot=reserved_agorot-r.reserved_agorot where owner_id=r.owner_id and month=r.month; r.reserved_agorot=0;update planner_private.calls set settled=true where run_id=r.id;end if;
 update public.planner_runs set state='cancelled',reserved_agorot=r.reserved_agorot,message='נעצר לבקשתך; עלות פעולה שכבר נשלחה עשויה להתעדכן',updated_at=now() where id=r.id returning * into r;return to_jsonb(r);end $$;
create function planner_private.publish_run(p_run uuid,p_version bigint) returns jsonb language plpgsql security definer set search_path='' as $$declare r public.planner_runs;t public.trips;x jsonb;idx integer=0;begin
 select * into r from public.planner_runs where id=p_run and owner_id=auth.uid() for update;if not found then raise insufficient_privilege;end if;
 if r.state='completed' then return to_jsonb(r);end if;
 if r.state<>'ready' or r.artifact is null then raise check_violation using message='התכנון אינו מוכן לפרסום';end if;
 select * into t from public.trips where id=r.trip_id and owner_id=r.owner_id for update;
 if t.version<>p_version or t.version<>r.trip_version then raise check_violation using message='היעד השתנה מאז התכנון; יש לתכנן שוב לפני הוספה';end if;
 -- Lock item table to cover direct owner edits/inserts that do not increment the trip version.
 lock table public.trip_items in share row exclusive mode;
 if (select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'version',i.version) order by i.id),'[]'::jsonb) from public.trip_items i where trip_id=t.id) is distinct from (select coalesce(jsonb_agg(jsonb_build_object('id',i->'id','version',i->'version') order by (i->>'id')::uuid),'[]'::jsonb) from jsonb_array_elements(r.snapshot->'items') i) then raise check_violation using message='פריטי היעד השתנו; התכנון דורש רענון';end if;
 for x in select * from jsonb_array_elements(r.artifact->'records') loop
 if x->>'kind' not in ('stop','booking','task','place','gear') or jsonb_typeof(x->'payload') is distinct from 'object' then raise check_violation;end if;
 if x->>'kind'='booking' and ((x->'payload'->>'paid')::numeric<>0 or x->'payload'->>'status'<>'לבדיקה' or coalesce(x->'payload'->>'ref','')<>'') then raise check_violation;end if;
 if x->>'kind' in ('task','booking') and x->'payload'->>'workflowStatus'<>'opened' then raise check_violation;end if;
 if x->>'kind'='task' and (x->'payload'->>'done')::boolean then raise check_violation;end if;
 idx=idx+1;
 insert into public.trip_items(trip_id,kind,legacy_id,payload,planner_run_id) values(t.id,x->>'kind','planner-'||r.id||'-'||idx,x->'payload',r.id);
 end loop;
 update public.trips set settings=settings||jsonb_build_object('start',r.artifact->>'start','days',(r.artifact->>'days')::integer,'budget',(r.input->>'budget')::numeric),version=version+1 where id=t.id;
 update public.planner_runs set state='completed',message='התכנון נוסף לאתר',updated_at=now() where id=r.id returning * into r;return to_jsonb(r);end $$;
-- Public owner endpoints run as invokers; only these narrow private operations elevate.
create function public.planner_overview(p_trip uuid) returns jsonb language sql security invoker set search_path='' as $$select planner_private.overview(p_trip)$$;
create function public.planner_start(p_trip uuid,p_version bigint,p_input jsonb,p_key uuid) returns jsonb language sql security invoker set search_path='' as $$select planner_private.start_run(p_trip,p_version,p_input,p_key)$$;
create function public.planner_cancel(p_run uuid) returns jsonb language sql security invoker set search_path='' as $$select planner_private.cancel_run(p_run)$$;
create function public.planner_publish(p_run uuid,p_version bigint) returns jsonb language sql security invoker set search_path='' as $$select planner_private.publish_run(p_run,p_version)$$;
revoke all on all functions in schema planner_private from public,anon,authenticated;
grant execute on function planner_private.overview(uuid),planner_private.start_run(uuid,bigint,jsonb,uuid),planner_private.cancel_run(uuid),planner_private.publish_run(uuid,bigint) to authenticated;
revoke all on function public.planner_overview(uuid),public.planner_start(uuid,bigint,jsonb,uuid),public.planner_cancel(uuid),public.planner_publish(uuid,bigint) from public,anon;
grant execute on function public.planner_overview(uuid),public.planner_start(uuid,bigint,jsonb,uuid),public.planner_cancel(uuid),public.planner_publish(uuid,bigint) to authenticated;
-- Worker procedures are invoker and available only to the backend service role.
create function public.planner_runtime_ready(p_ready boolean,p_bound integer) returns void language sql security invoker set search_path='' as $$update planner_private.runtime set ready_until=case when p_ready then now()+interval '5 minutes' else null end,cost_bound_agorot=p_bound where singleton$$;
create function public.planner_worker_claim() returns jsonb language plpgsql security invoker set search_path='' as $$declare r public.planner_runs;c planner_private.calls;f uuid=gen_random_uuid();begin
 select rr.* into r from public.planner_runs rr join planner_private.calls cc on cc.run_id=rr.id where (rr.state in ('queued','researching') or (rr.state='cancelled' and not cc.settled)) and (cc.lease_until is null or cc.lease_until<now()) order by rr.created_at for update of rr skip locked limit 1;
 if not found then return null;end if;
 update planner_private.calls set fence=f,lease_until=now()+interval '90 seconds' where run_id=r.id returning * into c;
 return jsonb_build_object('run',to_jsonb(r),'call',to_jsonb(c));end $$;
create function public.planner_worker_dispatch(p_run uuid,p_fence uuid,p_pricing jsonb) returns boolean language plpgsql security invoker set search_path='' as $$begin
 perform 1 from public.planner_runs where id=p_run and state='queued' and created_at>now()-interval '15 minutes' for update;if not found then return false;end if;
 update planner_private.calls set dispatched_at=now(),pricing=p_pricing where run_id=p_run and fence=p_fence and lease_until>now() and dispatched_at is null;if not found then return false;end if;
 update public.planner_runs set state='researching',updated_at=now() where id=p_run;return true;end $$;
create function public.planner_worker_response(p_run uuid,p_fence uuid,p_response text) returns boolean language plpgsql security invoker set search_path='' as $$begin
 update planner_private.calls set response_id=p_response,lease_until=null where run_id=p_run and fence=p_fence and lease_until>now() and response_id is null and dispatched_at is not null;return found;end $$;
create function public.planner_worker_finish(p_run uuid,p_fence uuid,p_state text,p_artifact jsonb,p_spent integer,p_message text) returns boolean language plpgsql security invoker set search_path='' as $$declare r public.planner_runs;c planner_private.calls;begin
 select * into r from public.planner_runs where id=p_run for update;
 select * into c from planner_private.calls where run_id=p_run and fence=p_fence and lease_until>now() for update;
 if not found or c.settled then return false;end if;
 if p_state not in ('ready','failed','needs_details','budget_exhausted') then raise check_violation;end if;
 if p_spent is not null and (p_spent<0 or p_spent>r.reserved_agorot) then raise check_violation using message='Cost exceeds reserved bound';end if;
 if p_spent is not null then update planner_private.monthly_budget set reserved_agorot=reserved_agorot-r.reserved_agorot,spent_agorot=spent_agorot+p_spent where owner_id=r.owner_id and month=r.month;update planner_private.calls set settled=true where run_id=r.id;end if;
 update planner_private.calls set lease_until=now()+interval '100 years' where run_id=r.id;
 update public.planner_runs set state=case when state='cancelled' then state else p_state end,artifact=case when state='cancelled' then null else p_artifact end,spent_agorot=coalesce(p_spent,spent_agorot),reserved_agorot=case when p_spent is null then reserved_agorot else 0 end,message=left(p_message,500),updated_at=now() where id=p_run;return true;end $$;
revoke all on function public.planner_runtime_ready(boolean,integer),public.planner_worker_claim(),public.planner_worker_dispatch(uuid,uuid,jsonb),public.planner_worker_response(uuid,uuid,text),public.planner_worker_finish(uuid,uuid,text,jsonb,integer,text) from public,anon,authenticated;
grant execute on function public.planner_runtime_ready(boolean,integer),public.planner_worker_claim(),public.planner_worker_dispatch(uuid,uuid,jsonb),public.planner_worker_response(uuid,uuid,text),public.planner_worker_finish(uuid,uuid,text,jsonb,integer,text) to service_role;

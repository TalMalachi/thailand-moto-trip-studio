-- Narrow privileged boundaries; service_role does not need SELECT on auth.users.
do $$declare f record;d text;args text;begin
 for f in select p.oid,p.proname,pg_get_function_identity_arguments(p.oid) arguments from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname in ('billing_prepare','billing_page','billing_attention','billing_claim','billing_confirm') loop
 d=pg_get_functiondef(f.oid);d=replace(d,'FUNCTION public.'||f.proname,'FUNCTION app_private.'||f.proname);d=replace(d,'LANGUAGE plpgsql','LANGUAGE plpgsql SECURITY DEFINER');d=replace(d,'LANGUAGE sql','LANGUAGE sql SECURITY DEFINER');
 if f.proname='billing_prepare' then d=replace(d,'destination_name=dest','lower(trim(destination_name))=lower(trim(dest))');end if;
 if f.proname='billing_claim' then d=replace(d,'select * into o from app_private.orders',$fragment$if p_user is not null and not exists(select 1 from public.account_access where user_id=p_user and status in ('pending','active')) then raise insufficient_privilege;end if;select * into o from app_private.orders$fragment$);end if;
 execute d;
 execute format('revoke all on function app_private.%I(%s) from public,anon,authenticated',f.proname,f.arguments);
 execute format('grant execute on function app_private.%I(%s) to service_role',f.proname,f.arguments);
 select string_agg(trim(split_part(a, ' ',1)),',') into args from unnest(string_to_array(f.arguments,', ')) a;
 execute format('create or replace function public.%I(%s) returns %s language sql security invoker set search_path='''' as %L',f.proname,f.arguments,pg_get_function_result(f.oid),'select app_private.'||f.proname||'('||args||')');
 end loop;
end $$;
create unique index order_destination_normalized on app_private.orders(owner_id,lower(trim(destination_name)));
create function app_private.immutable_package() returns trigger language plpgsql set search_path='' as $$begin raise check_violation using message='Purchased package versions are immutable';end $$;
revoke all on function app_private.immutable_package() from public,anon,authenticated;
create trigger immutable_package before update or delete on app_private.package_versions for each row execute function app_private.immutable_package();
-- A manual active status also requires verified paid rights for ordinary accounts.
do $$declare d text;begin
 d=pg_get_functiondef('app_private.admin_status(uuid,bigint,text,text)'::regprocedure);
 d=replace(d,'update public.account_access set status=p_status', $fragment$if p_status='active' and not exists(select 1 from app_private.superusers where user_id=p_user) and not exists(select 1 from app_private.orders where owner_id=p_user and state='paid') then raise check_violation using message='נדרש תשלום מאומת לפני הפעלת החשבון';end if;update public.account_access set status=p_status$fragment$);execute d;
end $$;

-- Durable wakeups contain only a random internal token stored in Vault.
create extension if not exists pg_cron;
create extension if not exists pg_net with schema extensions;
do $$begin
 if not exists(select 1 from vault.secrets where name='planner_worker_token') then
 perform vault.create_secret(gen_random_uuid()::text||gen_random_uuid()::text,'planner_worker_token','Internal destination planner scheduler token');end if;
end $$;
alter table planner_private.runtime add column worker_hash text;
update planner_private.runtime set worker_hash=encode(sha256(convert_to((select decrypted_secret from vault.decrypted_secrets where name='planner_worker_token'),'UTF8')),'hex') where singleton;
create function public.planner_worker_authorized(p_token text) returns boolean language sql security invoker set search_path='' as $$
 select p_token is not null and length(p_token)>60 and exists(select 1 from planner_private.runtime where singleton and worker_hash=encode(sha256(convert_to(p_token,'UTF8')),'hex'))
$$;
revoke all on function public.planner_worker_authorized(text) from public,anon,authenticated;
grant execute on function public.planner_worker_authorized(text) to service_role;
-- Only the postgres scheduler can read the Vault token; service_role may verify, never list it via this endpoint.
create function planner_private.scheduler_tick() returns void language plpgsql security invoker set search_path='' as $$begin
 if exists(select 1 from public.planner_runs r join planner_private.calls c on c.run_id=r.id where (r.state in ('queued','researching') or (r.state='cancelled' and not c.settled)) and (c.lease_until is null or c.lease_until<now())) then
 perform net.http_post(url:='https://nxpvxsyiyigedmplsdnz.supabase.co/functions/v1/trip-planner',headers:=jsonb_build_object('Content-Type','application/json','x-planner-worker',(select decrypted_secret from vault.decrypted_secrets where name='planner_worker_token')),body:='{"action":"tick"}'::jsonb,timeout_milliseconds:=45000);
 end if;
 -- Redacted execution detail retention; completed artifact provenance stays with destination.
 update public.planner_runs set snapshot=jsonb_build_object('destination_name',snapshot->>'destination_name','items','[]'::jsonb) where created_at<now()-interval '30 days' and state in ('completed','cancelled','failed','budget_exhausted','needs_details') and jsonb_array_length(coalesce(snapshot->'items','[]'::jsonb))>0;
end $$;
revoke all on function planner_private.scheduler_tick() from public,anon,authenticated,service_role;
select cron.schedule('motor-trip-planner','* * * * *','select planner_private.scheduler_tick()');


-- Apply planning-scheduler-nonces.sql next: managed queue ACLs require single-use wakeups.

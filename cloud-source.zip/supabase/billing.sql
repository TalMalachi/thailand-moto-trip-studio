-- Immutable paid terms, hosted checkout orders, and per-trip AI quota.
alter table app_private.billing_config add column gateway_enabled boolean not null default false;
create table app_private.orders(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users on delete cascade,
 trip_id uuid references public.trips on delete set null,destination_name text not null check(length(trim(destination_name)) between 1 and 100),
 package_id uuid not null references app_private.package_versions,state text not null default 'creating' check(state in ('creating','pending','paid','attention')),
 consent_version text not null check(consent_version='per-trip-v1'),low_profile_id uuid unique,checkout_url text,transaction_id text unique,
 verification_fence uuid,verification_after timestamptz,created_at timestamptz not null default now(),paid_at timestamptz,
 unique(owner_id,destination_name)
);
create unique index order_trip_unique on app_private.orders(trip_id) where trip_id is not null;
create table app_private.entitlements(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users on delete cascade,
 trip_id uuid not null unique references public.trips on delete cascade,order_id uuid not null unique references app_private.orders,
 ai_runs integer not null check(ai_runs>0),reserved_runs integer not null default 0 check(reserved_runs>=0),used_runs integer not null default 0 check(used_runs>=0),check(reserved_runs+used_runs<=ai_runs)
);
create table app_private.run_quota(run_id uuid primary key references public.planner_runs on delete cascade,entitlement_id uuid not null references app_private.entitlements on delete cascade,state text not null default 'reserved' check(state in ('reserved','consumed','released')));
create function app_private.reserve_run_quota() returns trigger language plpgsql security definer set search_path='' as $$declare eid uuid;begin
 if not app_private.user_active(new.owner_id) then raise insufficient_privilege using message='החשבון אינו פעיל';end if;
 if exists(select 1 from app_private.superusers where user_id=new.owner_id) then return new;end if;
 update app_private.entitlements set reserved_runs=reserved_runs+1 where trip_id=new.trip_id and owner_id=new.owner_id and reserved_runs+used_runs<ai_runs returning id into eid;
 if eid is null then raise check_violation using message='מכסת הרצות ה־AI לטיול אינה זמינה או הסתיימה';end if;
 insert into app_private.run_quota(run_id,entitlement_id) values(new.id,eid);return new;end $$;
create trigger reserve_run_quota after insert on public.planner_runs for each row execute function app_private.reserve_run_quota();
create function app_private.settle_run_quota() returns trigger language plpgsql security definer set search_path='' as $$declare q app_private.run_quota;dispatched boolean;begin
 if new.state=old.state then return new;end if;
 select * into q from app_private.run_quota where run_id=new.id and state='reserved' for update;if not found then return new;end if;
 select dispatched_at is not null into dispatched from planner_private.calls where run_id=new.id;
 if coalesce(dispatched,false) then
 update app_private.entitlements set reserved_runs=reserved_runs-1,used_runs=used_runs+1 where id=q.entitlement_id;
 update app_private.run_quota set state='consumed' where run_id=new.id;
 elsif new.state in ('cancelled','failed','needs_details','budget_exhausted') then
 update app_private.entitlements set reserved_runs=reserved_runs-1 where id=q.entitlement_id;
 update app_private.run_quota set state='released' where run_id=new.id;end if;return new;end $$;
create trigger settle_run_quota after update of state on public.planner_runs for each row execute function app_private.settle_run_quota();
-- Capture only registration contact fields. User metadata NEVER grants status or roles.
create or replace function app_private.new_account() returns trigger language plpgsql security definer set search_path='' as $$declare k text;v text;clean jsonb='{}';begin
 insert into public.account_access(user_id) values(new.id);
 for k in select unnest(array['name','phone','street','city','postcode','country']) loop
 v=trim(new.raw_user_meta_data->'profile'->>k);if length(coalesce(v,'')) between 1 and 200 then clean=clean||jsonb_build_object(k,v);end if;end loop;
 insert into app_private.profiles(user_id,details) values(new.id,clean);return new;end $$;
-- Account reads expose only that account's orders/allowances, never credentials/provider payloads.
do $$declare d text;begin
 d=pg_get_functiondef('app_private.account_state()'::regprocedure);
 d=replace(d,'''checkoutEnabled'',false','''checkoutEnabled'',coalesce((select gateway_enabled from app_private.billing_config where singleton),false)');
 d=replace(d,'return result;end', $fragment$return result||jsonb_build_object('entitlements',(select coalesce(jsonb_agg(jsonb_build_object('trip_id',e.trip_id,'destination_name',t.destination_name,'ai_runs',e.ai_runs,'used_runs',e.used_runs,'reserved_runs',e.reserved_runs)),'[]') from app_private.entitlements e join public.trips t on t.id=e.trip_id where e.owner_id=uid),'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'state',o.state,'destination_name',o.destination_name,'price_agorot',v.price_agorot,'ai_runs',v.ai_runs,'paid_at',o.paid_at,'created_at',o.created_at)),'[]') from app_private.orders o join app_private.package_versions v on v.id=o.package_id where o.owner_id=uid));end$fragment$);
 execute d;end $$;
create function public.billing_prepare(p_user uuid,p_package uuid,p_trip uuid,p_destination text,p_consent text) returns jsonb language plpgsql security invoker set search_path='' as $$declare a public.account_access;v app_private.package_versions;o app_private.orders;dest text;details jsonb;mail text;begin
 select * into a from public.account_access where user_id=p_user for update;
 if not found or a.status not in ('pending','active') then raise insufficient_privilege;end if;
 if not exists(select 1 from app_private.billing_config where singleton and gateway_enabled and package_id=p_package) then raise check_violation using message='החבילה השתנתה או שהסליקה אינה פעילה';end if;
 select email into mail from auth.users where id=p_user and email_confirmed_at is not null;if not found then raise insufficient_privilege using message='נדרש אימות מייל לפני תשלום';end if;
 select p.details into details from app_private.profiles p where user_id=p_user;
 if details is null or not (details ?& array['name','phone','street','city','postcode','country']) then raise check_violation using message='יש להשלים פרטי חשבון וכתובת';end if;
 if p_consent is distinct from 'per-trip-v1' then raise check_violation;end if;
 if p_trip is not null then select destination_name into dest from public.trips where id=p_trip and owner_id=p_user;if not found then raise insufficient_privilege;end if;
 else dest=trim(p_destination);if length(coalesce(dest,'')) not between 1 and 100 then raise check_violation;end if;end if;
 select * into v from app_private.package_versions where id=p_package;
 select * into o from app_private.orders where owner_id=p_user and (destination_name=dest or p_trip is not null and trip_id=p_trip) for update;
 if found then
 if o.package_id<>p_package or o.state<>'pending' then raise check_violation using message='כבר קיים תשלום או ניסיון תשלום לטיול; יש לבדוק את הסטטוס לפני ניסיון נוסף';end if;
 return jsonb_build_object('order',to_jsonb(o),'new',false);end if;
 insert into app_private.orders(owner_id,trip_id,destination_name,package_id,consent_version) values(p_user,p_trip,dest,p_package,p_consent) returning * into o;
 return jsonb_build_object('order',to_jsonb(o),'new',true,'package',to_jsonb(v)-'created_by','profile',details,'email',mail);end $$;
create function public.billing_page(p_order uuid,p_low_profile uuid,p_url text) returns void language plpgsql security invoker set search_path='' as $$begin
 if p_low_profile is null or p_url !~ '^https://secure[.]cardcom[.]solutions/[^[:space:]]+$' then raise check_violation;end if;
 update app_private.orders set low_profile_id=p_low_profile,checkout_url=p_url,state='pending' where id=p_order and state in ('creating','attention') and low_profile_id is null;
 -- A verified webhook may already have settled the order while Create was returning.
 if not found and not exists(select 1 from app_private.orders where id=p_order and state='paid' and low_profile_id=p_low_profile) then raise check_violation;end if;end $$;
create function public.billing_attention(p_order uuid) returns void language sql security invoker set search_path='' as $$update app_private.orders set state='attention' where id=p_order and state='creating'$$;
create function public.billing_claim(p_order uuid,p_low_profile uuid,p_user uuid) returns jsonb language plpgsql security invoker set search_path='' as $$declare o app_private.orders;v app_private.package_versions;f uuid=gen_random_uuid();begin
 select * into o from app_private.orders where id=p_order and (p_user is null or owner_id=p_user) for update;
 if not found then return null;end if;
 if o.state='paid' then return jsonb_build_object('paid',true);end if;
 if o.verification_after>now() then return jsonb_build_object('busy',true);end if;
 if p_low_profile is not null and o.low_profile_id is not null and o.low_profile_id<>p_low_profile then return null;end if;
 if coalesce(o.low_profile_id,p_low_profile) is null then return null;end if;
 select * into v from app_private.package_versions where id=o.package_id;
 update app_private.orders set verification_fence=f,verification_after=now()+interval '30 seconds' where id=o.id;
 return jsonb_build_object('orderId',o.id,'ownerId',o.owner_id,'lowProfileId',coalesce(o.low_profile_id,p_low_profile),'priceAgorot',v.price_agorot,'fence',f);end $$;
create function public.billing_confirm(p_order uuid,p_fence uuid,p_low_profile uuid,p_transaction text,p_amount integer) returns jsonb language plpgsql security invoker set search_path='' as $$declare o app_private.orders;v app_private.package_versions;a public.account_access;tid uuid;begin
 -- Account lock precedes order lock, matching checkout/admin operations.
 select * into a from public.account_access where user_id=(select owner_id from app_private.orders where id=p_order) for update;
 select * into o from app_private.orders where id=p_order for update;if not found then raise insufficient_privilege;end if;
 if o.state='paid' then return jsonb_build_object('paid',true,'tripId',o.trip_id);end if;
 select * into v from app_private.package_versions where id=o.package_id;
 if o.verification_fence is distinct from p_fence or p_fence is null or p_amount is distinct from v.price_agorot or p_low_profile is null or o.low_profile_id is not null and o.low_profile_id<>p_low_profile or p_transaction is null or p_transaction !~ '^[1-9][0-9]{0,19}$' then raise check_violation;end if;
 if not exists(select 1 from auth.users where id=o.owner_id and email_confirmed_at is not null) then raise insufficient_privilege;end if;
 tid=o.trip_id;
 -- A payment cannot undo an administrator's suspension/closure.
 if a.status in ('pending','active') then
 if tid is null then
 select id into tid from public.trips where owner_id=o.owner_id and lower(trim(destination_name))=lower(trim(o.destination_name));
 if tid is null then insert into public.trips(owner_id,destination_name,title) values(o.owner_id,o.destination_name,o.destination_name) returning id into tid;end if;end if;
 insert into app_private.entitlements(owner_id,trip_id,order_id,ai_runs) values(o.owner_id,tid,o.id,v.ai_runs);
 if a.status='pending' then update public.account_access set status='active',version=version+1,updated_at=now() where user_id=o.owner_id;end if;
 end if;
 update app_private.orders set state='paid',paid_at=now(),low_profile_id=p_low_profile,transaction_id=p_transaction,trip_id=tid where id=o.id;
 return jsonb_build_object('paid',true,'tripId',tid,'accountActive',a.status in ('active','pending'));end $$;
-- Every payment RPC is service-only. Hosted callbacks are verified by the Edge Function.
do $$declare f record;t text;begin
 foreach t in array array['orders','entitlements','run_quota'] loop
 execute format('alter table app_private.%I enable row level security',t);execute format('revoke all on app_private.%I from public,anon,authenticated',t);execute format('grant all on app_private.%I to service_role',t);end loop;
 for f in select p.oid::regprocedure signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname in ('billing_prepare','billing_page','billing_attention','billing_claim','billing_confirm') loop execute format('revoke all on function %s from public,anon,authenticated',f.signature);execute format('grant execute on function %s to service_role',f.signature);end loop;
end $$;
revoke all on function app_private.reserve_run_quota(),app_private.settle_run_quota() from public,anon,authenticated;

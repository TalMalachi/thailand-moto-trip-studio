create function planner_private.manual_expense_budget(p_settings jsonb) returns numeric language plpgsql immutable set search_path='' as $$declare x jsonb;c numeric;p numeric;total numeric=0;rows jsonb=coalesce(p_settings->'expenses','[]'::jsonb);begin
 if jsonb_typeof(rows)<>'array' or jsonb_array_length(rows)>500 then raise check_violation using message='נתוני הוצאות לא תקינים';end if;
 for x in select * from jsonb_array_elements(rows) loop
 if jsonb_typeof(x)<>'object' or (x ? 'cost' and jsonb_typeof(x->'cost') not in ('number','null')) or (x ? 'paid' and jsonb_typeof(x->'paid')<>'number') then raise check_violation using message='נתוני הוצאות לא תקינים';end if;
 c=coalesce((x->>'cost')::numeric,0);p=coalesce((x->>'paid')::numeric,0);
 if c<0 or p<0 or c>1000000000 or p>1000000000 then raise check_violation using message='נתוני הוצאות לא תקינים';end if;
 total=total+greatest(round(c,2),round(p,2));end loop;return total;
end $$;
revoke all on function planner_private.manual_expense_budget(jsonb) from public,anon,authenticated;
do $$declare d text;needle text='used=used+coalesce((select sum((a.offer';begin
 d=pg_get_functiondef('planner_private.daily_review(uuid,bigint,text)'::regprocedure);
 if position(needle in d)=0 then raise exception 'Unexpected approval budget implementation';end if;
 d=replace(d,needle,'used=used+planner_private.manual_expense_budget(t.settings);'||chr(10)||' '||needle);execute d;
end $$;

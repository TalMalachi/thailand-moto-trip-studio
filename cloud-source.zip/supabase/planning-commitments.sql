create or replace function planner_private.start_run(p_trip uuid,p_version bigint,p_input jsonb,p_key uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare uid uuid=auth.uid(); t public.trips; r public.planner_runs; amount integer; mon date=planner_private.month_key(); n text; begin
 if uid is null then raise insufficient_privilege;end if;
 select * into r from public.planner_runs where owner_id=uid and request_key=p_key;if found then if r.trip_id<>p_trip or r.input<>p_input then raise check_violation using message='Idempotency conflict';end if;return to_jsonb(r);end if;
 -- Serialize starts against trip edits and account-level reservations.
 select * into t from public.trips where id=p_trip and owner_id=uid for update;if not found then raise insufficient_privilege;end if;
 if t.version<>p_version then raise exception 'Version conflict';end if;
 if p_key is null or p_input is null or jsonb_typeof(p_input)<>'object' or octet_length(p_input::text)>10000 then raise check_violation using message='Invalid planning input';end if;
 if not exists(select 1 from planner_private.runtime where singleton and ready_until>now()) then raise check_violation using message='הסוכן עדיין אינו מחובר לספק AI';end if;
 for n in select unnest(array['days','earlierDays','laterDays','shorterDays','longerDays','travelers','rooms','runLimitAgorot','budget','budgetDeviationPct']) loop
 if jsonb_typeof(p_input->n) is distinct from 'number' then raise check_violation using message='Invalid numeric input';end if;end loop;
 if (p_input->>'days')::numeric not between 1 and 90 or (p_input->>'runLimitAgorot')::numeric not between 1 and 500 or (p_input->>'budget')::numeric<=0 or (p_input->>'budgetDeviationPct')::numeric not between 0 and 100 or coalesce(p_input->>'start','') !~ '^\d{4}-\d{2}-\d{2}$' then raise check_violation using message='Invalid planning limits';end if;
 -- Every full input is independently revalidated by the worker before any provider call.
 select cost_bound_agorot into amount from planner_private.runtime where singleton;
 if amount>(p_input->>'runLimitAgorot')::numeric then raise check_violation using message='תקרת ההרצה נמוכה מעלותה המרבית';end if;
 insert into planner_private.monthly_budget(owner_id,month) values(uid,mon) on conflict do nothing;
 perform 1 from planner_private.monthly_budget where owner_id=uid and month=mon for update;
 if exists(select 1 from public.planner_runs where owner_id=uid and state in ('queued','researching')) then raise check_violation using message='כבר קיימת הרצה פעילה בחשבון';end if;
 update planner_private.monthly_budget set reserved_agorot=reserved_agorot+amount where owner_id=uid and month=mon and spent_agorot+reserved_agorot+amount<=2000;
 if not found then raise check_violation using message='אין מספיק יתרה בתקציב הסוכן החודשי';end if;
 insert into public.planner_runs(owner_id,trip_id,request_key,state,input,trip_version,snapshot,month,reserved_agorot)
 values(uid,p_trip,p_key,'queued',p_input,t.version,jsonb_build_object('destination_name',t.destination_name,'settings',t.settings,'items',(select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'version',i.version,'kind',i.kind,'title',coalesce(i.payload->>'name',i.payload->>'title',i.payload->>'place'),'day',i.payload->'day','category',coalesce(i.payload->>'type',i.payload->>'category'),'status',i.payload->>'status','cost',i.payload->'cost','paid',i.payload->'paid')),'[]'::jsonb) from public.trip_items i where i.trip_id=p_trip)),mon,amount) returning * into r;
 insert into planner_private.calls(run_id) values(r.id);return to_jsonb(r);
end $$;

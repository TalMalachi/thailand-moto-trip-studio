import {handlePlannerRequest,createDependencies} from './worker.bundle.js';
const deps=createDependencies(Deno.env.toObject());
Deno.serve((request:Request)=>handlePlannerRequest(request,deps));

import {handleBillingRequest,createBillingDependencies} from './worker.bundle.js';
const deps=createBillingDependencies(Deno.env.toObject());
Deno.serve((request:Request)=>handleBillingRequest(request,deps));

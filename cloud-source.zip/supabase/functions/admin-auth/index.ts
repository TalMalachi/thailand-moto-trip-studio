import {handleAdminAuth,createAdminAuthDependencies} from './worker.bundle.js';
const deps=createAdminAuthDependencies(Deno.env.toObject());
Deno.serve((request:Request)=>handleAdminAuth(request,deps));

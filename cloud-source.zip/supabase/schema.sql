create table public.trips (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid references auth.users(id),
 title text not null default 'Thailand Moto Trip Studio',
 settings jsonb not null default '{"start":"","days":21,"budget":0,"currency":"ILS"}',
 version bigint not null default 1 check(version>0),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check(jsonb_typeof(settings)='object')
);
create unique index trips_owner_id on public.trips(owner_id) where owner_id is not null;
create table public.trip_items (
 id uuid primary key default gen_random_uuid(),
 trip_id uuid not null references public.trips(id) on delete cascade,
 kind text not null check(kind in ('booking','stop','place','gear','task')),
 legacy_id text check(length(legacy_id) between 1 and 200),
 payload jsonb not null check(jsonb_typeof(payload)='object' and octet_length(payload::text)<=100000),
 version bigint not null default 1 check(version>0),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(trip_id,kind,legacy_id)
);
create index trip_items_trip_id on public.trip_items(trip_id);
alter table public.trips enable row level security;
alter table public.trip_items enable row level security;
revoke all on public.trips,public.trip_items from anon,authenticated;
grant select,insert,update,delete on public.trips,public.trip_items to authenticated;
create policy trips_read on public.trips for select to authenticated using(owner_id=(select auth.uid()));
create policy trips_insert on public.trips for insert to authenticated with check(owner_id=(select auth.uid()));
create policy trips_update on public.trips for update to authenticated using(owner_id=(select auth.uid())) with check(owner_id=(select auth.uid()));
create policy trips_delete on public.trips for delete to authenticated using(owner_id=(select auth.uid()));
create policy items_read on public.trip_items for select to authenticated using(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create policy items_insert on public.trip_items for insert to authenticated with check(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create policy items_update on public.trip_items for update to authenticated using(trip_id in(select id from public.trips where owner_id=(select auth.uid()))) with check(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create policy items_delete on public.trip_items for delete to authenticated using(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create function public.enforce_trip_version() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if new.version<>old.version+1 then raise exception 'Version conflict' using errcode='40001'; end if;
 if new.id<>old.id then raise exception 'ID cannot change'; end if;
 new.updated_at=now();return new;
end $$;
revoke all on function public.enforce_trip_version() from public;
create trigger trip_version before update on public.trips for each row execute function public.enforce_trip_version();
create trigger item_version before update on public.trip_items for each row execute function public.enforce_trip_version();
create function public.update_trip_item(p_id uuid,p_expected_version bigint,p_payload jsonb)
returns setof public.trip_items language sql security invoker set search_path='' as $$
 update public.trip_items set payload=p_payload,version=version+1 where id=p_id and version=p_expected_version returning *
$$;
create function public.delete_trip_item(p_id uuid,p_expected_version bigint)
returns setof public.trip_items language sql security invoker set search_path='' as $$
 delete from public.trip_items where id=p_id and version=p_expected_version returning *
$$;
create function public.update_trip_settings(p_id uuid,p_expected_version bigint,p_settings jsonb)
returns setof public.trips language sql security invoker set search_path='' as $$
 update public.trips set settings=p_settings,version=version+1 where id=p_id and version=p_expected_version returning *
$$;
revoke all on function public.update_trip_item(uuid,bigint,jsonb),public.delete_trip_item(uuid,bigint),public.update_trip_settings(uuid,bigint,jsonb) from public,anon;
grant execute on function public.update_trip_item(uuid,bigint,jsonb),public.delete_trip_item(uuid,bigint),public.update_trip_settings(uuid,bigint,jsonb) to authenticated;


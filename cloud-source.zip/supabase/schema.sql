create table public.trips (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid references auth.users(id),
 title text not null default 'Motor Trip Studio',
 destination_name text not null default 'תאילנד' check(length(trim(destination_name)) between 1 and 100),
 is_active boolean not null default true,
 settings jsonb not null default '{"start":"","days":21,"budget":0,"currency":"ILS"}',
 version bigint not null default 1 check(version>0),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check(jsonb_typeof(settings)='object')
);
create unique index trips_owner_destination on public.trips(owner_id,lower(trim(destination_name))) where owner_id is not null;
create table public.trip_items (
 id uuid primary key default gen_random_uuid(),
 trip_id uuid not null references public.trips(id) on delete cascade,
 kind text not null check(kind in ('booking','stop','place','gear','task')),
 legacy_id text check(length(legacy_id) between 1 and 200),
 payload jsonb not null check(jsonb_typeof(payload)='object' and octet_length(payload::text)<=100000),
 version bigint not null default 1 check(version>0),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(trip_id,kind,legacy_id)
);
create index trip_items_trip_id on public.trip_items(trip_id);
alter table public.trips enable row level security;
alter table public.trip_items enable row level security;
revoke all on public.trips,public.trip_items from anon,authenticated;
grant select,insert,update,delete on public.trips,public.trip_items to authenticated;
create policy trips_read on public.trips for select to authenticated using(owner_id=(select auth.uid()));
create policy trips_insert on public.trips for insert to authenticated with check(owner_id=(select auth.uid()));
create policy trips_update on public.trips for update to authenticated using(owner_id=(select auth.uid())) with check(owner_id=(select auth.uid()));
create policy trips_delete on public.trips for delete to authenticated using(owner_id=(select auth.uid()));
create policy items_read on public.trip_items for select to authenticated using(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create policy items_insert on public.trip_items for insert to authenticated with check(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create policy items_update on public.trip_items for update to authenticated using(trip_id in(select id from public.trips where owner_id=(select auth.uid()))) with check(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create policy items_delete on public.trip_items for delete to authenticated using(trip_id in(select id from public.trips where owner_id=(select auth.uid())));
create function public.enforce_trip_version() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if new.version<>old.version+1 then raise exception 'Version conflict' using errcode='40001'; end if;
 if new.id<>old.id then raise exception 'ID cannot change'; end if;
 new.updated_at=now();return new;
end $$;
revoke all on function public.enforce_trip_version() from public;
create trigger trip_version before update on public.trips for each row execute function public.enforce_trip_version();
create trigger item_version before update on public.trip_items for each row execute function public.enforce_trip_version();
create function public.update_trip_item(p_id uuid,p_expected_version bigint,p_payload jsonb)
returns setof public.trip_items language sql security invoker set search_path='' as $$
 update public.trip_items set payload=p_payload,version=version+1 where id=p_id and version=p_expected_version returning *
$$;
create function public.delete_trip_item(p_id uuid,p_expected_version bigint)
returns setof public.trip_items language sql security invoker set search_path='' as $$
 delete from public.trip_items where id=p_id and version=p_expected_version returning *
$$;
create function public.update_trip_settings(p_id uuid,p_expected_version bigint,p_settings jsonb)
returns setof public.trips language sql security invoker set search_path='' as $$
 update public.trips set settings=p_settings,version=version+1 where id=p_id and version=p_expected_version returning *
$$;
revoke all on function public.update_trip_item(uuid,bigint,jsonb),public.delete_trip_item(uuid,bigint),public.update_trip_settings(uuid,bigint,jsonb) from public,anon;
grant execute on function public.update_trip_item(uuid,bigint,jsonb),public.delete_trip_item(uuid,bigint),public.update_trip_settings(uuid,bigint,jsonb) to authenticated;


create function public.update_trip_destination(p_id uuid,p_expected_version bigint,p_destination_name text,p_is_active boolean)
returns setof public.trips language sql security invoker set search_path='' as $$
 update public.trips set destination_name=trim(p_destination_name),title=trim(p_destination_name),is_active=p_is_active,version=version+1 where id=p_id and version=p_expected_version returning *
$$;
revoke all on function public.update_trip_destination(uuid,bigint,text,boolean) from public,anon;
grant execute on function public.update_trip_destination(uuid,bigint,text,boolean) to authenticated;

create or replace function public.review_booking_policy(p_trip_id uuid,p_expected_version bigint,p_proposal_id text,p_selected_ids jsonb,p_decision text)
returns setof public.trips language plpgsql security invoker set search_path='' as $$
declare t public.trips; proposal jsonb; proposals jsonb; category text; share numeric; other_shares numeric;
begin
 if p_decision not in ('approved','rejected') then raise exception 'Invalid policy decision';end if;
 select * into t from public.trips where id=p_trip_id and version=p_expected_version for update;
 if not found then return;end if;
 proposals=coalesce(t.settings->'bookingPolicyProposals','[]'::jsonb);
 if (select count(*) from jsonb_array_elements(proposals) p where p->>'id'=p_proposal_id)<>1 then raise exception 'Policy proposal not found';end if;
 select p into proposal from jsonb_array_elements(proposals) p where p->>'id'=p_proposal_id;
 if proposal->>'state' not in ('policy_updated','awaiting_approval') then raise exception 'Policy proposal already reviewed';end if;
 category=proposal->>'category';
 if (select p->>'id' from jsonb_array_elements(proposals) with ordinality x(p,n) where p->>'category'=category order by n desc limit 1)<>p_proposal_id then raise exception 'Policy proposal superseded';end if;
 if exists(select 1 from jsonb_array_elements_text(coalesce(proposal->'bookingIds','[]'::jsonb)) b where not exists(select 1 from public.trip_items i where i.id::text=b and i.trip_id=p_trip_id and i.kind='booking' and coalesce(nullif(trim(i.payload->>'type'),''),'ללא קטגוריה')=category)) then raise exception 'Proposal booking does not match destination and category';end if;
 if p_decision='approved' then
  if jsonb_typeof(p_selected_ids)<>'array' or jsonb_array_length(p_selected_ids)=0 then raise exception 'Select at least one option';end if;
  if exists(select 1 from jsonb_array_elements_text(p_selected_ids) s where not exists(select 1 from jsonb_array_elements(proposal->'options') o where o->>'id'=s)) then raise exception 'Unknown policy option';end if;
  if (select count(*) from jsonb_array_elements_text(p_selected_ids))<>(select count(distinct s) from jsonb_array_elements_text(p_selected_ids) s) then raise exception 'Duplicate selected option';end if;
  share=nullif(proposal->>'budgetSharePct','')::numeric;
  if share is not null and (share<0 or share>100) then raise exception 'Invalid budget share';end if;
  select coalesce(sum(nullif(p->>'budgetSharePct','')::numeric),0) into other_shares from (select distinct on (p->>'category') p from jsonb_array_elements(proposals) with ordinality x(p,n) where p->>'category'<>category and p->>'state'='approved' order by p->>'category',n desc) latest;
  if coalesce(share,0)+other_shares>100 then raise exception 'Category allocations exceed 100 percent of the trip budget';end if;
 else p_selected_ids='[]'::jsonb;end if;
 proposal=proposal||jsonb_build_object('state',p_decision,'approvedOptionIds',p_selected_ids,'reviewedAt',now());
 select jsonb_agg(case when p->>'id'=p_proposal_id then proposal else p end order by n) into proposals from jsonb_array_elements(proposals) with ordinality x(p,n);
 update public.trips set settings=jsonb_set(settings,'{bookingPolicyProposals}',proposals),version=version+1 where id=p_trip_id;
 update public.trip_items set payload=payload||jsonb_build_object('workflowStatus',case when p_decision='approved' then 'updated' else 'rejected' end,'workflowUpdatedBy','user','workflowUpdatedAt',now()),version=version+1 where trip_id=p_trip_id and kind='booking' and id::text in(select jsonb_array_elements_text(coalesce(proposal->'bookingIds','[]'::jsonb))) and payload->>'workflowStatus' in ('policy_updated','awaiting_approval');
 return query select * from public.trips where id=p_trip_id;
end $$;
revoke all on function public.review_booking_policy(uuid,bigint,text,jsonb,text) from public,anon;
grant execute on function public.review_booking_policy(uuid,bigint,text,jsonb,text) to authenticated;

create function public.update_trip_destination_details(p_id uuid,p_expected_version bigint,p_destination_name text,p_is_active boolean,p_settings jsonb)
returns setof public.trips language sql security invoker set search_path='' as $$
 update public.trips set destination_name=trim(p_destination_name),title=trim(p_destination_name),is_active=p_is_active,settings=settings||p_settings,version=version+1 where id=p_id and version=p_expected_version and jsonb_typeof(p_settings)='object' returning *
$$;
revoke all on function public.update_trip_destination_details(uuid,bigint,text,boolean,jsonb) from public,anon;
grant execute on function public.update_trip_destination_details(uuid,bigint,text,boolean,jsonb) to authenticated;

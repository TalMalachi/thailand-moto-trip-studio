alter table public.planner_runs add column paused_at timestamptz;
alter table public.planner_runs add column deadline_at timestamptz;
update public.planner_runs set deadline_at=created_at+interval '15 minutes';
alter table public.planner_runs alter column deadline_at set default (now()+interval '15 minutes');
alter table public.planner_runs alter column deadline_at set not null;

create function planner_private.control_run(p_run uuid,p_action text) returns jsonb language plpgsql security definer set search_path='' as $$
declare r public.planner_runs;c planner_private.calls;events jsonb;begin
 if auth.uid() is null then raise insufficient_privilege;end if;
 select * into r from public.planner_runs where id=p_run and owner_id=auth.uid() for update;
 if not found then raise insufficient_privilege;end if;
 if p_action is null or p_action not in ('pause','resume') or r.state not in ('queued','researching','ready') then raise check_violation using message='אפשר להמשיך רק הרצה שהושהתה; הרצה שבוטלה או נכשלה דורשת תכנון חדש';end if;
 if (p_action='pause' and r.paused_at is not null) or (p_action='resume' and r.paused_at is null) then return to_jsonb(r);end if;
 select * into c from planner_private.calls where run_id=p_run for update;
 events=coalesce(r.progress->'events','[]'::jsonb);
 select coalesce(jsonb_agg(e order by ord),'[]'::jsonb) into events from jsonb_array_elements(events) with ordinality z(e,ord) where ord>jsonb_array_length(events)-31;
 events=events||jsonb_build_array(jsonb_build_object('stage',case when p_action='pause' then 'paused' else 'resumed' end,'at',now()));
 update public.planner_runs set
  deadline_at=case when p_action='resume' and r.state='queued' and c.dispatched_at is null then deadline_at+(now()-r.paused_at) else deadline_at end,
  paused_at=case when p_action='pause' then now() else null end,
  progress=progress||jsonb_build_object('events',events,'checkedAt',now()),
  message=case when p_action='pause' then 'ההרצה מושהית; בקשת AI שכבר נשלחה עשויה להמשיך אצל הספק' else 'ההרצה חודשה ללא פתיחת בקשה חדשה' end,updated_at=now()
 where id=p_run returning * into r;
 -- Invalidate a queued claim before it can dispatch. Never lose an in-flight receipt.
 if c.dispatched_at is null then update planner_private.calls set fence=gen_random_uuid(),lease_until=null where run_id=p_run;end if;
 return to_jsonb(r);
end $$;
revoke all on function planner_private.control_run(uuid,text) from public,anon;
grant execute on function planner_private.control_run(uuid,text) to authenticated;
create function public.planner_pause(p_run uuid) returns jsonb language sql security invoker set search_path='' as $$select planner_private.control_run(p_run,'pause')$$;
create function public.planner_resume(p_run uuid) returns jsonb language sql security invoker set search_path='' as $$select planner_private.control_run(p_run,'resume')$$;
revoke all on function public.planner_pause(uuid),public.planner_resume(uuid) from public,anon;
grant execute on function public.planner_pause(uuid),public.planner_resume(uuid) to authenticated;

create or replace function public.planner_worker_claim() returns jsonb language plpgsql security invoker set search_path='' as $$declare r public.planner_runs;c planner_private.calls;f uuid=gen_random_uuid();begin
 select rr.* into r from public.planner_runs rr join planner_private.calls cc on cc.run_id=rr.id
 where ((rr.state='queued' and rr.paused_at is null) or rr.state='researching' or (rr.state='cancelled' and not cc.settled)) and (cc.lease_until is null or cc.lease_until<now()) order by rr.created_at for update of rr skip locked limit 1;
 if not found then return null;end if;
 update planner_private.calls set fence=f,lease_until=now()+interval '90 seconds' where run_id=r.id returning * into c;
 return jsonb_build_object('run',to_jsonb(r),'call',to_jsonb(c));end $$;
create or replace function public.planner_worker_dispatch(p_run uuid,p_fence uuid,p_pricing jsonb) returns boolean language plpgsql security invoker set search_path='' as $$begin
 perform 1 from public.planner_runs where id=p_run and state='queued' and paused_at is null and deadline_at>now() for update;if not found then return false;end if;
 update planner_private.calls set dispatched_at=now(),pricing=p_pricing where run_id=p_run and fence=p_fence and lease_until>now() and dispatched_at is null;if not found then return false;end if;
 update public.planner_runs set state='researching',updated_at=now() where id=p_run;return true;end $$;
-- Preserve the existing publication validation and add a pause guard.
do $$ declare definition text;begin
 definition=pg_get_functiondef('planner_private.publish_run(uuid,bigint)'::regprocedure);
 if position('if r.state=''completed''' in definition)=0 then raise exception 'Unexpected publish function';end if;
 definition=replace(definition,'if r.state=''completed''','if r.paused_at is not null then raise check_violation using message=''התכנון מושהה; לחץ המשך לפני הוספה'';end if; if r.state=''completed''');
 execute definition;
 definition=pg_get_functiondef('planner_private.scheduler_tick()'::regprocedure);
 if position('r.state in (''queued'',''researching'')' in definition)=0 then raise exception 'Unexpected scheduler function';end if;
 definition=replace(definition,'r.state in (''queued'',''researching'')','(r.state=''researching'' or (r.state=''queued'' and r.paused_at is null))');
 execute definition;
 definition=pg_get_functiondef('planner_private.cancel_run(uuid)'::regprocedure);
 definition=replace(definition,'set state=''cancelled'',','set state=''cancelled'',paused_at=null,');
 execute definition;
 definition=pg_get_functiondef('public.planner_worker_finish(uuid,uuid,text,jsonb,integer,text)'::regprocedure);
 definition=replace(definition,'set state=case when state=','set paused_at=case when state=''cancelled'' or p_state<>''ready'' then null else paused_at end,state=case when state=');
 execute definition;
end $$;

-- Managed pg_net queue ACLs cannot be changed by this project's postgres role.
-- Never enqueue a reusable credential. Use a short-lived single-use wakeup nonce.
create table planner_private.worker_nonces(hash text primary key,expires_at timestamptz not null,used_at timestamptz);
alter table planner_private.worker_nonces enable row level security;
revoke all on planner_private.worker_nonces from public,anon,authenticated;
grant select,update on planner_private.worker_nonces to service_role;
create or replace function public.planner_worker_authorized(p_token text) returns boolean language plpgsql security invoker set search_path='' as $$begin
 if p_token is null or length(p_token)<60 then return false;end if;
 update planner_private.worker_nonces set used_at=now() where hash=encode(sha256(convert_to(p_token,'UTF8')),'hex') and used_at is null and expires_at>now();return found;
end $$;
create or replace function planner_private.scheduler_tick() returns void language plpgsql security invoker set search_path='' as $$declare nonce text;begin
 if exists(select 1 from public.planner_runs r join planner_private.calls c on c.run_id=r.id where (r.state in ('queued','researching') or (r.state='cancelled' and not c.settled)) and (c.lease_until is null or c.lease_until<now())) then
 nonce=gen_random_uuid()::text||gen_random_uuid()::text;
 insert into planner_private.worker_nonces(hash,expires_at) values(encode(sha256(convert_to(nonce,'UTF8')),'hex'),now()+interval '2 minutes');
 perform net.http_post(url:='https://nxpvxsyiyigedmplsdnz.supabase.co/functions/v1/trip-planner',headers:=jsonb_build_object('Content-Type','application/json','x-planner-worker',nonce),body:='{"action":"tick"}'::jsonb,timeout_milliseconds:=45000);
 end if;
 delete from planner_private.worker_nonces where expires_at<now()-interval '10 minutes';
 update public.planner_runs set snapshot=jsonb_build_object('destination_name',snapshot->>'destination_name','items','[]'::jsonb) where created_at<now()-interval '30 days' and state in ('completed','cancelled','failed','budget_exhausted','needs_details') and jsonb_array_length(coalesce(snapshot->'items','[]'::jsonb))>0;
end $$;
-- Public and client roles still have no EXECUTE on either routine.
revoke all on function public.planner_worker_authorized(text) from public,anon,authenticated;
grant execute on function public.planner_worker_authorized(text) to service_role;
revoke all on function planner_private.scheduler_tick() from public,anon,authenticated,service_role;
update planner_private.runtime set worker_hash=null where singleton;

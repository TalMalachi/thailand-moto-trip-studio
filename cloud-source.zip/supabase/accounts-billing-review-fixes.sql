-- Review fix: admission and suspension share one account row lock.
create or replace function app_private.active_uid() returns uuid language plpgsql volatile security definer set search_path='' as $$declare uid uuid;begin
 select user_id into uid from public.account_access where user_id=auth.uid() and status='active' for share;
 if uid is null then raise insufficient_privilege using message='החשבון אינו פעיל';end if;return uid;end $$;
-- Admin authorization itself does not retain an actor row lock while waiting for
-- the global last-admin mutex / a different target account row.
create or replace function app_private.admin_uid() returns uuid language plpgsql stable security definer set search_path='' as $$declare uid uuid=auth.uid();begin
 if not app_private.is_active() or not exists(select 1 from app_private.superusers where user_id=uid) then raise insufficient_privilege;end if;return uid;end $$;
do $$declare f record;d text;begin
 for f in select p.oid from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='planner_private' and p.proname in ('start_run','overview','cancel_run','publish_run','control_run','daily_control','daily_overview','daily_review') loop
 d=pg_get_functiondef(f.oid);d=regexp_replace(d,'\mbegin\M','begin perform app_private.active_uid();','i');execute d;end loop;
 d=pg_get_functiondef('public.planner_worker_dispatch(uuid,uuid,jsonb)'::regprocedure);
 d=regexp_replace(d,'\mbegin\M',$fragment$begin perform 1 from public.account_access where user_id=(select owner_id from public.planner_runs where id=p_run) and status='active' for share;if not found then return false;end if;$fragment$,'i');execute d;
 d=pg_get_functiondef('planner_private.daily_tick_at(timestamptz)'::regprocedure);
 d=replace(d,'select * into t from public.trips where id=s.trip_id', $fragment$perform 1 from public.account_access where user_id=s.owner_id and status='active' for share;if not found then continue;end if;select * into t from public.trips where id=s.trip_id$fragment$);execute d;
end $$;
-- Review fix: bind a stable, empty destination before opening a charge page.
-- Pending accounts still cannot read or act on business data through RLS.
alter table app_private.orders drop constraint orders_trip_id_fkey;
alter table app_private.orders alter column trip_id set not null;
alter table app_private.orders add constraint orders_trip_id_fkey foreign key(trip_id) references public.trips(id) on delete restrict;
create or replace function app_private.billing_prepare(p_user uuid,p_package uuid,p_trip uuid,p_destination text,p_consent text) returns jsonb language plpgsql security definer set search_path='' as $$declare a public.account_access;v app_private.package_versions;o app_private.orders;dest text;tid uuid;details jsonb;mail text;begin
 select * into a from public.account_access where user_id=p_user for update;
 if not found or a.status not in ('pending','active') then raise insufficient_privilege;end if;
 if not exists(select 1 from app_private.billing_config where singleton and gateway_enabled and package_id=p_package) then raise check_violation using message='החבילה השתנתה או שהסליקה אינה פעילה';end if;
 select email into mail from auth.users where id=p_user and email_confirmed_at is not null;if not found then raise insufficient_privilege using message='נדרש אימות מייל לפני תשלום';end if;
 select p.details into details from app_private.profiles p where user_id=p_user;
 if details is null or not (details ?& array['name','phone','street','city','postcode','country']) then raise check_violation using message='יש להשלים פרטי חשבון וכתובת';end if;
 if p_consent is distinct from 'per-trip-v1' then raise check_violation;end if;
 if p_trip is not null then select id,destination_name into tid,dest from public.trips where id=p_trip and owner_id=p_user for update;if not found then raise insufficient_privilege;end if;
 else
 dest=trim(p_destination);if length(coalesce(dest,'')) not between 1 and 100 then raise check_violation;end if;
 select id,destination_name into tid,dest from public.trips where owner_id=p_user and lower(trim(destination_name))=lower(trim(p_destination)) for update;
 if not found then dest=trim(p_destination);insert into public.trips(owner_id,destination_name,title) values(p_user,dest,dest) returning id into tid;end if;
 end if;
 if exists(select 1 from app_private.entitlements where trip_id=tid) then raise check_violation using message='כבר נרכשה חבילת AI לטיול זה';end if;
 select * into v from app_private.package_versions where id=p_package;
 select * into o from app_private.orders where owner_id=p_user and trip_id=tid for update;
 if found then
 if o.package_id<>p_package or o.state<>'pending' then raise check_violation using message='כבר קיים תשלום או ניסיון תשלום לטיול; יש לבדוק את הסטטוס לפני ניסיון נוסף';end if;
 return jsonb_build_object('order',to_jsonb(o),'new',false);end if;
 insert into app_private.orders(owner_id,trip_id,destination_name,package_id,consent_version) values(p_user,tid,dest,p_package,p_consent) returning * into o;
 return jsonb_build_object('order',to_jsonb(o),'new',true,'package',to_jsonb(v)-'created_by','profile',details,'email',mail);end $$;
-- Review fix: purchased entitlement is independent from access status.
create or replace function app_private.billing_confirm(p_order uuid,p_fence uuid,p_low_profile uuid,p_transaction text,p_amount integer) returns jsonb language plpgsql security definer set search_path='' as $$declare o app_private.orders;v app_private.package_versions;a public.account_access;begin
 select * into a from public.account_access where user_id=(select owner_id from app_private.orders where id=p_order) for update;
 select * into o from app_private.orders where id=p_order for update;if not found then raise insufficient_privilege;end if;
 if o.state='paid' then return jsonb_build_object('paid',true,'tripId',o.trip_id);end if;
 select * into v from app_private.package_versions where id=o.package_id;
 if o.verification_fence is distinct from p_fence or p_fence is null or p_amount is distinct from v.price_agorot or p_low_profile is null or o.low_profile_id is not null and o.low_profile_id<>p_low_profile or p_transaction is null or p_transaction !~ '^[1-9][0-9]{0,19}$' then raise check_violation;end if;
 if not exists(select 1 from auth.users where id=o.owner_id and email_confirmed_at is not null) then raise insufficient_privilege;end if;
 if not exists(select 1 from public.trips where id=o.trip_id and owner_id=o.owner_id) then raise check_violation;end if;
 insert into app_private.entitlements(owner_id,trip_id,order_id,ai_runs) values(o.owner_id,o.trip_id,o.id,v.ai_runs);
 if a.status='pending' then update public.account_access set status='active',version=version+1,updated_at=now() where user_id=o.owner_id;end if;
 update app_private.orders set state='paid',paid_at=now(),low_profile_id=p_low_profile,transaction_id=p_transaction where id=o.id;
 return jsonb_build_object('paid',true,'tripId',o.trip_id,'accountActive',a.status in ('active','pending'));end $$;
-- Replacements preserve the already narrow grants on these exact signatures.

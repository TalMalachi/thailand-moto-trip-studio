create function public.valid_trip_payload(k text,p jsonb) returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare key text; v jsonb; title_key text;
begin
 if jsonb_typeof(p) is distinct from 'object' then return false;end if;
 if k not in ('booking','stop','place','gear','task') then return false;end if;
 title_key=case when k='stop' then 'place' when k='task' then 'title' else 'name' end;
 if jsonb_typeof(p->title_key) is distinct from 'string' or length(btrim(p->>title_key))=0 then return false;end if;
 for key,v in select * from jsonb_each(p) loop
  if key in ('cost','paid','day') then
   if jsonb_typeof(v) is distinct from 'number' or (v::text)::numeric<0 then return false;end if;
  elsif key='done' then
   if jsonb_typeof(v) is distinct from 'boolean' then return false;end if;
  else
   if jsonb_typeof(v) is distinct from 'string' or length(p->>key)>10000 then return false;end if;
  end if;
  if key in ('url','guide') and p->>key<>'' and (p->>key)!~* '^https?://[^[:space:]]+$' then return false;end if;
 end loop;
 if k='stop' then
  if jsonb_typeof(p->'day') is distinct from 'number' then return false;end if;
  if (p->>'day')::numeric<1 or (p->>'day')::numeric>365 or (p->>'day')::numeric<>trunc((p->>'day')::numeric) then return false;end if;
 end if;
 return true;
exception when others then return false;
end $$;
create function public.valid_trip_settings(p jsonb) returns boolean language plpgsql immutable security invoker set search_path='' as $$
begin
 if jsonb_typeof(p) is distinct from 'object' or jsonb_typeof(p->'start') is distinct from 'string' or jsonb_typeof(p->'days') is distinct from 'number' or jsonb_typeof(p->'budget') is distinct from 'number' or p->>'currency' is distinct from 'ILS' then return false;end if;
 if p->>'start'<>'' and (p->>'start')!~ '^\d{4}-\d{2}-\d{2}$' then return false;end if;
 return (p->>'days')::numeric between 1 and 365 and (p->>'days')::numeric=trunc((p->>'days')::numeric) and (p->>'budget')::numeric>=0;
exception when others then return false;
end $$;
revoke all on function public.valid_trip_payload(text,jsonb),public.valid_trip_settings(jsonb) from public,anon;
grant execute on function public.valid_trip_payload(text,jsonb),public.valid_trip_settings(jsonb) to authenticated;
alter table public.trip_items add constraint trip_payload_valid check(public.valid_trip_payload(kind,payload));
alter table public.trips add constraint trip_settings_valid check(public.valid_trip_settings(settings));

create function planner_private.daily_tick_at(p_now timestamptz) returns void language plpgsql set search_path='' as $$declare s public.agent_daily_settings;t public.trips;c uuid;r jsonb;inp jsonb;oldsub text=current_setting('request.jwt.claim.sub',true);olduid text=current_setting('request.jwt.claims',true);day date=(p_now at time zone 'Asia/Jerusalem')::date;begin
 for c in select run_id from public.agent_daily_checks where state in ('queued','awaiting_resume') and run_id is not null loop perform planner_private.daily_finalize(c);end loop;
 if (p_now at time zone 'Asia/Jerusalem')::time<'08:00' then return;end if;
 for s in select * from public.agent_daily_settings where state='active' loop
 select * into t from public.trips where id=s.trip_id for update skip locked;if not found then continue;end if;
 select * into s from public.agent_daily_settings where trip_id=t.id and state='active' for update skip locked;if not found then continue;end if;
 if day<(s.updated_at at time zone 'Asia/Jerusalem')::date or (p_now at time zone 'Asia/Jerusalem')::date=(s.updated_at at time zone 'Asia/Jerusalem')::date and (s.updated_at at time zone 'Asia/Jerusalem')::time>='08:00' then continue;end if;
 c=null;insert into public.agent_daily_checks(trip_id,owner_id,report_date) values(s.trip_id,s.owner_id,day) on conflict do nothing returning id into c;if c is null then continue;end if;
 begin
 if exists(select 1 from public.planner_runs where owner_id=s.owner_id and (state in ('queued','researching') or purpose='daily' and state='ready')) then raise exception 'כבר קיימת הרצה פעילה או מושהית; לא הופעל מחקר נוסף';end if;
 if not exists(select 1 from public.trip_items i where trip_id=t.id and kind='booking' and coalesce(payload->>'status','') not in ('הוזמן','שולם') and not exists(select 1 from public.agent_booking_requests q where q.booking_id=i.id and q.state='approved' and q.expires_at>now() and q.booking_version=i.version)) then raise exception 'אין הזמנות פתוחות לבדיקה';end if;
 inp=s.input||jsonb_build_object('start',t.settings->>'start','days',(t.settings->>'days')::integer,'budget',(t.settings->>'budget')::numeric);
 perform set_config('request.jwt.claim.sub',s.owner_id::text,true);perform set_config('request.jwt.claims',jsonb_build_object('sub',s.owner_id)::text,true);
 r=planner_private.start_run(t.id,t.version,inp,gen_random_uuid());
 update public.planner_runs set purpose='daily',snapshot=jsonb_build_object('destination_name',t.destination_name,'settings',t.settings,'items',(select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'version',i.version,'kind',i.kind,'title',coalesce(i.payload->>'name',i.payload->>'title',i.payload->>'place'),'day',i.payload->'day','category',coalesce(i.payload->>'type',i.payload->>'category'),'status',i.payload->>'status','workflowStatus',i.payload->>'workflowStatus','done',i.payload->'done','cost',i.payload->'cost','paid',i.payload->'paid','approvedUntil',(select max(q.expires_at) from public.agent_booking_requests q where q.booking_id=i.id and q.state='approved' and q.booking_version=i.version),'lastCheckedAt',(select max(ch.created_at) from public.agent_daily_checks ch where ch.trip_id=t.id and exists(select 1 from jsonb_array_elements(coalesce(ch.report->'checks','[]')) z where z->>'bookingId'=i.id::text)))),'[]') from public.trip_items i where i.trip_id=t.id)) where id=(r->>'id')::uuid;
 update public.agent_daily_checks set run_id=(r->>'id')::uuid where id=c;
 exception when others then update public.agent_daily_checks set state='skipped',report=jsonb_build_object('summary',case when sqlerrm ~ 'תקציב|יתרה|הרצה|סוכן|הזמנות|נתונ' then left(sqlerrm,300) else 'נתוני היעד אינם מאפשרים בדיקה; יש לבדוק תאריך, משך ותקציב' end,'noProviderCall',true) where id=c;end;
 perform set_config('request.jwt.claim.sub',coalesce(oldsub,''),true);perform set_config('request.jwt.claims',coalesce(olduid,'{}'),true);
 end loop;end $$;

revoke all on function planner_private.daily_tick_at(timestamptz) from public,anon,authenticated,service_role;
create or replace function planner_private.daily_tick() returns void language sql set search_path='' as $$select planner_private.daily_tick_at(now())$$;

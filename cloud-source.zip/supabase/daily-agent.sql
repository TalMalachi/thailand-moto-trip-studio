alter table public.planner_runs add column purpose text not null default 'plan' check(purpose in ('plan','daily'));
create table public.agent_daily_settings(trip_id uuid primary key references public.trips on delete cascade,owner_id uuid not null references auth.users on delete cascade,state text not null check(state in ('active','paused','stopped')),input jsonb not null,updated_at timestamptz not null default now());
create table public.agent_daily_checks(id uuid primary key default gen_random_uuid(),trip_id uuid not null references public.trips on delete cascade,owner_id uuid not null references auth.users on delete cascade,report_date date not null,run_id uuid unique references public.planner_runs,state text not null default 'queued',report jsonb not null default '{}',created_at timestamptz not null default now(),unique(trip_id,report_date));
create table public.agent_booking_requests(id uuid primary key default gen_random_uuid(),trip_id uuid not null references public.trips on delete cascade,owner_id uuid not null references auth.users on delete cascade,check_id uuid not null references public.agent_daily_checks on delete cascade,booking_id uuid not null references public.trip_items on delete cascade,booking_version bigint not null,version bigint not null default 1,state text not null default 'pending' check(state in ('pending','approved','rejected','superseded')),offer jsonb not null,expires_at timestamptz not null default now()+interval '24 hours',created_at timestamptz not null default now());
create index on public.agent_daily_checks(owner_id,trip_id,report_date desc);
create index on public.agent_booking_requests(owner_id,trip_id,created_at desc);
create index on public.agent_booking_requests(booking_id);
do $$declare t text;begin foreach t in array array['agent_daily_settings','agent_daily_checks','agent_booking_requests'] loop execute format('alter table public.%I enable row level security',t);execute format('create policy owner_read on public.%I for select to authenticated using(owner_id=(select auth.uid()))',t);execute format('revoke all on public.%I from anon,authenticated',t);execute format('grant select on public.%I to authenticated',t);execute format('grant all on public.%I to service_role',t);end loop;end $$;

create function planner_private.daily_overview(p_trip uuid) returns jsonb language plpgsql security definer set search_path='' as $$declare uid uuid=auth.uid();begin
 if uid is null or not exists(select 1 from public.trips where id=p_trip and owner_id=uid) then raise insufficient_privilege;end if;
 return jsonb_build_object('schedule',(select to_jsonb(s)-'input' from public.agent_daily_settings s where trip_id=p_trip),'baselineAvailable',exists(select 1 from public.planner_runs where trip_id=p_trip and owner_id=uid and purpose='plan'),'reports',(select coalesce(jsonb_agg(x),'[]') from (select * from public.agent_daily_checks where trip_id=p_trip order by report_date desc limit 30)x),'requests',(select coalesce(jsonb_agg(x),'[]') from (select * from public.agent_booking_requests where trip_id=p_trip order by created_at desc limit 100)x),'run',(select to_jsonb(r) from public.planner_runs r where trip_id=p_trip and purpose='daily' order by created_at desc limit 1),'budget',planner_private.overview(p_trip));end $$;

create function planner_private.daily_control(p_trip uuid,p_action text,p_version bigint) returns jsonb language plpgsql security definer set search_path='' as $$declare uid uuid=auth.uid();t public.trips;inp jsonb;r public.planner_runs;s public.agent_daily_settings;begin
 select * into t from public.trips where id=p_trip and owner_id=uid for update;if not found or uid is null then raise insufficient_privilege;end if;
 if t.version<>p_version then raise exception 'Version conflict';end if;
 if p_action is null or p_action not in ('enable','pause','resume','stop') then raise check_violation;end if;
 select * into s from public.agent_daily_settings where trip_id=p_trip for update;
 if p_action='enable' then
 select input into inp from public.planner_runs where trip_id=p_trip and owner_id=uid and purpose='plan' order by created_at desc limit 1;
 if inp is null or coalesce(t.settings->>'start','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' or coalesce((t.settings->>'budget')::numeric,0)<=0 or coalesce((t.settings->>'days')::integer,0)<=0 then raise exception 'נתוני תכנון חסרים; יש להשלים שאלון, תאריך ותקציב';end if;
 inp=inp||jsonb_build_object('start',t.settings->>'start','days',(t.settings->>'days')::integer,'budget',(t.settings->>'budget')::numeric);
 insert into public.agent_daily_settings(trip_id,owner_id,state,input) values(p_trip,uid,'active',inp) on conflict(trip_id) do update set state='active',input=excluded.input,updated_at=now();
 else
 if s.trip_id is null or (p_action='resume' and s.state<>'paused') then raise exception 'הסוכן אינו מושהה או שטרם הופעל';end if;
 update public.agent_daily_settings set state=case p_action when 'resume' then 'active' when 'pause' then 'paused' else 'stopped' end,updated_at=now() where trip_id=p_trip;
 end if;
 for r in select * from public.planner_runs where trip_id=p_trip and purpose='daily' and state in ('queued','researching','ready') loop
 if p_action='stop' then perform planner_private.cancel_run(r.id);
 elsif p_action='pause' then perform planner_private.control_run(r.id,'pause');
 elsif r.paused_at is not null then perform planner_private.control_run(r.id,'resume');end if;end loop;
 return planner_private.daily_overview(p_trip);end $$;

create function planner_private.daily_review(p_request uuid,p_version bigint,p_decision text) returns jsonb language plpgsql security definer set search_path='' as $$declare q public.agent_booking_requests;b public.trip_items;t public.trips;used numeric;allowed numeric;begin
 if auth.uid() is null or p_decision is null or p_decision not in ('approved','rejected') then raise insufficient_privilege;end if;
 -- Serialize approvals with trip edits and other offers for this trip.
 select tt.* into t from public.trips tt join public.agent_booking_requests qq on qq.trip_id=tt.id where qq.id=p_request and tt.owner_id=auth.uid() for update of tt;if not found then raise insufficient_privilege;end if;
 select * into q from public.agent_booking_requests where id=p_request and owner_id=auth.uid() for update;
 select * into b from public.trip_items where id=q.booking_id for update;
 if q.version<>p_version or q.state<>'pending' or q.expires_at<=now() or b.version<>q.booking_version or b.payload->>'status' in ('הוזמן','שולם') then raise exception 'פריטי ההצעה השתנו או שפג תוקפה; יש לרענן';end if;
 if p_decision='approved' then
 select coalesce(sum(greatest(coalesce((payload->>'cost')::numeric,0),coalesce((payload->>'paid')::numeric,0))),0) into used from public.trip_items where trip_id=t.id and kind='booking' and (payload->>'status' in ('הוזמן','שולם') or coalesce((payload->>'paid')::numeric,0)>0);
 used=used+coalesce((select sum((a.offer->>'totalCost')::numeric) from public.agent_booking_requests a join public.trip_items i on i.id=a.booking_id where a.trip_id=t.id and a.state='approved' and a.expires_at>now() and a.booking_id<>b.id and a.booking_version=i.version and coalesce(i.payload->>'status','') not in ('הוזמן','שולם')),0);
 allowed=(t.settings->>'budget')::numeric*(1+coalesce((select (input->>'budgetDeviationPct')::numeric from public.agent_daily_settings where trip_id=t.id),0)/100);
 if allowed is null or used+(q.offer->>'totalCost')::numeric>allowed then raise exception 'ההצעה חורגת מתקציב הטיול הכולל';end if;
 update public.agent_booking_requests set state='superseded',version=version+1 where booking_id=b.id and id<>q.id and state in ('pending','approved');
 end if;
 update public.agent_booking_requests set state=p_decision,version=version+1 where id=q.id;return planner_private.daily_overview(t.id);end $$;

-- Service-only materialization. Never mark a booking reserved or paid.
create function planner_private.daily_finalize(p_run uuid) returns void language plpgsql set search_path='' as $$declare r public.planner_runs;c public.agent_daily_checks;s public.agent_daily_settings;x jsonb;o jsonb;b public.trip_items;stale integer=0;n integer=0;begin
 select * into s from public.agent_daily_settings where trip_id=(select trip_id from public.planner_runs where id=p_run) for update;
 select * into r from public.planner_runs where id=p_run and purpose='daily' for update;if not found then return;end if;
 select * into c from public.agent_daily_checks where run_id=p_run for update;if not found or c.state not in ('queued','awaiting_resume') then return;end if;
 if r.state in ('queued','researching') then return;end if;
 if r.state='ready' and (r.paused_at is not null or s.state='paused') then update public.agent_daily_checks set state='awaiting_resume',report=jsonb_build_object('summary','המחקר הסתיים בזמן השהיה; פרסום הצעות ימתין להמשך') where id=c.id;return;end if;
 if r.state<>'ready' or s.state<>'active' then update public.agent_daily_checks set state='finished',report=jsonb_build_object('summary',r.message,'outcome',r.state,'spentAgorot',r.spent_agorot,'reservedAgorot',r.reserved_agorot) where id=c.id;return;end if;
 if r.artifact->>'kind'<>'daily_review' then raise check_violation;end if;
 for x in select * from jsonb_array_elements(r.artifact->'checks') loop
 select * into b from public.trip_items where id=(x->>'bookingId')::uuid and trip_id=r.trip_id and kind='booking' for update;
 if not found or b.version<>(x->>'bookingVersion')::bigint or b.payload->>'status' in ('הוזמן','שולם') then stale=stale+1;continue;end if;
 if jsonb_array_length(x->'offers')>0 then
 update public.agent_booking_requests set state='superseded',version=version+1 where booking_id=b.id and state='pending';
 for o in select * from jsonb_array_elements(x->'offers') loop
 insert into public.agent_booking_requests(trip_id,owner_id,check_id,booking_id,booking_version,offer) values(r.trip_id,r.owner_id,c.id,b.id,b.version,o||jsonb_build_object('category',x->>'category'));n=n+1;end loop;end if;end loop;
 update public.agent_daily_checks set state='finished',report=r.artifact||jsonb_build_object('staleBookings',stale,'requestsCreated',n,'spentAgorot',r.spent_agorot,'reservedAgorot',r.reserved_agorot) where id=c.id;
 update public.planner_runs set state='completed',message='הבדיקה היומית הסתיימה; הדו״ח ובקשות האישור זמינים באתר',updated_at=now() where id=r.id;end $$;

create function planner_private.daily_tick() returns void language plpgsql set search_path='' as $$declare s public.agent_daily_settings;t public.trips;c uuid;r jsonb;inp jsonb;oldsub text=current_setting('request.jwt.claim.sub',true);olduid text=current_setting('request.jwt.claims',true);day date=(now() at time zone 'Asia/Jerusalem')::date;begin
 for c in select run_id from public.agent_daily_checks where state in ('queued','awaiting_resume') and run_id is not null loop perform planner_private.daily_finalize(c);end loop;
 if (now() at time zone 'Asia/Jerusalem')::time<'08:00' then return;end if;
 for s in select * from public.agent_daily_settings where state='active' for update skip locked loop
 select * into t from public.trips where id=s.trip_id;
 if day<(s.updated_at at time zone 'Asia/Jerusalem')::date or (now() at time zone 'Asia/Jerusalem')::date=(s.updated_at at time zone 'Asia/Jerusalem')::date and (s.updated_at at time zone 'Asia/Jerusalem')::time>='08:00' then continue;end if;
 c=null;insert into public.agent_daily_checks(trip_id,owner_id,report_date) values(s.trip_id,s.owner_id,day) on conflict do nothing returning id into c;if c is null then continue;end if;
 begin
 if exists(select 1 from public.planner_runs where owner_id=s.owner_id and (state in ('queued','researching') or purpose='daily' and state='ready')) then raise exception 'כבר קיימת הרצה פעילה או מושהית; לא הופעל מחקר נוסף';end if;
 if not exists(select 1 from public.trip_items i where trip_id=t.id and kind='booking' and coalesce(payload->>'status','') not in ('הוזמן','שולם') and not exists(select 1 from public.agent_booking_requests q where q.booking_id=i.id and q.state='approved' and q.expires_at>now() and q.booking_version=i.version)) then raise exception 'אין הזמנות פתוחות לבדיקה';end if;
 inp=s.input||jsonb_build_object('start',t.settings->>'start','days',(t.settings->>'days')::integer,'budget',(t.settings->>'budget')::numeric);
 perform set_config('request.jwt.claim.sub',s.owner_id::text,true);perform set_config('request.jwt.claims',jsonb_build_object('sub',s.owner_id)::text,true);
 r=planner_private.start_run(t.id,t.version,inp,gen_random_uuid());
 update public.planner_runs set purpose='daily',snapshot=jsonb_build_object('destination_name',t.destination_name,'settings',t.settings,'items',(select coalesce(jsonb_agg(jsonb_build_object('id',i.id,'version',i.version,'kind',i.kind,'title',coalesce(i.payload->>'name',i.payload->>'title',i.payload->>'place'),'day',i.payload->'day','category',coalesce(i.payload->>'type',i.payload->>'category'),'status',i.payload->>'status','workflowStatus',i.payload->>'workflowStatus','done',i.payload->'done','cost',i.payload->'cost','paid',i.payload->'paid','approvedUntil',(select max(q.expires_at) from public.agent_booking_requests q where q.booking_id=i.id and q.state='approved' and q.booking_version=i.version),'lastCheckedAt',(select max(ch.created_at) from public.agent_daily_checks ch where ch.trip_id=t.id and exists(select 1 from jsonb_array_elements(coalesce(ch.report->'checks','[]')) z where z->>'bookingId'=i.id::text)))),'[]') from public.trip_items i where i.trip_id=t.id)) where id=(r->>'id')::uuid;
 update public.agent_daily_checks set run_id=(r->>'id')::uuid where id=c;
 exception when others then update public.agent_daily_checks set state='skipped',report=jsonb_build_object('summary',case when sqlerrm ~ 'תקציב|יתרה|הרצה|סוכן|הזמנות|נתונ' then left(sqlerrm,300) else 'נתוני היעד אינם מאפשרים בדיקה; יש לבדוק תאריך, משך ותקציב' end,'noProviderCall',true) where id=c;end;
 perform set_config('request.jwt.claim.sub',coalesce(oldsub,''),true);perform set_config('request.jwt.claims',coalesce(olduid,'{}'),true);
 end loop;end $$;

create function public.agent_daily_overview(p_trip uuid) returns jsonb language sql security invoker set search_path='' as $$select planner_private.daily_overview(p_trip)$$;
create function public.agent_daily_control(p_trip uuid,p_action text,p_version bigint) returns jsonb language sql security invoker set search_path='' as $$select planner_private.daily_control(p_trip,p_action,p_version)$$;
create function public.agent_daily_review(p_request uuid,p_version bigint,p_decision text) returns jsonb language sql security invoker set search_path='' as $$select planner_private.daily_review(p_request,p_version,p_decision)$$;
create function public.agent_daily_finalize(p_run uuid) returns void language sql security invoker set search_path='' as $$select planner_private.daily_finalize(p_run)$$;
revoke all on function planner_private.daily_overview(uuid),planner_private.daily_control(uuid,text,bigint),planner_private.daily_review(uuid,bigint,text),public.agent_daily_overview(uuid),public.agent_daily_control(uuid,text,bigint),public.agent_daily_review(uuid,bigint,text) from public,anon;
grant execute on function planner_private.daily_overview(uuid),planner_private.daily_control(uuid,text,bigint),planner_private.daily_review(uuid,bigint,text),public.agent_daily_overview(uuid),public.agent_daily_control(uuid,text,bigint),public.agent_daily_review(uuid,bigint,text) to authenticated;
revoke all on function planner_private.daily_finalize(uuid),planner_private.daily_tick(),public.agent_daily_finalize(uuid) from public,anon,authenticated;
grant execute on function planner_private.daily_finalize(uuid),public.agent_daily_finalize(uuid) to service_role;
do $$declare d text;begin
 d=pg_get_functiondef('planner_private.overview(uuid)'::regprocedure);d=replace(d,'where trip_id=p_trip and owner_id=uid order by','where trip_id=p_trip and owner_id=uid and purpose=''plan'' order by');execute d;
 d=pg_get_functiondef('planner_private.publish_run(uuid,bigint)'::regprocedure);d=replace(d,'if r.paused_at is not null','if r.purpose<>''plan'' then raise check_violation using message=''יש לאשר הצעות דרך מסך הסוכן'';end if; if r.paused_at is not null');execute d;
 d=pg_get_functiondef('planner_private.scheduler_tick()'::regprocedure);d=replace(d,'declare nonce text;begin','declare nonce text;begin perform planner_private.daily_tick();');execute d;
end $$;

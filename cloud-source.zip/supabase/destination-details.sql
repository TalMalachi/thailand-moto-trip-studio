create function public.update_trip_destination_details(p_id uuid,p_expected_version bigint,p_destination_name text,p_is_active boolean,p_settings jsonb)
returns setof public.trips language sql security invoker set search_path='' as $$
 update public.trips set destination_name=trim(p_destination_name),title=trim(p_destination_name),is_active=p_is_active,settings=settings||p_settings,version=version+1 where id=p_id and version=p_expected_version and jsonb_typeof(p_settings)='object' returning *
$$;
revoke all on function public.update_trip_destination_details(uuid,bigint,text,boolean,jsonb) from public,anon;
grant execute on function public.update_trip_destination_details(uuid,bigint,text,boolean,jsonb) to authenticated;

alter table public.trips add column destination_name text not null default 'תאילנד' check(length(trim(destination_name)) between 1 and 100);
alter table public.trips add column is_active boolean not null default true;
alter table public.trips alter column title set default 'Motor Trip Studio';
drop index public.trips_owner_id;
create unique index trips_owner_destination on public.trips(owner_id,lower(trim(destination_name))) where owner_id is not null;
create function public.update_trip_destination(p_id uuid,p_expected_version bigint,p_destination_name text,p_is_active boolean)
returns setof public.trips language sql security invoker set search_path='' as $$
 update public.trips set destination_name=trim(p_destination_name),title=trim(p_destination_name),is_active=p_is_active,version=version+1 where id=p_id and version=p_expected_version returning *
$$;
revoke all on function public.update_trip_destination(uuid,bigint,text,boolean) from public,anon;
grant execute on function public.update_trip_destination(uuid,bigint,text,boolean) to authenticated;

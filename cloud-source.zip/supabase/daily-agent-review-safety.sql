create or replace function planner_private.daily_review(p_request uuid,p_version bigint,p_decision text) returns jsonb language plpgsql security definer set search_path='' as $$declare q public.agent_booking_requests;b public.trip_items;t public.trips;used numeric;allowed numeric;begin
 if auth.uid() is null or p_decision is null or p_decision not in ('approved','rejected') then raise insufficient_privilege;end if;
 -- Serialize approvals with trip edits and other offers for this trip.
 select tt.* into t from public.trips tt join public.agent_booking_requests qq on qq.trip_id=tt.id where qq.id=p_request and tt.owner_id=auth.uid() for update of tt;if not found then raise insufficient_privilege;end if;
 select * into q from public.agent_booking_requests where id=p_request and owner_id=auth.uid() for update;
 select * into b from public.trip_items where id=q.booking_id for update;
 if q.trip_version<>t.version or q.version<>p_version or q.state<>'pending' or q.expires_at<=now() or b.version<>q.booking_version or b.payload->>'status' in ('הוזמן','שולם') then raise exception 'פריטי ההצעה השתנו או שפג תוקפה; יש לרענן';end if;
 if p_decision='approved' then
 select coalesce(sum(greatest(coalesce((payload->>'cost')::numeric,0),coalesce((payload->>'paid')::numeric,0))),0) into used from public.trip_items where trip_id=t.id and kind='booking' and (payload->>'status' in ('הוזמן','שולם') or coalesce((payload->>'paid')::numeric,0)>0);
 used=used+coalesce((select sum((a.offer->>'totalCost')::numeric) from public.agent_booking_requests a join public.trip_items i on i.id=a.booking_id where a.trip_id=t.id and a.state='approved' and a.expires_at>now() and a.booking_id<>b.id and a.booking_version=i.version and a.trip_version=t.version and coalesce(i.payload->>'status','') not in ('הוזמן','שולם')),0);
 allowed=(t.settings->>'budget')::numeric*(1+coalesce((select (input->>'budgetDeviationPct')::numeric from public.agent_daily_settings where trip_id=t.id),0)/100);
 if allowed is null or used+(q.offer->>'totalCost')::numeric>allowed then raise exception 'ההצעה חורגת מתקציב הטיול הכולל';end if;
 update public.agent_booking_requests set state='superseded',version=version+1 where booking_id=b.id and id<>q.id and state in ('pending','approved');
 end if;
 update public.agent_booking_requests set state=p_decision,version=version+1 where id=q.id;return planner_private.daily_overview(t.id);end $$;

-- Service-only materialization. Never mark a booking reserved or paid.
create or replace function planner_private.daily_finalize(p_run uuid) returns void language plpgsql set search_path='' as $$declare r public.planner_runs;c public.agent_daily_checks;s public.agent_daily_settings;t public.trips;x jsonb;o jsonb;b public.trip_items;stale integer=0;n integer=0;expired integer=0;valid_until timestamptz;begin
 select * into t from public.trips where id=(select trip_id from public.planner_runs where id=p_run) for update;
 select * into s from public.agent_daily_settings where trip_id=(select trip_id from public.planner_runs where id=p_run) for update;
 select * into r from public.planner_runs where id=p_run and purpose='daily' for update;if not found then return;end if;
 select * into c from public.agent_daily_checks where run_id=p_run for update;if not found then return;end if;
 if c.state='finished' then update public.agent_daily_checks set report=report||jsonb_build_object('spentAgorot',r.spent_agorot,'reservedAgorot',r.reserved_agorot)||case when r.state in ('cancelled','failed','budget_exhausted','needs_details') then jsonb_build_object('summary',r.message,'outcome',r.state) else '{}'::jsonb end where id=c.id;return;end if;
 if c.state not in ('queued','awaiting_resume') then return;end if;
 if r.state in ('queued','researching') then return;end if;
 if r.state='ready' and (r.paused_at is not null or s.state='paused') then update public.agent_daily_checks set state='awaiting_resume',report=jsonb_build_object('summary','המחקר הסתיים בזמן השהיה; פרסום הצעות ימתין להמשך') where id=c.id;return;end if;
 if r.state<>'ready' or s.state<>'active' then update public.agent_daily_checks set state='finished',report=jsonb_build_object('summary',r.message,'outcome',r.state,'spentAgorot',r.spent_agorot,'reservedAgorot',r.reserved_agorot) where id=c.id;return;end if;
 if r.artifact->>'kind'<>'daily_review' then raise check_violation;end if;
 valid_until=coalesce((r.artifact->>'researchedAt')::timestamptz,r.created_at)+interval '24 hours';
 for x in select * from jsonb_array_elements(r.artifact->'checks') loop
 select * into b from public.trip_items where id=(x->>'bookingId')::uuid and trip_id=r.trip_id and kind='booking' for update;
 if t.version<>r.trip_version or not found or b.version<>(x->>'bookingVersion')::bigint or b.payload->>'status' in ('הוזמן','שולם') then stale=stale+1;continue;end if;
 if jsonb_array_length(x->'offers')>0 and valid_until<=now() then expired=expired+jsonb_array_length(x->'offers');continue;end if;
 if jsonb_array_length(x->'offers')>0 then
 update public.agent_booking_requests set state='superseded',version=version+1 where booking_id=b.id and state='pending';
 for o in select * from jsonb_array_elements(x->'offers') loop
 insert into public.agent_booking_requests(trip_id,owner_id,check_id,booking_id,booking_version,trip_version,expires_at,offer) values(r.trip_id,r.owner_id,c.id,b.id,b.version,r.trip_version,valid_until,o||jsonb_build_object('category',x->>'category'));n=n+1;end loop;end if;end loop;
 update public.agent_daily_checks set state='finished',report=r.artifact||jsonb_build_object('staleBookings',stale,'expiredOffers',expired,'requestsCreated',n,'spentAgorot',r.spent_agorot,'reservedAgorot',r.reserved_agorot) where id=c.id;
 update public.planner_runs set state='completed',message='הבדיקה היומית הסתיימה; הדו״ח ובקשות האישור זמינים באתר',updated_at=now() where id=r.id;end $$;

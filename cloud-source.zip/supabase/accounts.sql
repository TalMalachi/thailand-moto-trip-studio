-- Account authorization. Apply before enabling public registration.
create schema app_private;
revoke all on schema app_private from public,anon,authenticated;
grant usage on schema app_private to authenticated,service_role;
create table public.account_access(
 user_id uuid primary key references auth.users on delete cascade,
 status text not null default 'pending' check(status in ('pending','active','suspended','closed')),
 version bigint not null default 1,updated_at timestamptz not null default now()
);
alter table public.account_access enable row level security;
revoke all on public.account_access from anon,authenticated;
grant select on public.account_access to authenticated;
grant all on public.account_access to service_role;
create policy own_status on public.account_access for select to authenticated using(user_id=(select auth.uid()));
create table app_private.superusers(user_id uuid primary key references auth.users on delete cascade);
create table app_private.profiles(user_id uuid primary key references auth.users on delete cascade,details jsonb not null default '{}',updated_at timestamptz not null default now());
create table app_private.account_audit(id bigint generated always as identity primary key,actor uuid not null,target uuid not null,old_status text not null,new_status text not null,reason text not null,created_at timestamptz not null default now());
create table app_private.package_versions(id uuid primary key default gen_random_uuid(),name text not null check(length(trim(name)) between 1 and 80),price_agorot integer not null check(price_agorot between 100 and 10000000),ai_runs integer not null check(ai_runs between 1 and 10000),created_by uuid not null,created_at timestamptz not null default now());
create table app_private.billing_config(singleton boolean primary key default true check(singleton),package_id uuid references app_private.package_versions,version bigint not null default 1);
insert into app_private.billing_config(singleton) values(true);
-- Bootstrap the established sole owner only. Abort rather than guessing in a multi-user project.
do $$declare uid uuid;begin
 if (select count(*) from auth.users)<>1 then raise exception 'Explicit owner bootstrap required';end if;
 select id into uid from auth.users where email_confirmed_at is not null;
 if uid is null or not exists(select 1 from public.trips where owner_id=uid) then raise exception 'Established verified owner required';end if;
 insert into public.account_access(user_id,status) values(uid,'active');
 insert into app_private.superusers values(uid);
end $$;
create function app_private.new_account() returns trigger language plpgsql security definer set search_path='' as $$begin
 insert into public.account_access(user_id) values(new.id);return new;end $$;
revoke all on function app_private.new_account() from public,anon,authenticated;
create trigger create_account_access after insert on auth.users for each row execute function app_private.new_account();
create function app_private.is_active() returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.account_access where user_id=auth.uid() and status='active')$$;
create function app_private.user_active(p_user uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.account_access where user_id=p_user and status='active')$$;
create function app_private.active_uid() returns uuid language plpgsql stable security definer set search_path='' as $$begin
 if not app_private.is_active() then raise insufficient_privilege using message='החשבון אינו פעיל';end if;return auth.uid();end $$;
create function app_private.admin_uid() returns uuid language plpgsql stable security definer set search_path='' as $$declare uid uuid=app_private.active_uid();begin
 if not exists(select 1 from app_private.superusers where user_id=uid) then raise insufficient_privilege;end if;return uid;end $$;
create function public.account_assert_active() returns uuid language sql security invoker set search_path='' as $$select app_private.active_uid()$$;
create function app_private.account_state() returns jsonb language plpgsql stable security definer set search_path='' as $$declare uid uuid=auth.uid();result jsonb;begin
 if uid is null then raise insufficient_privilege;end if;
 select jsonb_build_object('status',a.status,'version',a.version,'isSuperuser',a.status='active' and exists(select 1 from app_private.superusers where user_id=uid),'emailVerified',u.email_confirmed_at is not null,'profile',coalesce(p.details,'{}'::jsonb),'package',(select to_jsonb(v)-'created_by' from app_private.package_versions v join app_private.billing_config c on c.package_id=v.id where c.singleton),'billingVersion',(select version from app_private.billing_config where singleton),'checkoutEnabled',false) into result from public.account_access a join auth.users u on u.id=a.user_id left join app_private.profiles p on p.user_id=a.user_id where a.user_id=uid;
 if result is null then raise insufficient_privilege;end if;return result;end $$;
create function public.account_state() returns jsonb language sql security invoker set search_path='' as $$select app_private.account_state()$$;
create function app_private.save_profile(p_details jsonb) returns jsonb language plpgsql security definer set search_path='' as $$declare uid uuid=auth.uid();k text;clean jsonb='{}';v text;begin
 if uid is null or not exists(select 1 from public.account_access where user_id=uid and status in ('pending','active')) then raise insufficient_privilege;end if;
 if p_details is null or jsonb_typeof(p_details)<>'object' or octet_length(p_details::text)>4000 then raise check_violation;end if;
 for k in select unnest(array['name','phone','street','city','postcode','country']) loop
 if jsonb_typeof(p_details->k) is distinct from 'string' then raise check_violation using message='פרטי הרשמה חסרים';end if;
 v=trim(p_details->>k);if length(v) not between 1 and 200 then raise check_violation using message='פרטי הרשמה חסרים';end if;
 clean=clean||jsonb_build_object(k,v);end loop;
 if exists(select 1 from jsonb_object_keys(p_details) x where x not in ('name','phone','street','city','postcode','country')) then raise check_violation;end if;
 insert into app_private.profiles(user_id,details) values(uid,clean) on conflict(user_id) do update set details=excluded.details,updated_at=now();return clean;end $$;
create function public.account_save_profile(p_details jsonb) returns jsonb language sql security invoker set search_path='' as $$select app_private.save_profile(p_details)$$;
create function app_private.admin_accounts(p_offset integer,p_query text) returns jsonb language plpgsql stable security definer set search_path='' as $$begin
 perform app_private.admin_uid();if p_offset is null or p_offset not between 0 and 100000 or p_query is null or length(p_query)>200 then raise check_violation;end if;
 return jsonb_build_object('accounts',(select coalesce(jsonb_agg(x),'[]') from (select a.*,u.email,u.email_confirmed_at is not null as email_verified,coalesce(p.details->>'name','') as name,exists(select 1 from app_private.superusers s where s.user_id=a.user_id) as is_superuser from public.account_access a join auth.users u on u.id=a.user_id left join app_private.profiles p on p.user_id=a.user_id where p_query='' or position(lower(p_query) in lower(coalesce(u.email,'')||' '||coalesce(p.details->>'name','')))>0 order by a.updated_at desc,a.user_id limit 51 offset p_offset)x));end $$;
create function public.admin_accounts(p_offset integer default 0,p_query text default '') returns jsonb language sql security invoker set search_path='' as $$select app_private.admin_accounts(p_offset,p_query)$$;
create function app_private.admin_status(p_user uuid,p_version bigint,p_status text,p_reason text) returns jsonb language plpgsql security definer set search_path='' as $$declare actor uuid=app_private.admin_uid();a public.account_access;r public.planner_runs;c planner_private.calls;begin
 -- Serialize administrators to preserve the last-active-admin invariant.
 perform pg_advisory_xact_lock(72731001);
 select * into a from public.account_access where user_id=p_user for update;if not found then raise insufficient_privilege;end if;
 if a.version is distinct from p_version then raise serialization_failure using message='Version conflict';end if;
 if p_status is null or p_status not in ('pending','active','suspended','closed') or length(trim(coalesce(p_reason,''))) not between 3 and 500 then raise check_violation using message='יש לבחור מצב ולציין סיבה';end if;
 if p_status<>'active' and exists(select 1 from app_private.superusers where user_id=p_user) and not exists(select 1 from app_private.superusers s join public.account_access aa on aa.user_id=s.user_id where aa.status='active' and aa.user_id<>p_user) then raise check_violation using message='לא ניתן לחסום את מנהל המערכת הפעיל האחרון';end if;
 if p_status='active' and not exists(select 1 from auth.users where id=p_user and email_confirmed_at is not null) then raise check_violation using message='נדרש אימות כתובת המייל לפני הפעלה';end if;
 update public.account_access set status=p_status,version=version+1,updated_at=now() where user_id=p_user;
 insert into app_private.account_audit(actor,target,old_status,new_status,reason) values(actor,p_user,a.status,p_status,trim(p_reason));
 if p_status<>'active' then
 update public.agent_daily_settings set state='stopped',updated_at=now() where owner_id=p_user;
 for r in select * from public.planner_runs where owner_id=p_user and state in ('queued','researching','ready') order by id for update loop
 select * into c from planner_private.calls where run_id=r.id for update;
 if c.dispatched_at is null and not coalesce(c.settled,true) then
 update planner_private.monthly_budget set reserved_agorot=reserved_agorot-r.reserved_agorot where owner_id=r.owner_id and month=r.month;
 update planner_private.calls set settled=true,fence=gen_random_uuid(),lease_until=null where run_id=r.id;
 r.reserved_agorot=0;end if;
 update public.planner_runs set state='cancelled',paused_at=null,artifact=null,reserved_agorot=r.reserved_agorot,message='ההרצה בוטלה עקב שינוי סטטוס החשבון',updated_at=now() where id=r.id;
 end loop;end if;
 return jsonb_build_object('user_id',p_user,'status',p_status,'version',a.version+1);end $$;
create function public.admin_account_status(p_user uuid,p_version bigint,p_status text,p_reason text) returns jsonb language sql security invoker set search_path='' as $$select app_private.admin_status(p_user,p_version,p_status,p_reason)$$;
create function app_private.admin_package(p_version bigint,p_name text,p_price_agorot integer,p_ai_runs integer) returns jsonb language plpgsql security definer set search_path='' as $$declare uid uuid=app_private.admin_uid();v app_private.package_versions;c app_private.billing_config;begin
 select * into c from app_private.billing_config where singleton for update;
 if c.version is distinct from p_version then raise serialization_failure using message='Version conflict';end if;
 insert into app_private.package_versions(name,price_agorot,ai_runs,created_by) values(trim(p_name),p_price_agorot,p_ai_runs,uid) returning * into v;
 update app_private.billing_config set package_id=v.id,version=version+1 where singleton;return to_jsonb(v)-'created_by';end $$;
create function public.admin_package_save(p_version bigint,p_name text,p_price_agorot integer,p_ai_runs integer) returns jsonb language sql security invoker set search_path='' as $$select app_private.admin_package(p_version,p_name,p_price_agorot,p_ai_runs)$$;
-- All business tables retain their owner policies AND require current active status.
do $$declare t text;f record;definition text;begin
 foreach t in array array['trips','trip_items','planner_runs','agent_daily_settings','agent_daily_checks','agent_booking_requests'] loop
 execute format('create policy active_account on public.%I as restrictive for all to authenticated using ((select app_private.is_active())) with check ((select app_private.is_active()))',t);end loop;
 for f in select p.oid from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='planner_private' and p.proname in ('start_run','overview','cancel_run','publish_run','control_run','daily_control','daily_overview','daily_review') loop
 definition=pg_get_functiondef(f.oid);if position('auth.uid()' in definition)=0 then raise exception 'Missing planner owner gate';end if;
 execute replace(definition,'auth.uid()','app_private.active_uid()');end loop;
 definition=pg_get_functiondef('public.planner_worker_dispatch(uuid,uuid,jsonb)'::regprocedure);
 execute replace(definition,$fragment$and state='queued'$fragment$,$fragment$and app_private.user_active(owner_id) and state='queued'$fragment$);
 definition=pg_get_functiondef('public.planner_worker_claim()'::regprocedure);
 execute replace(definition,$fragment$where ((rr.state=$fragment$,$fragment$where (app_private.user_active(rr.owner_id) or cc.dispatched_at is not null) and ((rr.state=$fragment$);
 definition=pg_get_functiondef('planner_private.daily_tick_at(timestamptz)'::regprocedure);
 execute replace(definition,$fragment$where state='active' loop$fragment$,$fragment$where state='active' and app_private.user_active(owner_id) loop$fragment$);
 definition=pg_get_functiondef('planner_private.daily_due(timestamptz)'::regprocedure);
 execute replace(definition,$fragment$where s.state='active'$fragment$,$fragment$where s.state='active' and app_private.user_active(s.owner_id)$fragment$);
 definition=pg_get_functiondef('planner_private.daily_finalize(uuid)'::regprocedure);
 execute replace(definition,$fragment$if r.state<>'ready' or s.state<>'active' then$fragment$,$fragment$if r.state<>'ready' or s.state<>'active' or not app_private.user_active(r.owner_id) then$fragment$);
end $$;
-- No blanket function EXECUTE or table privileges for new private objects.
revoke all on all tables in schema app_private from public,anon,authenticated;
revoke all on all functions in schema app_private from public,anon,authenticated;
grant all on all tables in schema app_private to service_role;
grant usage,select on all sequences in schema app_private to service_role;
grant execute on all functions in schema app_private to service_role;
grant execute on function app_private.is_active(),app_private.active_uid(),app_private.account_state(),app_private.save_profile(jsonb),app_private.admin_accounts(integer,text),app_private.admin_status(uuid,bigint,text,text),app_private.admin_package(bigint,text,integer,integer) to authenticated;
do $$declare f record;t text;begin
 for f in select p.oid::regprocedure signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname in ('account_state','account_assert_active','account_save_profile','admin_accounts','admin_account_status','admin_package_save') loop
 execute format('revoke all on function %s from public,anon',f.signature);execute format('grant execute on function %s to authenticated',f.signature);end loop;
 foreach t in array array['superusers','profiles','account_audit','package_versions','billing_config'] loop execute format('alter table app_private.%I enable row level security',t);end loop;
 if exists(select 1 from pg_publication where pubname='supabase_realtime') then alter publication supabase_realtime add table public.account_access;end if;
end $$;

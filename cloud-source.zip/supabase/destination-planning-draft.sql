-- Read the owner's saved wizard configuration for future daily runs.
-- Existing version fences make prior proposals stale when these settings change.
do $$declare d text;old text='inp=s.input||jsonb_build_object';begin
 d=pg_get_functiondef('planner_private.daily_tick_at(timestamptz)'::regprocedure);
 if position(old in d)=0 then raise exception 'Unexpected daily input contract';end if;
 d=replace(d,old,'inp=s.input||coalesce(t.settings->''planningDraft''->''input'',''{}''::jsonb)||jsonb_build_object');execute d;
 d=pg_get_functiondef('planner_private.daily_control(uuid,text,bigint)'::regprocedure);
 if position('inp=inp||jsonb_build_object' in d)=0 then raise exception 'Unexpected enable input contract';end if;
 d=replace(d,'inp=inp||jsonb_build_object','inp=inp||coalesce(t.settings->''planningDraft''->''input'',''{}''::jsonb)||jsonb_build_object');execute d;
end $$;

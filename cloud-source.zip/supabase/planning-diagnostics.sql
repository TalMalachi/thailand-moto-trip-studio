-- Read-only inspection of completed provider responses. No ledger writes or generation.
create function public.planner_worker_inspect(p_run uuid) returns jsonb language sql security invoker set search_path='' as $$
 select jsonb_build_object('run',to_jsonb(r),'call',to_jsonb(c))
 from public.planner_runs r join planner_private.calls c on c.run_id=r.id
 where r.id=p_run and c.response_id is not null and c.settled
 and r.state in ('needs_details','ready','failed','budget_exhausted','cancelled','completed')
$$;
revoke all on function public.planner_worker_inspect(uuid) from public,anon,authenticated;
grant execute on function public.planner_worker_inspect(uuid) to service_role;

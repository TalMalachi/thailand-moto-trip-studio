alter table public.planner_runs add column progress jsonb not null default '{"stage":"queued"}'::jsonb;
create function public.planner_worker_progress(p_run uuid,p_fence uuid,p_stage text,p_provider_status text,p_searches integer,p_records integer,p_release boolean) returns boolean language plpgsql security invoker set search_path='' as $$
declare r public.planner_runs; events jsonb;begin
 if p_stage is null or p_searches is null or p_records is null or p_release is null or p_stage not in ('submitting','submitted','provider_queued','provider_working','researching','drafting','validating','provider_retry') or p_searches not between 0 and 1 or p_records not between 0 and 500 or (p_provider_status is not null and p_provider_status not in ('queued','in_progress','completed','failed','cancelled','incomplete','unavailable')) then raise check_violation;end if;
 select rr.* into r from public.planner_runs rr join planner_private.calls c on c.run_id=rr.id where rr.id=p_run and rr.state in ('queued','researching') and c.fence=p_fence and c.lease_until>now() and not c.settled for update of rr;
 if not found then return false;end if;
 events=coalesce(r.progress->'events','[]'::jsonb);
 if r.progress->>'stage' is distinct from p_stage then
  select coalesce(jsonb_agg(e order by ord),'[]'::jsonb) into events from jsonb_array_elements(events) with ordinality z(e,ord) where ord>jsonb_array_length(events)-31;
  events=events||jsonb_build_array(jsonb_build_object('stage',p_stage,'at',now()));
 end if;
 update public.planner_runs set progress=jsonb_build_object('stage',p_stage,'checkedAt',now(),'providerStatus',p_provider_status,'searches',p_searches,'records',p_records,'events',events),updated_at=now() where id=p_run;
 -- A finished status check need not retain the 90-second crash-recovery lease.
 if p_release then update planner_private.calls set lease_until=now()+interval '10 seconds' where run_id=p_run and fence=p_fence;end if;
 return true;
end $$;
revoke all on function public.planner_worker_progress(uuid,uuid,text,text,integer,integer,boolean) from public,anon,authenticated;
grant execute on function public.planner_worker_progress(uuid,uuid,text,text,integer,integer,boolean) to service_role;

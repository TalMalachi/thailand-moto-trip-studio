# Motor Trip Studio design system

Intent: a map-first personal travel planning tool for iPhone Safari and desktop, in Hebrew RTL. Preserve private cloud data and existing workflows. No framework migration or new external fonts.

## Visual direction

A daylight travel workspace with a dark pine masthead, readable planning records, and a consistent outlined SVG icon set. Visual hierarchy comes from day numbers, titles, status badges, and clear actions. Avoid decorative gradients, stock imagery, or motion that competes with trip information.

## Tokens

- Ink: #123235
- Primary pine: #12665B; pressed: #0B4D45
- Canvas: #F3F7F6; surface: #FFFFFF
- Secondary text: #526B6D; separators: #D4E1DE
- Focus accent: #A95129; destructive text: #A42D35
- Typography: one system sans family with native Hebrew support; body 16px, readable 1.6 line height; headings 20–28px, labels 14–15px.
- Spacing follows a 4/8px rhythm. Distinguish primary panels (18px radius), records (14px), and buttons (12px).

## Navigation and content

- Four persistent primary sections: Route, Bookings, Places, Tasks; More exposes Overview, Gear, and Settings.
- On phones, navigation is fixed at the bottom with safe-area padding. Reserve content padding so controls are never hidden behind it. On desktop, the same navigation sits above the content.
- Route retains Map first, Daily Plan second. Preserve responsive, internally scrolling popups and both navigation providers.
- Records use a semantic heading, badges, labeled metadata and expandable long notes. Preserve complete text and keep edit/delete actions reachable.
- Unpriced drafts show “טרם תומחר”; confirmed zero-cost bookings show zero. No data migration or amount changes.
- Forms use native inputs with labels, 16px text, visible focus and touch-sized actions. Failed saves retain draft values and show status inside the editor.

## Research and review

UI UX Pro Max searches for travel/personal planning returned agency and event marketing templates; these were not adopted as a verified product match. The visual direction above is a deliberate custom design. Matched touch-target and spacing guidance informs interaction sizing. Review against the current Vercel Web Interface Guidelines and the skill’s accessibility/touch/performance checklist.

## Validation

Run the existing application test suite plus navigation, draft pricing and failed-save editor tests. Check contrast ratios, asset version hashes, and public login rendering after publication. Authenticated layouts are covered by DOM-based UI tests; do not claim real-device or signed-in visual testing unless actually performed.

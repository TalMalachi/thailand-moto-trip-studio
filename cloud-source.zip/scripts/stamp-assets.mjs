import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const revision=createHash('sha256').update(await readFile('app.js')).digest('hex').slice(0,12);
const html=await readFile('index.html','utf8');
if(!/src="\.\/app\.js(?:\?v=[a-f0-9]+)?"/.test(html))throw Error('App entry point missing');
const cssRevision=createHash('sha256').update(await readFile('app.css')).digest('hex').slice(0,12);
const versionedHtml=html.replace(/href="\.\/app\.css(?:\?v=[a-f0-9]+)?"/,'href="./app.css?v='+cssRevision+'"');
await writeFile('index.html',versionedHtml.replace(/src="\.\/app\.js(?:\?v=[a-f0-9]+)?"/,'src="./app.js?v='+revision+'"'));
console.log('Asset revision: '+revision);

# סוכן תכנון יעד — הפעלה ותפעול

## מה נוסף
בעריכת יעד: תכנון יעד → שאלון → סיכום ואישור נתונים → הרצה → בדיקת התכנון → הוספה לאתר. השאלון מבדיל בין תקציב טיול לבין תקציב הפעלת הסוכן. מותר מחקר ותכנון; אין רכישות, חיובים, הודעות או אישור מדיניות בידי הסוכן.

מגבלות: 20 ₪ לכל חשבון בחודש קלנדרי לפי Asia/Jerusalem, משותף לכל היעדים; עד 5 ₪ להרצה. בשלב הראשון אין גבייה מהלקוח. מונים, שריונים ותעריפים מנוהלים בשרת בלבד. קריאה לספק מחייבת שריון עלות מרבית מראש; פעולה מקבילית אינה יכולה להשתמש באותה יתרה. עלות לא ידועה נשארת משוריינת עד בדיקה מנהלית. לא נשלח ניסיון חוזר לקריאת יצירה שתוצאתה אינה ידועה.

לצורך שמירת התקרה, גרסה זו משתמשת בתגובה אחת ובקריאת מחקר ציבורי אחת לכל הרצה. המחקר עשוי להיות חלקי; אין בכך אישור למחיר, זמינות או הזמנה. הצעות שינוי תאריך מעל 15% חיסכון הן הערכות עם מקורות, דורשות אישור, ואינן משנות אוטומטית תאריך מעבר לטווח שאושר. מידע קיים נשמר. הצעות חדשות דורשות בדיקה כדי למנוע כפילות.

## מצב פריסה
Schema: supabase/planning.sql; scheduler: supabase/planning-scheduler.sql then supabase/planning-scheduler-nonces.sql. Gateway/worker: trip-planner. מקורות: server/planning-worker.js, src/planning.js. הפונקציה בודקת בעצמה משתמש דרך Supabase Auth; verify_jwt כבוי ברמת שער Supabase כדי לאפשר גם את המתזמן עם טוקן התעוררות חד־פעמי. בקשה חסרת זיהוי או עם טוקן עובד מזויף נדחית. אין חשיפת מפתחות למודל או לדפדפן.

## הפעלה מאובטחת (מנהל בלבד)
1. פתח https://supabase.com/dashboard/project/nxpvxsyiyigedmplsdnz/functions/secrets . אין להזין מפתח בצ׳אט, בקוד האתר או ב-GitHub.
2. צור מפתח API ייעודי בפרויקט OpenAI עם הרשאות Responses הנדרשות בלבד ומגבלת שימוש/התראות בצד הספק כהגנה נוספת. העלות היא בחשבון המפעיל, ולא במנוי ChatGPT של הלקוח.
3. שמור OPENAI_API_KEY בתור Supabase Edge Function secret.
4. בדוק מחדש מחירון רשמי, זמינות המודל וגבולות חיוב של web_search/background. שמור PLANNER_PRICING_JSON: דוגמה בלבד, יש לאמת ביום ההפעלה:

```json
{"model":"gpt-4.1-mini-2025-04-14","inputUsdPerMillion":0.4,"outputUsdPerMillion":1.6,"searchUsdPerCall":0.01,"ilsPerUsdCeiling":4,"feeMultiplier":1.25,"validUntil":"REPLACE_WITH_ISO_EXPIRY_WITHIN_31_DAYS"}
```

ilsPerUsdCeiling הוא גבול המרה שמרני בש״ח לדולר; feeMultiplier מכסה עמלות/מס לפי חשבון המפעיל. אין לבחור ערכים שאינם מכסים את העלות בפועל. המערכת דוחה תמחור חסר, שפג תוקפו, תעריפים מתחת למינימום הידוע או תמחור שמצריך יותר מ-5 ₪ לשריון המרבי. אין להפעיל אם גבולות החיוב אינם ניתנים לאימות.
5. רק לאחר אימות התמחור והיכולות: שמור PLANNER_COSTS_VERIFIED=true ו-PLANNER_ENABLED=true. מפתח לבדו אינו מפעיל את הסוכן. בצע בדיקת עשן קצרה ביעד בדיקה; העלות נספרת בתקציב החשבון. אמת חשבונית/usage לפני שימוש רחב.
6. חזור לעריכת יעד → תכנון יעד. לפני הרצה מוצג אישור העברת נתוני התכנון הנחוצים לספק AI. רשומות קיימות נשלחות רק כתמצית שמות, סוגים וגרסאות, ללא מזהי הזמנה או רשומות אישיות חופשיות; הגדרות מדיניות עשויות לכלול העדפות חופשיות ולכן אין להזין בהן סודות.

## פיקוח ועצירה
PLANNER_ENABLED=false מונע הרצות חדשות. משתמש יכול לעצור הרצה דרך המסך. פעולות שכבר נשלחו עשויות להסתיים ולצרוך שריון; ביטול מונע פרסום. תוצאה ישנה או עובד עם lease/fence ישן אינם רשאים לפרסם. עבודה שחרגה מ-15 דקות תבוטל בעת הבדיקה הבאה.

תכנון מתפרסם בתוספת אטומית ורק אם גרסת היעד וכל גרסאות הפריטים לא השתנו. סתירה מחייבת תכנון מחודש; אין לדרוס מידע. מזהי planner_run_id ו-legacy_id מאפשרים מעקב ומונעים הוספה כפולה באותו אישור.

תעריף הוצאות שמרני משתמש במחיר ללא הנחת cache, רזרבת המרה/עמלות ותקצוב תוכן חיפוש. הסכום בתצוגה הוא רישום עלות לצורך מגבלה, לא חיוב לקוח ולא חשבונית הספק. לאחר כשל עמום אין לשחרר שריון על סמך היעדר תשובה: יש להתאים Usage/חשבונית הספק, ואז לתקן באופן מבוקר את הרשומה והשריון בחודש המקורי. אין ממשק לקוח לשינוי ledger.

המכסה מכסה פעולות AI ומחקר משויכות. מנוי אירוח/תשתית, אם יידרש, אינו כלול בה ואסור להפעיל מסלול בתשלום בלי החלטה נפרדת. המתזמן מבצע קריאת Edge רק כשיש עבודה, וטוקן ההתעוררות תקף לשתי דקות ולשימוש יחיד. לא נשלח לתור מפתח ספק או סוד שרת קבוע. הרשאות pg_net מנוהלות בידי Supabase; מידע אישי והוראות תכנון אינם נכללים בבקשת ההתעוררות. פרטי snapshot של עבודות סופיות מצטמצמים לאחר 30 יום; תוצאות ומקורות נשמרים עם היעד. טבלאות פרטיות עם RLS וללא מדיניות הן חסימה מכוונת לכל לקוח.

## אימות מפתחים
npm test; npm run build. בדיקות DB: supabase/tests/planning.sql ו-planning-lifecycle.sql, עם rollback. בניית פונקציה: npm run build:planner. יש לפרוס מחדש גם את הפונקציה אחרי שינוי במודול התכנון המשותף.

מקורות רשמיים שנבדקו בפיתוח:
- https://developers.openai.com/api/docs/models/gpt-4.1-mini
- https://developers.openai.com/api/docs/pricing
- https://developers.openai.com/api/docs/guides/tools-web-search
- https://developers.openai.com/api/docs/guides/background
- https://supabase.com/docs/guides/functions/schedule-functions
- https://supabase.com/docs/guides/functions/auth

## Validation and diagnostics
Provider responses use a strict JSON Schema with the five supported record types. The server independently rechecks dates, ownership, booking status, costs and researched sources; schema compliance is not proof of factual correctness. Validation failures return bounded diagnostic codes, never raw provider content. The browser preserves safe server error messages from non-2xx responses.

Apply `supabase/planning-diagnostics.sql` for server-only read-only inspection. An internal `tick` with `inspectRunId` requires the same expiring, single-use scheduler nonce. It retrieves a completed provider response, revalidates it without generation or ledger mutations, and returns only state, safe error code and record/source counts. Anonymous and authenticated client roles have no EXECUTE on the inspection RPC. Temporary provider retention can make older responses unavailable.

## Live progress
Apply `supabase/planning-progress.sql`. Worker heartbeats record only verified stages, provider status, completed search counts and server timestamps. Stage changes append a bounded activity timeline; repeated checks update the heartbeat without duplicating events. Updates require the current unexpired worker fence and service-role execution; cancelled/settled runs cannot be revived. A completed pending-status check shortens its lease to 10 seconds so the next minute scheduler tick can poll again.

The monitor opens automatically for active runs unless the user has already begun editing an input draft. It shows elapsed time, last actual agent update, last successful browser/server sync, and time until the 15-minute deadline, explicitly not an ETA. No invented percentage is shown. Lack of a heartbeat for 3 minutes produces a delay warning, while connection failures preserve the current monitor and offer retry/stop. Closing the dialog stops browser timers but not durable server work. Cancelled work with unverified provider costs is shown as stopped with the remaining reservation, not as active work.

# Implementation ledger — destination planning
Approved design: 2026-10-30-destination-planning-design.md.
Execution: inline, authorized by user approval; no additional planning gate.
Workspace: existing separate unbundled source directory, isolated from release clone. Local tracking initialized on feature branch; release uses connector optimistic lease.
Preflight: contract shared by frontend/server; server validates independently; budget values never accepted from browser.
Task 1: contract + Hebrew wizard tested RED→GREEN. Existing source baseline 51/51. Planning inputs reject invalid calendar dates and limits; approved preview never writes confirmed reservations.
Task 2: run/ledger migration deployed. Transactional database cap/cancellation/isolation tests passed. Private privileged owner operations behind invoker RPC wrappers; worker RPCs service-only.
Task 3 in progress: bounded Responses worker, durable response IDs, conservative cost bounds and safe unavailable state. No provider key configured/used.
Ruling: execution uses a single public web tool call per response to bound the full model-context worst-case under 5 ILS/run; real research completeness remains subject to draft validation and explicit review.

Final review: 3 important findings reproduced RED→GREEN: expired provider retrieval/cancellation releases active slot while retaining unknown hold; intentional replan gets a new idempotency key; booking costs are reconciled and shown in preview. Budget check also includes confirmed existing commitments. Prompt/tool limit aligned; polling retries transient errors.
Ruling: research prices remain indicative estimates, never live verified offers; explicit preview required even for an empty destination in this release — one extra confirmation buys consistent protection.

Final: actual privilege audit found managed pg_net queue SELECT grants. Revocation was ineffective because Supabase owns these objects, caught by the failing regression. Safer implementation removes reusable credentials from requests entirely: short-lived single-use wakeup nonces, private authorization hashes and atomic consume; no model secret, personal data or reusable server token enters the queue. Scheduler remains postgres-only.

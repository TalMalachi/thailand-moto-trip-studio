# Destination planning agent — design for review

## Agreed intent
Add תכנון יעד inside עריכת יעד in Motor Trip Studio. Run an authenticated agent inside the site after the owner reviews and approves planning inputs. Destination is fixed. Collect start date, permitted earlier/later days, trip duration and permitted shortening/extension, overall trip budget, allowed budget deviation and preferences/free text. Reuse existing destination settings as defaults, without treating saved defaults as new approval. Ask adaptively for travelers/rooms, departure location, transport mode and what the total budget includes (flights, lodging, transport, activities, meals, insurance). Missing cost-critical details enter needs_details.

The agent researches and completes daily route, lodging suggestions, booking drafts, tasks, places/services and relevant equipment information. Missing or uncertain information remains visibly unverified. Never claim a reservation or message was completed by planning.

Compare alternative dates at comparable comfort and quality. Highlight savings strictly above 15% of comparable total estimated trip cost, showing baseline, alternative, scope, sources and timestamps. Insufficient price evidence means savings unknown. Dates outside approved flexibility require fresh approval. Do not silently substitute a different destination or exceed approved budget tolerance.

## Approach selected
1. In-site agent, selected by the owner: integrated questionnaire, durable runs and reviewable updates; needs a secure backend and paid model provider.
2. ChatGPT handoff/import: avoids a new execution backend, but requires manual transfers. Rejected by the owner in favor of the in-site agent.

## Proposed implementation choices
Keep the current GitHub Pages frontend and Supabase Auth/Postgres. Add authenticated Supabase endpoints plus a resumable worker/queue rather than a long browser request. A server-side provider adapter executes bounded model and public-web research calls. Final provider/model selection requires checking current official capabilities and prices. No provider secret currently demonstrated; install secrets through a secure administrative channel, never chat, source, frontend or logs. Until credentials and execution infrastructure are verified, show an explicit unavailable state; never simulate an active agent.

Version the planning instructions/schema as a repository resource consumed by the worker. This is an application planning skill, not an assumption that a ChatGPT-installed skill can execute from a webpage.

## Planning and publication
Questionnaire → input summary/approval → queued → researching/planning → validation → ready → atomic publication → completed. Also support needs_details, awaiting_approval, failed, cancelled and budget_exhausted. Show current status, progress and stop control; browser closing must not lose a run.

For an empty itinerary, the first plan may add validated records after input approval. For any populated destination, including Thailand, all publication, even additions, requires a concrete preview to prevent duplicate routes/bookings. Approval binds the exact input snapshot, generated artifact and destination versions. Existing destination content is read as context; replacement or modification requires approval of a concrete change preview with current row versions. Never delete, overwrite paid/booked records, change policy approvals or erase manually entered information. Generated additions have provenance, stable IDs and run IDs; retries/publication are idempotent. Publish the whole validated batch in one transaction, recheck owner/run state and expected versions; conflicts return for review. Partial generated work is retained as a draft, not published as a complete itinerary. Publication builds on existing booking policies; discovered policy options remain pending human review.

## Agent permissions and isolation
Default capability set: read selected destination, research public information, propose structured additions, publish only through narrow validated run operations. No purchases, payment tools, email/message sending, account changes, arbitrary SQL, arbitrary network destinations or human-policy approval capability. Later transaction integrations require separate design and exact-action confirmation.

User asks must remain within travel planning and permitted capabilities. Server tools enforce restrictions regardless of prompt. Treat fetched webpages as untrusted evidence, never instructions. No secrets, passwords, OTP or card data requests. Minimize personal data sent to providers; avoid private booking references unless essential and specifically authorized. Validate URLs, block private/link-local/metadata endpoints and redirects to them, restrict protocols, bound response sizes/time and sanitize displayed output.

Do not reuse unrestricted owner JWT tools as the agent toolset. Worker identity must have narrowly mediated capabilities; all run access and commit operations validate owner, selected destination and action. Client cannot set cost, limits, run status, approve agent tools or invoke privileged persistence. Never expose a service-role key to the model. Existing owner RLS remains intact.

## Independent operating budget
Agreed: no customer billing in phase one. Operator-funded agent allowance is 20 ILS per account per calendar month, Asia/Jerusalem, shared by all destinations/runs. Display usage and remaining allowance without implying the customer owes money. Customer cannot increase the cap. Warn at 80%; block any call without sufficient reserved balance. Trip spending budget is independent.

Server ledger uses integer currency units and atomic reservations across concurrent runs, model calls, search calls and retries. Reserve a conservative upper bound before dispatch using pinned server pricing, bounded input/output/search tools, exchange-rate and applicable fee margin; charge actual usage and release only confirmed unused reservation. Unknown usage remains reserved; no auto retry after ambiguous provider response. If a provider/tool has no bounded enforceable cost, disallow it under the hard cap. Fail closed when server pricing or currency conversion configuration is missing or stale. Server counters enforce loop limits regardless of model output. Attribute late usage to the reservation month. Reconcile provider usage and alert on discrepancies. No automatic top-up or user-controlled ledger writes.

Proposed defaults: at most one active run per account, 5 ILS per run, 20 provider calls, 15-minute active execution budget, one retry for safe transient reads, all subordinate to remaining monthly allowance. Expose lower limits; higher limits never bypass monthly cap. Stop cancels queued work and prevents new calls/publication; already dispatched calls may finish and incur reserved cost. Never promise stopping reverses external work.

## Data and operational visibility
Add protected account budget configuration, monthly ledger/reservations, planning runs, immutable input snapshots/approval, draft artifacts and redacted audit events. RLS permits owners to read their own safe run/account views; only trusted backend updates execution/ledger data. Separate frontend human approval endpoint from worker capabilities. Enforce idempotency keys, bounded payloads, retention and rate limits.

Use leased jobs and fencing tokens; stale workers cannot publish after cancellation or re-dispatch an ambiguously charged call. Show run cost, reserved cost, status, errors and source timestamps. Preserve bounded non-sensitive evidence excerpts with retrieval time and price scope; distinguish live quotes, indicative prices and estimates. Never infer availability from generated text. Redact prompts/logs for sensitive data; logs do not contain keys or authentication headers. Proposed retention: detailed redacted execution events 30 days; retain run summary, source references and generated-record provenance with the trip. No broad personal memory or cross-account data sharing.

## Verification and rollout
Test owner/destination isolation, server-only budget writes, concurrent reservations and month rollover, cost bounds and unknown-usage handling, cancellation, job resumption/idempotency, malicious source instructions/URLs, schema validation, safe HTML, unchanged manual/booked items, approval/version conflicts and atomic publication. Use deterministic provider mocks for automated coverage. Run one explicitly capped real smoke test only after credentials are configured, count its cost and report outcome. Deployment must truthfully distinguish ready UI from working end-to-end execution.

## Open infrastructure dependency
Secure model-provider credential and an execution mechanism with verified durable/resumable semantics must be configured before real runs. Do not promise 20 ILS as an all-inclusive infrastructure bill; this cap covers attributable agent model/research operations. Hosting subscriptions, if any become necessary, require a separate disclosed decision.

# Destination settings wizard
User request: restore every planning category to destination editing, show completion per colored tab, and save changes.

Use the existing Hebrew RTL app and native form controls. Eight tabs cover destination, dates/flexibility, budget/inclusions, travelers/transport, pace/lodging/driving, interests/roads, constraints/free text, and agent cost/safety. Green means configured and saved; amber means changed but unsaved; grey means not configured. Every state also has text and a symbol. Optional sections can explicitly be reviewed with no preference.

Save-only permits incomplete planning preferences without running AI, and keeps the editor open with feedback. Save-and-plan validates the complete input, persists it, and opens the existing explicit AI approval summary. Returning to edit reopens the wizard. Existing last-run preferences are recovered only if the owner has not edited the current form; otherwise recovery is explicit. Existing current trip date/length/budget override older run values.

Persist bounded settings.planningDraft (version1 input, structured choices, free text and reviewed tab IDs). Preserve policy data, optimistic trip versions, export/import, account isolation and duplicate-create protection. Scheduled runs merge the current saved input into their authorized baseline before applying current trip date/length/budget. Saving does not dispatch a paid call, restart cancelled work, or enable a daily schedule.

Validation: Node/jsdom tests cover all fields, preference migration, saving/reopening/export, status colors, keyboard navigation, failure recovery, old response isolation, duplicate creates and planning approval. Rollback-only database verification checks saved inputs reach future daily runs. Existing private browser session is signed out; no authenticated live UI claim without successful login.

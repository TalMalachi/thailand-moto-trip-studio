# Daily trip preparation agent Implementation Plan
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.
**Goal:** Deliver scheduled internal supplier research, owner approvals, reports and honest preparation percentages.
**Architecture:** Reuse planner runs, bounded provider tools and the existing monthly ledger. Add owner-readable schedule/report/approval tables and service-only daily finalization. Daily research creates proposals only; human review and reservation completion remain separate.
**Tech Stack:** ES modules, Node tests/jsdom, Supabase PostgreSQL/Edge Functions, pg_cron.
**Spec:** docs/superpowers/specs/2026-10-31-daily-agent-design.md
## Global Constraints
08:00 Asia/Jerusalem; 20 ILS/account/month; 5 ILS/run; no supplier communication or purchases; no fake live prices; owner RLS and optimistic versions; no new paid validation runs without authorization.
## Review Focus
- DST/day-boundary retries must not dispatch twice or omit a blocked-day report.
- Stale or expired proposals must not approve a changed booking or exceed the trip budget.
- Pause/cancel races must not publish approvals or restart paid work.
- Duplicate rows, empty categories and approved-but-unbooked choices must not inflate completion.
- Failed generation, unknown costs and partial coverage must remain visible in reports.
## Task 1: Completion and daily output contract
Files: src/trip-completion.js, src/daily-research.js, tests/trip-completion.test.mjs, tests/daily-research.test.mjs.
Interfaces: tripCompletion(items,settings), completionMarkup(items,settings); dailyTargets(snapshot), dailyProviderRequest(run,baseRequest), validateDailyResearch(raw,run,evidence).
Steps: failing tests; run RED; implement bounded target selection, strict schema and source/amount/coverage validation; run GREEN/full suite.
## Task 2: Durable schedule, reports and approvals
Files: supabase/daily-agent.sql, supabase/tests/daily-agent.sql; server/planning-worker.js.
Interfaces: daily_overview(p_trip), daily_control(p_trip,p_action,p_version), daily_review(p_request,p_version,p_decision), daily_finalize(p_run), planner_private.daily_tick().
Steps: transactional tests first; implement RLS, idempotent due-date claim, existing-ledger start, daily purpose, blocked-day reports, owner review and server-only finalization; test rollback fixtures; integrate worker request/validation/finalization and gateway actions; run full suite.
## Task 3: Agent hub and completion UI
Files: src/agent-hub.js, src/planning-api.js, src/app.js, src/planning-progress.js, src/ui.css; tests/agent-hub.test.mjs and UI tests.
Interfaces: mountAgentHub({container,trip,api,onRefresh}) => cleanup. API dailyOverview(tripId), dailyControl(tripId,action,version), reviewDaily(requestId,version,decision).
Steps: failing UI tests; implement settings/consent, approvals, report details and progress; add completion summary to dashboard and hub navigation; run tests/build.
## Task 4: Review and release
Run full tests, database isolation/budget/day-idempotency tests, build browser/worker, security advisors, fresh independent whole-change review. Resolve material findings with regression tests. Deploy server and source/browser atomically through GitHub with expected-head lease; verify live assets, browser hub and daily cron configuration without a paid generation. Record facts and remaining limitations.

# Accounts and per-trip packages

Authorized scope: superuser account management; inactive users cannot use trip data or AI; registration with contact/address details; hosted card payment; one-time package per trip with owner-configured price and AI allowance. No monthly renewal or automatic overage charges. Prefer official APIs/MCP. Preserve existing owner's access and trip data.

## Design and security decisions

- Canonical account status in Postgres, checked on every business request. Restrictive RLS also blocks an old JWT. Privileged planner functions must explicitly check active status. Service dispatch and scheduled work must check the destination owner's current status.
- Pending users may only read their own onboarding state, save their own profile, and initiate verified payment after email verification. Suspended/closed accounts cannot pay to reactivate themselves. Business tables remain inaccessible until active.
- Superuser membership is private server data. Bootstrap only the established sole owner; never trust user metadata for roles. Status changes require a reason, optimistic version, and audit record. Prevent locking out the last active administrator.
- Account suspension stops daily work and cancels runs without dropping outstanding provider cost accounting. Already-dispatched external calls cannot be recalled; their results cannot publish planning changes.
- Immutable package versions contain a one-time ILS price and AI run quota. Owner configures both; initially no package is offered. Existing owner remains exempt from purchased run quota, with existing internal AI monetary caps preserved.
- Payment uses a hosted provider page. Never collect or store PAN/CVV. Gateway remains disabled until merchant credentials are configured. Server verifies order, currency, amount, transaction, and ownership against the official provider API; a browser redirect or unsigned webhook cannot activate an account.
- AI quota reserves atomically at run creation, consumes on provider dispatch, releases if cancelled before dispatch. Request-key retries cannot consume extra quota. Paid quota never bypasses existing internal cost limits.
- Registration is a compact RTL flow with email verification, transparent package terms, and a hosted payment step. Account management belongs in the existing account menu.

## Implementation sequence

1. Add failing SQL security fixtures; implement account status, private roles/profiles, bounded superuser RPCs and audit, restrictive RLS and all planner/service gates. Verify using rolled-back authenticated fixtures.
2. Add immutable package configuration, orders, trip entitlements and run quota accounting with transaction/replay tests.
3. Implement a disabled-by-default official hosted gateway adapter and server-verified callbacks. Use mock network responses for payment tests; no live charge.
4. Add fail-closed account session guard, superuser UI, registration, package details and payment disclosure. Verify mobile UI and existing functionality.
5. Fresh whole-change security review, full tests/build, security advisors, deploy backend then frontend, and compare released artifacts.

## Validation and release gates

Test pending/suspended/closed accounts with existing JWTs, cross-account access, direct privileged RPCs, worker dispatch, stale admin updates, metadata escalation, payment forgery/replay/mismatch, quota concurrency/idempotency, and last-admin protection. Review source/bundles for secrets and raw card handling. Do not enable real checkout without merchant setup. Do not claim a provider is connected until verified.

## Work ledger

- Baseline: source 497bd97, release 93844d5e; 129 tests previously passing.
- User decisions confirmed: one-time per-trip package; price and AI allowance configured by owner; activation after verified email and confirmed payment; no existing merchant provider.
- Implementation starting. Provider onboarding remains external; no merchant account or real payment authorized.

- Task 1: account migration applied; rolled-back account tests PASS. All eight owner-facing planner definer functions now require active status. Worker dispatch and daily schedule/finalization are gated. Existing owner active/superuser, 2 trips and 92 items preserved.
- Task 2: immutable package versions, orders and per-trip run quota applied; quota and receipt/replay tests PASS. A service-role integration test exposed missing auth.users SELECT; fixed with narrow private SECURITY DEFINER implementations behind service-only wrappers, without broad auth grants.
- Task 3: Cardcom official hosted API adapter implemented and mock-tested; no merchant credentials, no provider account opened, no real payment attempted. Two explicit enable switches (server env and private config) default off. New-signup Auth setting observed disabled; email confirmation enabled. Requires provider setup and Auth activation before customer onboarding can be live.
- Task 4: account menu, superuser account editor, immutable package editor, contact/address registration, pending onboarding, hosted checkout disclosures, fail-closed current-account checks and suspension tests implemented. Preserves existing compact navigation and destination UI. Full suite currently 142/142; builds pass.
- Ruling: prepare the official Cardcom hosted adapter as an interchangeable implementation; merchant choice/contract remains uncommitted — suitable ILS/Hebrew hosted API, no new provider relationship or charge — switching provider later requires replacing this adapter and validating callbacks.
- Ruling: leave new registration and checkout disabled pending merchant setup and explicit operational configuration; expose truthful setup messages — no configured merchant exists and current Supabase signup setting is disabled — customers cannot complete signup/payment yet.
- Ruling: maintain existing internal AI cost limits in addition to purchased quota, and disclose availability/cost limits before purchase — bounds owner exposure — a package is not a promise to dispatch all included runs immediately.

- Final fresh review (gpt-6-astra): three Important findings, no Critical. Fixed all three in accounts-billing-review-fixes.sql; repros failed before fixes and passed afterwards: suspended payment retains rights without reactivation; renamed destination cannot prepare a second charge; active admission retains account row lock so suspension serializes against starts. Worker dispatch takes the same lock before run lock. Source-proven race; no two-connection concurrency stress test was performed.
- Ruling: reserve an empty destination server-side before requesting the hosted payment page, rather than creating it after payment — stable identity prevents rename/collision double charges — abandoned checkouts leave an inaccessible empty destination for pending customers. RLS still denies pending business access.
- Final: fixed empty existing-trip destination disclosure, regraded Important because the destination is a material purchase term — selected-destination checkout UI test RED→GREEN.
- Final: removed unused standalone gate/test helper and added integration tests of actual app authorization responses after logout/identity switch. Full JavaScript suite 143/143.
- Final: minor (deferred): recovering an unpaid checkout after the package price/version changes requires an operator if the original hosted URL was lost. Checkout stays disabled pending completion of this workflow and merchant acceptance testing.
- SQL regression fixtures planning/planning-lifecycle previously assumed an empty monthly budget; real owner had prior usage. Updated only their rollback setup to reset the fixture budget locally before measuring expected deltas; no live budget changes retained.
- Final verification: 143/143 JS tests, all 16 rolled-back SQL fixture files, frontend/planner/billing builds PASS. Existing owner remains active/superuser, 2 trips and 92 items. Edge trip-planner v15 and trip-billing v1 deployed; billing remains fail-closed/unconfigured. Security advisors show intentional private-table deny-by-default informational notices plus the pre-existing leaked-password-protection plan limitation.

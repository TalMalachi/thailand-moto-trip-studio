# Destination Planning Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship an in-site planning questionnaire and tightly bounded authenticated planning backend.
**Architecture:** Existing frontend invokes a Supabase planning gateway. Durable Postgres runs and budget reservations mediate a resumable server worker; provider credentials stay server-side. Unconfigured providers fail closed.
**Tech Stack:** JavaScript, Node tests/jsdom, Postgres RLS/RPC, Supabase Edge Functions, OpenAI Responses adapter.
**Spec:** ../specs/2026-10-30-destination-planning-design.md

## Global Constraints
20 ILS/account/calendar month Asia/Jerusalem; 5 ILS/run; no customer billing. No purchases, email, policy approvals or arbitrary model tools. Existing populated destinations always require preview approval. No fake successful run when credentials are absent.

## Review Focus
- Unknown provider cost remains reserved rather than retried.
- Cancellation and stale workers cannot publish.
- Cross-account/destination IDs never authorize access.
- Manual/booked information and policy approvals survive planning.
- Malformed output, missing daily coverage and unverified prices cannot become confirmed reservations.

### Task 1: Planning contract and questionnaire
Files: src/planning.js, src/planning-ui.js, src/app.js, src/ui.css; tests/planning.test.mjs, tests/ui.test.mjs.
Interfaces: validatePlanningInput(raw), validatePlan(raw,input,evidence), createPlanningApi(client), openPlanning({dialog,destination,api,onPublished}). Input immutable destinationId/version; result includes records, evidence, summary, estimated budget and warnings.
- [ ] Write failing contract tests for real dates, flexibility, budget tolerance, bounded free text, all-day coverage, safe URLs, zero paid/confirmed states and savings comparison.
- [ ] Run tests and observe missing exports; implement contract and escaped accessible Hebrew wizard with inputs→summary→start, status/cancel, preview/apply; preserve unsaved destination draft on entry/back.
- [ ] Verify tests including unconfigured status, form/summary back, UI error recovery and cross-account stale callbacks.

### Task 2: Durable runs and budget gate
Files: supabase/planning.sql, supabase/tests/planning.sql; src/planning-api.js.
Interfaces: planner_overview(trip), planner_start(trip,version,input,idempotency), planner_cancel(run), planner_publish(run,expectedtripversion), service-only claim/dispatch/finish RPCs.
- [ ] Write transactional assertions for owner isolation, denied direct ledger writes, one active run, 500-agora reservation, 2000-agora monthly cap, cancellation, stale completion, idempotent atomic additive publication and conflicts.
- [ ] Implement private owner-checked security-definer operations behind invoker wrappers, owner-read RLS tables, server-only immutable snapshots/ledger and fenced service operations. Unknown external usage remains held. Test transactional SQL against actual DB, rollback fixtures.
- [ ] Verify advisors and no new public elevated function exposure.

### Task 3: Provider worker and deployment
Files: supabase/functions/trip-planner/index.ts, supabase/functions/trip-planner/worker.js, supabase/functions/trip-planner/contract.js, docs/planning-agent.md; tests/planning-worker.test.mjs.
Interfaces: handlePlannerRequest(req,deps); provider adapter accepts only server-approved prompts/limits, persists response IDs for polling, never exposes credentials/model tools to client.
- [ ] Write failing mocked tests for no-key/no-pricing block, bounded request, no ambiguous retry, cancellation and invalid outputs.
- [ ] Implement authenticated gateway, fixed public-web-only toolset and durable staged worker, conservative pricing config with expiry, no caller-supplied provider URL/key/model. Cron invokes only queued work with Vault secret; no agent calls without readiness.
- [ ] Verify complete suite/build, real DB tests and fresh independent review. Deploy schema and Edge Function, publish assets/source archive through existing GitHub lease-based connector workflow. Verify Pages revision and unauthenticated/authenticated boundaries. Report credential dependency accurately; do not spend without a configured provider.

# Accounts and payment activation

Current release provides server-enforced account status, superuser management, one-time per-trip package configuration, email-verification onboarding, hosted Cardcom checkout adapter, payment verification, and per-trip AI quota accounting. **New account signup and paid checkout remain disabled. No merchant account has been connected and no live charge has been tested.**

## Owner workflow

Open the account menu → ניהול משתמשים וחבילות. The established owner is the initial superuser. Account status changes require a reason and current record version. The last active superuser cannot be suspended. Ordinary account activation requires verified email and a server-confirmed paid order. Suspending an account immediately blocks business access in Postgres, including old JWTs, stops daily schedules, and cancels queued work. The UI also checks status on reconnect/visibility and every 15 seconds, with Realtime updates where available. A provider call already dispatched may still incur a cost; its result cannot publish after cancellation.

In חבילה ומכסת AI, configure the final one-time ILS price and number of included AI runs. Every saved edit creates an immutable package version. No automatic renewal, overage debit, saved card, or token charging is implemented. Existing superuser is exempt from purchased run quota; existing internal AI monetary caps remain in force for everyone.

## Merchant setup required before enabling customers

1. Establish a merchant account with a supported hosted payment provider. The current adapter implements Cardcom v11 LowProfile via the official API; no supplier contract or merchant account was created by this change. A different provider needs its own verified adapter.
2. Configure server secrets for `trip-billing`: `CARDCOM_TERMINAL_NUMBER`, `CARDCOM_API_NAME`. Never put these or a service-role key into frontend source. `BILLING_ENABLED` must remain absent/false until provider acceptance testing is complete.
3. Configure the merchant Low Profile model and webhook callback, single ILS payment, Hebrew page, and the business's document/receipt settings. The app itself does not issue tax documents. Provider callback URL: `https://nxpvxsyiyigedmplsdnz.supabase.co/functions/v1/trip-billing?action=webhook`.
4. Validate in the merchant sandbox: successful/declined/abandoned checkout, exact price/currency, 3DS, real callback parameter format, result fields, repeated callbacks, delayed callback, payment while suspended, and return on iPhone. Current automated tests mock provider networking and do not prove live acquiring compatibility. Never test a real charge without explicit approval of its amount/card.
5. Complete the deferred pending-checkout recovery workflow when a package changes price. Current implementation blocks creating a replacement checkout and retains immutable original terms. This avoids duplicate charges but requires operator assistance if the customer loses their original URL after a price change.
6. Verify Supabase Auth email delivery, site/redirect URL, minimum server password length, rate limits and email confirmation. Public Auth settings currently report `disable_signup=true`, `mailer_autoconfirm=false`. Enable signup only when the onboarding/payment acceptance checks are complete. Leaked-password checking is currently unavailable without the relevant Supabase plan; do not silently purchase an upgrade.
7. Only after acceptance: enable `BILLING_ENABLED=true` in server secrets and `app_private.billing_config.gateway_enabled=true` through a privileged deployment. Frontend users/admin forms cannot toggle these gates. Keep the public package and its limits accurate before accepting payment.

## Data and payment safety

No PAN, CVV or reusable card token is requested/stored by the app. The customer enters card details only on the provider's HTTPS hosted page. A browser success query or callback body is never payment evidence: the server looks up a known order, fetches LowProfile/GetLpResult using server credentials, checks operation, order ID, terminal, amount, ILS currency, transaction IDs, response codes, single installment, and refund flag, then records a minimal verified receipt. Ambiguous page creation is not automatically retried.

Checkout binds to a stable destination ID before any provider request. For a new customer this creates an empty destination reserved for that order; pending users cannot access trip data through RLS. Renaming cannot create a second paid entitlement, and destinations with payment orders cannot be deleted. A payment arriving after suspension retains its purchased entitlement but never reactivates the account.

Quota is reserved transactionally, consumed on dispatch, and released on cancellation/failure before dispatch. Idempotent retries do not consume extra runs. Source migrations apply in order: accounts.sql, billing.sql, billing-hardening.sql, accounts-billing-review-fixes.sql. The initial bootstrap intentionally aborts unless exactly the established verified owner exists; for a different database, select the owner explicitly before enabling registrations.

## Verification evidence

Automated JS unit/UI/gateway tests and rolled-back SQL fixtures cover active/blocked/pending authorization, account isolation, metadata escalation, last-admin protection, planner/service gates, quota lifecycle, receipt mismatch/replay, purchased terms, stable destination binding, and service-role permissions. The admission-lock fixture verifies that the account row lock is retained for the transaction; it is not a two-connection concurrency stress test. Browser access to the signed-in owner is still required for live private-admin visual verification.

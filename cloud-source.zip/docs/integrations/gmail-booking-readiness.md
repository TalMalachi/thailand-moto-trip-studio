# Gmail and Booking.com integration readiness

Requested by owner: after a specific approval the agent should create a reservation, organize customer mail under product/destination labels, scan daily and reconcile itinerary/expenses. Choices confirmed on 2026-10-31: Gmail first, new Google Cloud project needed, Booking.com hotels first, only a normal consumer Booking.com account exists (no Demand API access).

## Implemented separately now
The budget/expenses tab combines existing booking costs and paid amounts with validated manual expenses in settings.expenses. It distinguishes missing prices from zero-cost manual entries, includes category totals, preserves cent-level arithmetic and signed budget overruns, supports owner/version-checked save, and round-trips through backups. Initial planning, daily option validation and owner approval budgets include known manual costs, without duplicating them as reservations. Existing reservations/items remain untouched by deployment.

## External prerequisites blocking activation
1. An owner-controlled Google Cloud project, Gmail API enabled, OAuth web application, permitted redirect URL, consent screen and appropriate test users. Server-only client secret and encrypted per-customer refresh tokens; never client-side secrets, mailbox passwords or tokens pasted into chat. Production use of restricted Gmail data requires the applicable Google verification/security process; testing/personal exceptions must not be represented as public-client production approval.
2. Booking.com Managed Affiliate Partner access, API key, Affiliate ID, order-creation/payment permissions and sandbox access. A normal traveller account cannot substitute for these credentials. Exact payment capabilities must be established before implementing a production reservation adapter.

No Gmail account was read/connected, no labels/filters were created, no booking API was invoked and no real reservation or charge was attempted in this change. The ChatGPT Gmail connector is not an OAuth credential for this independent website or its customers.

## Proposed runtime contract for the integration phase
- Each authenticated owner explicitly connects Gmail with Google OAuth. Persist owner/account/trip/label IDs server-side; isolate by owner and allow disconnect/revocation.
- Labels: Motor Trip Studio, then Motor Trip Studio/<destination>. Create idempotently. Maintain label-ID mapping through destination renames. For automatically routing new confirmations, configure narrowly matching provider/reference filters with the required additional consent; never create forwarding/deletion rules. Mail scan requests use the mapped destination label, not unrestricted inbox content.
- Daily at08:00 Asia/Jerusalem, independently of an open browser, scan paginated new/changed label messages from a persisted cursor. Deduplicate by owner/account/message ID and payment/receipt references. Store audit entries and minimal extracted facts; avoid storing raw bodies or attachments unless necessary and explicitly covered by the data policy.
- Treat emails, attachments and model output as untrusted data, never instructions. Match confirmations to supplier references and trip context. Verified factual updates may update the matching reservation/payment record transactionally with versions and evidence; ambiguous/conflicting changes require owner review. Reconcile replacement confirmations/refunds/partial payments without incrementing cumulative paid twice. Never infer payment from a booking confirmation alone.
- Preserve the user's current plan against stale scans. Changed dates, prices, payee, cancellation terms or itinerary must be visible in the audit and require a new approval where the existing approval no longer applies. Cancellation messages do not authorize purchasing a replacement.
- Booking execution: current supplier availability -> /orders/preview -> review exact property/products/dates/travellers/total/currency/payment timing/cancellation penalties -> owner-specific expiring single-use approval -> revalidation -> /orders/create with the supplier order token -> supplier-confirmed receipt -> reserved/paid statuses as independently evidenced. Manual researched URLs are not valid supplier order tokens.
- Use a durable idempotency/reconciliation record around create. Never blindly retry an ambiguous reservation/payment response. Validate access and the user's total trip budget immediately before execution. Only use payment methods compatible with an approved secure provider flow; do not collect/store raw payment-card data in this app.
- Show disconnected, awaiting setup, awaiting approval, submitting, confirmed, reconciliation-needed and failed states truthfully. Keep the current manual-booking flow until supplier execution is actually integrated and verified.
- All mail-related model work shares the existing account AI ledger, 20ILS/month and5ILS/run. No new external purchase, paid test or provider subscription was made.

## Primary references checked
https://developers.google.com/workspace/gmail/api/auth/web-server
https://developers.google.com/workspace/gmail/api/auth/scopes
https://developers.google.com/workspace/gmail/api/guides/filter_settings
https://developers.google.com/identity/protocols/oauth2/production-readiness/restricted-scope-verification
https://developers.booking.com/demand/docs/getting-started/prerequisites
https://developers.booking.com/demand/docs/orders-api/order-preview-create

# Booking and task workflow

Both booking and task payloads use workflowStatus with stable values:

| Value | Display |
| --- | --- |
| opened | נפתח |
| read_by_agent | נקרא ע״י הסוכן |
| email_sent | נשלח אימייל |
| awaiting_approval | ממתין לאישורך |
| awaiting_details | ממתין להוספת פרטים |
| updated | מעודכן |
| rejected | נדחה |
| completed | סיים בהצלחה |

workflowUpdatedAt is an ISO timestamp; workflowUpdatedBy is user or agent and is display metadata, never an authorization source. The existing booking status retains reservation/payment meaning. For tasks keep done consistent with workflowStatus === completed.

An agent must use authenticated owner-scoped access and the existing update_trip_item RPC with the row's current version, preserving other payload fields. Reject and reload after a version conflict. Do not use a service role in a client, bypass RLS, or infer authorization from payload fields. Reading, sending email, requesting approval, and completion must reflect real completed operations; a status label does not grant permission to send, purchase, or approve. This release supplies state and statistics only, without an email-sending agent.

The frontend refreshes managed views every 30 seconds while visible and when returning to the app. Refresh is paused during editing or saving. Statistics are recomputed from the latest saved payloads, not separately stored counters. Backup validation preserves workflow state and update metadata.

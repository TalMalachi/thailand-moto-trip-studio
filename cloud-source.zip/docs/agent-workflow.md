# Booking and task workflow

Both booking and task payloads use workflowStatus with stable values:

| Value | Display |
| --- | --- |
| opened | נפתח |
| read_by_agent | נקרא ע״י הסוכן |
| email_sent | נשלח אימייל |
| awaiting_approval | ממתין לאישורך |
| awaiting_details | ממתין להוספת פרטים |
| updated | מעודכן |
| rejected | נדחה |
| completed | סיים בהצלחה |

workflowUpdatedAt is an ISO timestamp; workflowUpdatedBy is user or agent and is display metadata, never an authorization source. The existing booking status retains reservation/payment meaning. For tasks keep done consistent with workflowStatus === completed.

An agent must use authenticated owner-scoped access and the existing update_trip_item RPC with the row's current version, preserving other payload fields. Reject and reload after a version conflict. Do not use a service role in a client, bypass RLS, or infer authorization from payload fields. Reading, sending email, requesting approval, and completion must reflect real completed operations; a status label does not grant permission to send, purchase, or approve. This release supplies state and statistics only, without an email-sending agent.

The frontend refreshes managed views every 30 seconds while visible and when returning to the app. Refresh is paused during editing or saving. Statistics are recomputed from the latest saved payloads, not separately stored counters. Backup validation preserves workflow state and update metadata.

## Discovered booking policy options and human review

The active destination's `settings.bookingPolicyProposals` array stores ordered revisions discovered during the booking workflow. Each new revision has a new stable id, category, explicit bookingIds, state, options, and optional budgetSharePct. An option has an id, label, details, optional sourceUrl, optional estimatedCost in ILS with costBasis, and a recommended flag. Recommendations and preselected UI checkboxes are not human approval. Never fabricate offers or mark unverified details as confirmed.

The future agent publishes a revision in state policy_updated and marks its associated booking workflowStatus policy_updated (מדיניות הזמנה עודכנה), then moves to awaiting_approval when ready for human review. Related item IDs must belong to the same trip and category. Do not modify an existing revision in place. Preserve unrelated trip settings and use current optimistic versions.

The owner reviews options in the policy tab and explicitly approves exact IDs or rejects the proposal through review_booking_policy. This RPC checks owner access, current trip version, newest revision, pending state, valid selection and allocation totals. It atomically saves approvedOptionIds/reviewedAt and updates related pending bookings to updated or rejected. Approval covers policy options, not a completed purchase or permission to send messages.

The future agent must consume only approvedBookingOptions(settings, category), which returns no approved choices if the newest revision is pending or rejected. Agent-facing tools must not expose the human approval RPC or permit setting approved state; implement that separation when the agent is built. There is no agent or email-sending integration in this release.

Category allocation is derived exclusively from the overall settings.budget: budget * budgetSharePct / 100. A missing trip budget or allocation is unknown, never zero/free. Approval rejects cumulative category allocation over 100%. Changing the trip total recomputes displayed amounts. Option estimated costs and per-night/day/person bases are informational and must be normalized with quantity, taxes, mandatory fees and existing commitments before any future spending decision.

settings.bookingPolicies now contains optional preliminary preferences and free-text context only. Legacy maxBudget/budgetBasis fields are retained for backup compatibility and are not used as independent spending caps. Policies, proposals and review results survive backup validation. The existing additive backup import does not overwrite destination settings automatically. Automatic refresh pauses while the owner changes review selections, preserving choices until review or explicit navigation.

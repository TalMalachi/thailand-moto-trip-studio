import test from 'node:test';import assert from 'node:assert/strict';import {JSDOM} from 'jsdom';
import {agentHubMarkup,mountAgentHub} from '../src/agent-hub.js';
const trip={id:'trip',version:2,settings:{days:3,budget:1000},items:[{id:'b',version:2,kind:'booking',payload:{name:'מלון',status:'לבדיקה'}}]};
test('daily hub exposes explicit paid-research consent, defaults stopped and distinguishes approvals from bookings',()=>{
 const html=agentHubMarkup({baselineAvailable:true,reports:[],requests:[],budget:{}},trip);assert.match(html,/08:00/);assert.match(html,/Asia\/Jerusalem/);assert.match(html,/data-daily-control="enable"/);assert.match(html,/type="checkbox"/);assert.match(html,/אישור הצעה אינו הזמנה/);
 const data={schedule:{state:'active'},reports:[{id:'r',report_date:'2027-01-01',state:'skipped',report:{summary:'תקציב חסום <script>'}}],requests:[{id:'q',booking_id:'b',booking_version:2,trip_version:2,version:1,state:'pending',expires_at:'2099-01-01',offer:{supplier:'מלון',label:'חדר',totalCost:100,url:'javascript:bad',sourceUrl:'https://example.com',details:'בדיקה'}}]};
 const markup=agentHubMarkup(data,trip);assert.doesNotMatch(markup,/href="javascript:/);assert.match(markup,/&lt;script&gt;/);assert.match(markup,/data-decision="approved"/);assert.match(markup,/data-daily-control="pause"/);
 const stale=agentHubMarkup({...data,requests:[{...data.requests[0],booking_version:1}]},trip);assert.doesNotMatch(stale,/data-decision="approved"/);
});
test('closing the hub ignores late responses and no mount or polling enables a paid run',async()=>{
 const dom=new JSDOM('<main></main>');const container=dom.window.document.querySelector('main');let resolve;const calls=[];const api={dailyOverview:()=>new Promise(r=>resolve=r),dailyControl:()=>calls.push('paid')};
 const close=mountAgentHub({container,trip,api});close();const before=container.innerHTML;resolve({reports:[],requests:[]});await new Promise(r=>setTimeout(r,0));assert.equal(container.innerHTML,before);assert.deepEqual(calls,[]);dom.window.close();
});
test('a trip revision invalidates approval controls without waiting for the booking to change',()=>{
 const q={id:'q',booking_id:'b',booking_version:2,trip_version:1,version:1,state:'pending',expires_at:'2099-01-01',offer:{supplier:'מלון',totalCost:100}};
 const html=agentHubMarkup({schedule:{state:'active'},requests:[q],reports:[]},trip);assert.doesNotMatch(html,/data-decision="approved"/);assert.match(html,/נתוני ההזמנה השתנו/);
});

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRepository} from '../src/trip-repository.js';
import {createAuth} from '../src/auth.js';
const good={data:[{id:'item',version:2,payload:{title:'saved'}}],error:null};
test('stale update raises conflict instead of reporting a successful save',async()=>{const repo=createRepository({rpc:async()=>({data:[],error:null})});await assert.rejects(()=>repo.updateItem('item',1,'task',{title:'draft'}),/conflict/i)});
test('server failures propagate instead of reporting saved',async()=>{const repo=createRepository({rpc:async()=>({data:null,error:{message:'network failed'}})});await assert.rejects(()=>repo.updateItem('item',1,'task',{title:'draft'}),/network failed/)});
test('versioned writes send expected version and normalized payload',async()=>{let params;const repo=createRepository({rpc:async(name,p)=>{params={name,p};return good}});const row=await repo.updateItem('item',1,'task',{title:'draft'});assert.equal(params.name,'update_trip_item');assert.equal(params.p.p_expected_version,1);assert.deepEqual(params.p.p_payload,{title:'draft',done:false});assert.equal(row.version,2)});
test('login never silently registers a public user',async()=>{let options;const a=createAuth({auth:{signInWithOtp:async o=>{options=o;return {error:null}}}},'https://app.test/');await a.requestLink(' owner@example.com ');assert.equal(options.email,'owner@example.com');assert.equal(options.options.shouldCreateUser,false);assert.equal(options.options.emailRedirectTo,'https://app.test/')});
test('auth errors propagate and malformed email never contacts server',async()=>{let calls=0;const a=createAuth({auth:{signInWithOtp:async()=>{calls++;return {error:{message:'mail failed'}}}}},'https://app.test/');await assert.rejects(()=>a.requestLink('invalid'));assert.equal(calls,0);await assert.rejects(()=>a.requestLink('owner@example.com'),/mail failed/)});
test('password sign in and change report server failures without exposing the password',async()=>{
 const a=createAuth({auth:{signInWithPassword:async()=>({error:{message:'Invalid login credentials'}}),updateUser:async()=>({error:{message:'Password update failed'}})}},'https://app.test/');
 await assert.rejects(()=>a.signIn('owner@example.com','test-only-password'),/Invalid login credentials/);
 await assert.rejects(()=>a.changePassword('new-test-only-password'),/Password update failed/);
});

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
import {JSDOM} from 'jsdom';
const bundle=await build({entryPoints:['src/app.js'],bundle:true,format:'iife',write:false,outfile:'test-ui.js',loader:{'.png':'dataurl'},plugins:[{name:'external-sdk-boundary',setup(b){b.onResolve({filter:/^@supabase\/supabase-js$/},()=>({path:'sdk',namespace:'boundary'}));b.onLoad({filter:/.*/,namespace:'boundary'},()=>({contents:'export const createClient = () => globalThis.__client;'}))}}]});
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const pause=()=>new Promise(r=>setTimeout(r,15));
async function setup(items=null,autoOpen=true){
 const dom=new JSDOM('<div id="account"></div><nav id="tabs"></nav><div id="message"></div><main id="view"></main><dialog id="editor"></dialog>',{url:'https://app.test/',runScripts:'outside-only'}),w=dom.window;
 w.structuredClone=structuredClone;w.confirm=()=>true;
 w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let user='A',pending=null;const callbacks=[];
 const trip=()=>({id:'trip-'+user,destination_name:'תאילנד',is_active:true,settings:{start:'',days:21,budget:0,currency:'ILS'},version:1});
 w.__client={auth:{getSession:async()=>({data:{session:{user:{id:'A',email:'a@example.invalid'}}},error:null}),onAuthStateChange:cb=>{callbacks.push(cb);return {data:{subscription:{unsubscribe(){}}}}}},from(table){const q={select(){return q},eq(){return q},order(){return q},limit(){if(pending){const x=pending;pending=null;return x.promise}return Promise.resolve({data:[trip()],error:null})},range(){return Promise.resolve({data:items??[{id:'item-'+user,kind:'task',payload:{title:'private-'+user,done:false},version:1}],error:null})}};return q}};
 w.eval(bundle.outputFiles.find(x=>x.path.endsWith('.js')).text);await pause();if(autoOpen){w.document.querySelector('[data-destination-open]')?.click();await pause();}
 return {w,close:()=>w.close(),defer:()=>{const d=deferred();pending=d;return d},emit(s){user=s?.user.id;callbacks.forEach(cb=>cb('TEST',s))},tripResult:()=>({data:[trip()],error:null})};
}
test('switching accounts clears previous account private editor and loads the new account',async()=>{const c=await setup();try{c.w.document.querySelector('[data-tab=task]').click();c.w.document.querySelector('[data-work-view=current]')?.click();c.w.document.querySelector('[data-action=edit]').click();assert.equal(c.w.document.querySelector('#editor input').value,'private-A');c.emit({user:{id:'B',email:'b@example.invalid'}});await pause();c.w.document.querySelector('[data-destination-open]')?.click();await pause();assert.equal(c.w.document.querySelector('#editor').open,false);assert.equal(c.w.document.querySelector('#editor').textContent,'');c.w.document.querySelector('[data-tab=task]').click();c.w.document.querySelector('[data-work-view=current]')?.click();assert.match(c.w.document.querySelector('#view').textContent,/private-B/)}finally{c.close()}});
test('failed old request after logout cannot replace the login screen',async()=>{const c=await setup();try{const d=c.defer();c.w.document.querySelector('#refresh').click();c.emit(null);await pause();d.reject(Error('stale failure'));await pause();assert.ok(c.w.document.querySelector('#login'));assert.equal(c.w.document.querySelector('#retry'),null)}finally{c.close()}});
test('in-flight refresh does not destroy a settings draft entered after it started',async()=>{const c=await setup();try{const d=c.defer();c.w.document.querySelector('#refresh').click();c.w.document.querySelector('[data-tab=settings]').click();const budget=c.w.document.querySelector('input[name=budget]');budget.value='1234';budget.dispatchEvent(new c.w.Event('input',{bubbles:true}));d.resolve(c.tripResult());await pause();assert.equal(c.w.document.querySelector('input[name=budget]').value,'1234')}finally{c.close()}});
test('password login clears the secret and shows a useful server error',async()=>{const c=await setup();try{c.emit(null);await pause();const form=c.w.document.querySelector('#login');assert.ok(form.querySelector('input[type=password]'));c.w.__client.auth.signInWithPassword=async()=>({error:{message:'Invalid login credentials'}});form.elements.email.value='owner@example.invalid';form.elements.password.value='test-only-password';form.dispatchEvent(new c.w.Event('submit',{bubbles:true,cancelable:true}));await pause();assert.equal(form.elements.password.value,'');assert.match(c.w.document.querySelector('#message').textContent,/נכשלה/)}finally{c.close()}});

test('place category menu filters cards, prefills new places and recovers when the category disappears',async()=>{
 const rows=[['f1','תחנה אחת','דלק'],['f2','תחנה שנייה','דלק'],['p1','שוק ערב','בילוי'],['p2','מקום ללא סוג','']].map(([id,name,type])=>({id,kind:'place',payload:{name,type,area:'',url:'',notes:''},version:1}));
 const c=await setup(rows);try{
  const doc=c.w.document;doc.querySelector('[data-tab=place]').click();
  const menu=()=>doc.querySelector('[aria-label="קטגוריות מקומות ושירותים"]');
  assert.ok(menu());assert.match(menu().textContent,/הכול \(4\)/);assert.match(menu().textContent,/דלק \(2\)/);assert.match(menu().textContent,/ללא קטגוריה \(1\)/);
  const fuel=[...menu().options].find(x=>x.textContent==='דלק (2)');menu().value=fuel.value;menu().dispatchEvent(new c.w.Event('change',{bubbles:true}));
  assert.equal(doc.querySelectorAll('#view [data-id]').length,2);assert.equal(doc.querySelector('[data-id=p1]'),null);assert.equal(menu().selectedOptions[0].textContent,'דלק (2)');
  doc.querySelector('#add').click();assert.equal(doc.querySelector('#editor input[name=type]').value,'דלק');doc.querySelector('#cancel').click();
  rows.splice(0,2);doc.querySelector('#refresh').click();await pause();
  assert.equal(doc.querySelectorAll('#view [data-id]').length,2);assert.equal(menu().selectedOptions[0].textContent,'הכול (2)');
 }finally{c.close()}
});

test('route opens with map first, groups repeated destinations and offers both navigation apps',async()=>{
 const rows=[1,2].map(day=>({id:'s'+day,kind:'stop',payload:{day,place:'פאי',kind:'רכיבה',notes:'',url:''},version:1}));rows.push({id:'s3',kind:'stop',payload:{day:3,place:'Unknown destination',kind:'',notes:'',url:''},version:1});
 const c=await setup(rows);try{const doc=c.w.document;
  assert.equal(doc.querySelector('[data-route-view=map]')?.getAttribute('aria-pressed'),'true');assert.ok(doc.querySelector('#route-map'));assert.equal(doc.querySelectorAll('.route-marker').length,1);
  doc.querySelector('.route-marker').dispatchEvent(new c.w.MouseEvent('click',{bubbles:true}));
  const popup=doc.querySelector('.leaflet-popup-content');assert.ok(popup);assert.ok(popup.closest('.route-popup'));assert.equal(doc.querySelector('#route-map').style.getPropertyValue('--route-popup-height'),'230px');assert.match(popup.textContent,/יום 1/);assert.match(popup.textContent,/יום 2/);assert.ok(popup.querySelector('a[data-navigation=google]'));assert.ok(popup.querySelector('a[data-navigation=waze]'));assert.match(doc.querySelector('#unmapped-stops').textContent,/Unknown destination/);
  doc.querySelector('[data-route-view=list]').click();assert.equal(doc.querySelectorAll('#view [data-id]').length,3);assert.equal(doc.querySelector('#route-map'),null);
  doc.querySelector('[data-id=s1] [data-action=edit]').click();assert.ok(doc.querySelector('input[name=lat]'));assert.ok(doc.querySelector('input[name=lng]'));
 }finally{c.close()}
});

test('more navigation exposes the remaining sections and closes after selection',async()=>{const c=await setup();try{const d=c.w.document,menu=d.querySelector('#nav-more');assert.ok(menu);assert.equal(menu.open,false);menu.querySelector('summary').click();assert.equal(menu.open,true);menu.querySelector('[data-tab=settings]').click();assert.ok(d.querySelector('#settingsform'));assert.equal(d.querySelector('#nav-more').open,false);assert.ok(d.querySelector('#nav-more').classList.contains('active'));}finally{c.close()}});
test('modern booking cards retain long notes and distinguish an unpriced draft from a free booking',async()=>{const notes='Long planning note '.repeat(20)+'<script>bad()</script>';const c=await setup([{id:'draft',kind:'booking',payload:{name:'Draft hotel',type:'מלון',status:'לבדיקה',cost:0,paid:0,notes},version:1}]);try{const d=c.w.document;d.querySelector('[data-tab=booking]').click();d.querySelector('[data-work-view=current]')?.click();assert.equal(d.querySelector('.record-title').textContent,'Draft hotel');assert.equal(d.querySelector('.record-price').textContent,'טרם תומחר');assert.ok(d.querySelector('.card-notes'));assert.ok(d.querySelector('.card-notes').textContent.includes(notes));assert.equal(d.querySelector('#view script'),null);d.querySelector('[data-action=edit]').click();assert.equal(d.querySelector('textarea[name=notes]').value,notes);}finally{c.close()}});
test('failed cloud save keeps the draft and displays the error inside the editor',async()=>{const c=await setup();try{const d=c.w.document;c.w.__client.rpc=async()=>({data:null,error:{message:'offline'}});d.querySelector('[data-tab=task]').click();d.querySelector('[data-work-view=current]')?.click();d.querySelector('[data-action=edit]').click();const form=d.querySelector('#editor form');form.elements.title.value='Unsaved draft';form.dispatchEvent(new c.w.Event('submit',{bubbles:true,cancelable:true}));await pause();assert.equal(d.querySelector('#editor').open,true);assert.equal(form.elements.title.value,'Unsaved draft');assert.match(d.querySelector('[data-dialog-status]')?.textContent??'',/offline/);}finally{c.close()}});
test('a confirmed booking with zero cost is displayed as zero rather than an unpriced draft',async()=>{const c=await setup([{id:'free',kind:'booking',payload:{name:'Confirmed booking',type:'מלון',status:'הוזמן',cost:0,paid:0,notes:''},version:1}]);try{c.w.document.querySelector('[data-tab=booking]').click();c.w.document.querySelector('[data-work-view=current]')?.click();assert.match(c.w.document.querySelector('.record-price').textContent,/0/);}finally{c.close()}});
test('daily-plan cards retain the stop type and saved coordinates',async()=>{const c=await setup([{id:'boat',kind:'stop',payload:{day:1,place:'Pier',kind:'שיט',lat:'8.01',lng:'98.83',notes:'',url:''},version:1}]);try{const d=c.w.document;d.querySelector('[data-route-view=list]').click();const card=d.querySelector('[data-id=boat]');assert.match(card.textContent,/שיט/);assert.match(card.textContent,/8.01/);assert.match(card.textContent,/98.83/);}finally{c.close()}});
test('navigation moves keyboard focus to the selected view heading and task checkboxes reference their titles',async()=>{const c=await setup();try{const d=c.w.document;d.querySelector('[data-tab=task]').click();assert.equal(d.activeElement,d.querySelector('#view h2'));assert.equal(d.querySelector('[data-work-view=stats]').getAttribute('aria-pressed'),'true');d.querySelector('[data-work-view=current]')?.click();const checkbox=d.querySelector('.task-toggle input');assert.ok(checkbox.getAttribute('aria-labelledby')?.includes('record-item-A'));}finally{c.close()}});

test('map popup uses the daily destination, opens its day and shows lodging navigation only in daily plan',async()=>{
 const c=await setup([{id:'day4',kind:'stop',payload:{day:4,place:'פאי',url:'https://www.google.com/maps/search/?api=1&query=Example+Bridge+Pai',notes:'לינה: Example Lodge. תוכנית יום 4: ביקור בגשר.'},version:1}]);try{
 const d=c.w.document;d.querySelector('.route-marker').dispatchEvent(new c.w.MouseEvent('click',{bubbles:true}));const popup=d.querySelector('.leaflet-popup-content');
 assert.match(popup.textContent,/Example Bridge Pai/);assert.equal(new URL(popup.querySelector('[data-navigation=google]').href).searchParams.get('destination'),'Example Bridge Pai');assert.equal(d.querySelector('[data-lodging-navigation]'),null);
 popup.querySelector('[data-open-day]').click();const card=d.querySelector('[data-id=day4]');assert.equal(d.activeElement,card.querySelector('h3'));assert.equal(new URL(card.querySelector('[data-lodging-navigation=google]').href).searchParams.get('destination'),'Example Lodge פאי Thailand');assert.ok(card.querySelector('[data-lodging-navigation=waze]'));
 }finally{c.close()}
});
test('a departure day without overnight lodging has no lodging navigation',async()=>{const c=await setup([{id:'last',kind:'stop',payload:{day:21,place:'Bangkok',notes:'לינה: ללא לינה נוספת כברירת מחדל. יציאה.'},version:1}]);try{const d=c.w.document;d.querySelector('[data-route-view=list]').click();assert.equal(d.querySelector('[data-lodging-navigation]'),null)}finally{c.close()}});

test('daily-plan popup button has readable foreground and background colors',async()=>{
 const c=await setup([{id:'day',kind:'stop',payload:{day:1,place:'פאי'},version:1}]);try{
 const d=c.w.document,style=d.createElement('style');style.textContent=bundle.outputFiles.find(x=>x.path.endsWith('.css')).text;d.head.append(style);
 d.querySelector('.route-marker').dispatchEvent(new c.w.MouseEvent('click',{bubbles:true}));const button=d.querySelector('.leaflet-popup-content [data-open-day]');assert.equal(button.textContent,'פתח תוכנית ליום 1');
 const computed=c.w.getComputedStyle(button);assert.equal(computed.color,'rgb(18, 50, 53)');assert.equal(computed.backgroundColor,'rgb(231, 243, 239)');
 }finally{c.close()}
});

test('booking and task categories filter independently and prefill new records',async()=>{
 const c=await setup([{id:'hotel',kind:'booking',payload:{name:'Hotel',type:'מלון'},version:1},{id:'flight',kind:'booking',payload:{name:'Flight',type:'טיסה'},version:1},{id:'packing',kind:'task',payload:{title:'Pack',category:'ציוד'},version:1},{id:'other',kind:'task',payload:{title:'Other'},version:1}]);try{
 const d=c.w.document;
 for(const [kind,label,key,id] of [['booking','מלון','type','hotel'],['task','ציוד','category','packing']]){
 d.querySelector('[data-tab='+kind+']').click();d.querySelector('[data-work-view=current]')?.click();let select=d.querySelector('#place-category');select.value=[...select.options].find(x=>x.textContent.startsWith(label+' (')).value;select.dispatchEvent(new c.w.Event('change',{bubbles:true}));assert.equal(d.querySelectorAll('#view [data-id]').length,1);assert.ok(d.querySelector('[data-id='+id+']'));d.querySelector('#add').click();assert.equal(d.querySelector('[name='+key+']').value,label);d.querySelector('#cancel').click();
 }
 d.querySelector('[data-tab=booking]').click();assert.match(d.querySelector('#place-category').selectedOptions[0].textContent,/מלון/);
 }finally{c.close()}
});

test('bookings and tasks expose current and statistics views with category and status filters',async()=>{
 const c=await setup([{id:'hotel',kind:'booking',payload:{name:'Hotel',type:'מלון',workflowStatus:'awaiting_approval'},version:1},{id:'flight',kind:'booking',payload:{name:'Flight',type:'טיסה',workflowStatus:'email_sent'},version:1},{id:'task',kind:'task',payload:{title:'Pack',category:'ציוד',workflowStatus:'completed',done:false},version:1}]);try{
 const d=c.w.document;d.querySelector('[data-tab=booking]').click();assert.ok(d.querySelector('[data-work-view=stats][aria-pressed=true]'));d.querySelector('[data-work-view=current]').click();assert.ok(d.querySelector('[data-work-view=current][aria-pressed=true]'));assert.match(d.querySelector('[data-id=hotel]').textContent,/ממתין לאישורך/);
 let filter=d.querySelector('#workflow-filter');filter.value='awaiting_approval';filter.dispatchEvent(new c.w.Event('change',{bubbles:true}));assert.equal(d.querySelectorAll('#view [data-id]').length,1);
 d.querySelector('[data-work-view=stats]').click();assert.equal(d.querySelectorAll('.workflow-stat').length,8);assert.equal(d.querySelectorAll('.workflow-table tbody tr').length,2);assert.equal(d.querySelector('.workflow-stat[data-status=email_sent] strong').textContent,'1');
 d.querySelector('[data-tab=task]').click();d.querySelector('[data-work-view=current]')?.click();assert.equal(d.querySelector('.task-toggle input').checked,true);d.querySelector('[data-action=edit]').click();assert.equal(d.querySelector('select[name=workflowStatus]').value,'completed');assert.equal(d.querySelector('select[name=workflowStatus]').options.length,8);
 }finally{c.close()}
});

test('login lands on destinations and allows opening Thailand and editing its active state',async()=>{
 const c=await setup(null,false);try{
 const d=c.w.document;assert.match(d.querySelector('#view h2').textContent,/לאן יוצאים/);assert.equal(d.querySelector('#tabs').textContent,'');assert.match(d.querySelector('.destination-card').textContent,/תאילנד/);
 d.querySelector('[data-destination-edit]').click();assert.equal(d.querySelector('[name=destination]').value,'תאילנד');assert.equal(d.querySelector('[name=active]').checked,true);d.querySelector('#cancel-destination').click();
 d.querySelector('#add-destination').click();assert.equal(d.querySelector('[name=destination]').value,'');d.querySelector('#cancel-destination').click();
 d.querySelector('[data-destination-open]').click();await pause();assert.ok(d.querySelector('[data-route-view]'));d.querySelector('#destinations-home').click();await pause();assert.ok(d.querySelector('.destination-home'));assert.equal(d.querySelector('[data-id]'),null);
 }finally{c.close()}
});

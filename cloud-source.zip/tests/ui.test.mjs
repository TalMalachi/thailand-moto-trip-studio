import {test} from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
import {JSDOM} from 'jsdom';
const bundle=await build({entryPoints:['src/app.js'],bundle:true,format:'iife',write:false,plugins:[{name:'external-sdk-boundary',setup(b){b.onResolve({filter:/^@supabase\/supabase-js$/},()=>({path:'sdk',namespace:'boundary'}));b.onLoad({filter:/.*/,namespace:'boundary'},()=>({contents:'export const createClient = () => globalThis.__client;'}))}}]});
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}};
const pause=()=>new Promise(r=>setTimeout(r,15));
async function setup(){
 const dom=new JSDOM('<div id="account"></div><nav id="tabs"></nav><div id="message"></div><main id="view"></main><dialog id="editor"></dialog>',{url:'https://app.test/',runScripts:'outside-only'}),w=dom.window;
 w.structuredClone=structuredClone;w.confirm=()=>true;
 w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','')};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open')};
 let user='A',pending=null;const callbacks=[];
 const trip=()=>({id:'trip-'+user,settings:{start:'',days:21,budget:0,currency:'ILS'},version:1});
 w.__client={auth:{getSession:async()=>({data:{session:{user:{id:'A',email:'a@example.invalid'}}},error:null}),onAuthStateChange:cb=>{callbacks.push(cb);return {data:{subscription:{unsubscribe(){}}}}}},from(table){const q={select(){return q},eq(){return q},order(){return q},limit(){if(pending){const x=pending;pending=null;return x.promise}return Promise.resolve({data:[trip()],error:null})},range(){return Promise.resolve({data:[{id:'item-'+user,kind:'task',payload:{title:'private-'+user,done:false},version:1}],error:null})}};return q}};
 w.eval(bundle.outputFiles[0].text);await pause();
 return {w,close:()=>w.close(),defer:()=>{const d=deferred();pending=d;return d},emit(s){user=s?.user.id;callbacks.forEach(cb=>cb('TEST',s))},tripResult:()=>({data:[trip()],error:null})};
}
test('switching accounts clears previous account private editor and loads the new account',async()=>{const c=await setup();try{c.w.document.querySelector('[data-tab=task]').click();c.w.document.querySelector('[data-action=edit]').click();assert.equal(c.w.document.querySelector('#editor input').value,'private-A');c.emit({user:{id:'B',email:'b@example.invalid'}});await pause();assert.equal(c.w.document.querySelector('#editor').open,false);assert.equal(c.w.document.querySelector('#editor').textContent,'');c.w.document.querySelector('[data-tab=task]').click();assert.match(c.w.document.querySelector('#view').textContent,/private-B/)}finally{c.close()}});
test('failed old request after logout cannot replace the login screen',async()=>{const c=await setup();try{const d=c.defer();c.w.document.querySelector('#refresh').click();c.emit(null);await pause();d.reject(Error('stale failure'));await pause();assert.ok(c.w.document.querySelector('#login'));assert.equal(c.w.document.querySelector('#retry'),null)}finally{c.close()}});
test('in-flight refresh does not destroy a settings draft entered after it started',async()=>{const c=await setup();try{const d=c.defer();c.w.document.querySelector('#refresh').click();c.w.document.querySelector('[data-tab=settings]').click();const budget=c.w.document.querySelector('input[name=budget]');budget.value='1234';budget.dispatchEvent(new c.w.Event('input',{bubbles:true}));d.resolve(c.tripResult());await pause();assert.equal(c.w.document.querySelector('input[name=budget]').value,'1234')}finally{c.close()}});

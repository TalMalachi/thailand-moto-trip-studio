import test from 'node:test';
import assert from 'node:assert/strict';
import {createPlanningApi} from '../src/planning-api.js';
test('planner HTTP errors show the safe server response instead of hiding it',async()=>{
 const api=createPlanningApi({functions:{invoke:async()=>({data:null,error:{context:Response.json({error:'הסוכן עדיין אינו מחובר לספק AI עם תמחור מאומת. ההרצה חסומה.'},{status:503})}})}});
 await assert.rejects(()=>api.overview('test'),/תמחור מאומת/);
});
test('malformed error responses retain a generic message without exposing response text',async()=>{
 const api=createPlanningApi({functions:{invoke:async()=>({data:null,error:{context:new Response('private server traceback',{status:500})}})}});
 await assert.rejects(()=>api.overview('test'),e=>!e.message.includes('private')&&e.message.includes('שירות הסוכן'));
});

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {validatePolicy,validatePolicies,policyFields,policiesMarkup,getBookingPolicy} from '../src/booking-policies.js';
import {validateSettings,exportTrip,parseBackup} from '../src/backup.js';
test('category-specific policy fields and strict optional budget validation',()=>{
 assert.ok(policyFields('מלון').some(f=>f.key==='breakfast'));assert.ok(policyFields('אופנוע').some(f=>f.key==='loweredBike'));assert.ok(policyFields('טיסה פנימית').some(f=>f.key==='baggageKg'));
 const p=validatePolicy({category:'מלון',maxBudget:700,budgetBasis:'night',cancellation:'free_required',roomType:'single',breakfast:'required',requiredNotes:'שקט',freeText:'חגים לפי התאריכים'});assert.equal(p.maxBudget,700);assert.equal(p.guests,null);
 assert.throws(()=>validatePolicy({category:'מלון',maxBudget:-1}));assert.throws(()=>validatePolicy({category:'מלון',breakfast:'bad'}));assert.throws(()=>validatePolicy({category:'מלון',guests:1.5}));assert.throws(()=>validatePolicies([{category:'Hotel'},{category:'hotel'}]));
});
test('policies survive settings validation and destination backup without leaking across destinations',()=>{
 const p=validatePolicy({category:'אופנוע',loweredBike:'required',freeText:'BMW GS Low'}),settings={start:'',days:21,budget:0,currency:'ILS',bookingPolicies:[p]};
 assert.deepEqual(validateSettings(settings).bookingPolicies,[p]);const parsed=parseBackup(exportTrip({settings,items:[],destination_name:'תאילנד'}));assert.deepEqual(parsed.settings.bookingPolicies,[p]);assert.equal(getBookingPolicy({bookingPolicies:[]},'אופנוע'),null);assert.equal(getBookingPolicy(settings,'אופנוע').loweredBike,'required');
});
test('policy summary escapes free text and displays named hard requirements',()=>{const p=validatePolicy({category:'מלון',cancellation:'free_required',freeText:'<script>alert(1)</script>'});const markup=policiesMarkup([],[p],null);assert.match(markup,/ביטול ללא עלות/);assert.ok(!markup.includes('<script>'));assert.match(markup,/&lt;script&gt;/)});

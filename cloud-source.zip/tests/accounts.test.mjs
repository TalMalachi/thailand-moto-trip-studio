import {test} from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import * as accounts from '../src/accounts.js';

test('superuser package editor sends exact agorot and prevents invalid money',async()=>{
 assert.equal(typeof accounts.openAccountAdmin,'function');
 const dom=new JSDOM('<dialog></dialog>'),dialog=dom.window.document.querySelector('dialog');dialog.showModal=()=>{};
 const calls=[];const api={list:async()=>({accounts:[]}),package:async p=>calls.push(p)};
 await accounts.openAccountAdmin({dialog,api,state:{billingVersion:7},changed:async()=>{}});
 const f=dialog.querySelector('[data-package-form]');f.elements.name.value='טיול';f.elements.price.value='123.45';f.elements.runs.value='12';
 f.dispatchEvent(new dom.window.Event('submit',{cancelable:true,bubbles:true}));await new Promise(r=>setTimeout(r,0));
 assert.deepEqual(calls,[{p_version:7,p_name:'טיול',p_price_agorot:12345,p_ai_runs:12}]);
 dom.window.close();
});
test('registration collects address and uses hosted-card disclosure without card fields',()=>{
 assert.equal(typeof accounts.registrationMarkup,'function');
 const dom=new JSDOM(accounts.registrationMarkup()),d=dom.window.document;
 for(const name of ['name','email','password','phone','street','city','postcode','country'])assert.ok(d.querySelector('[name='+name+']'));
 assert.equal(d.querySelector('[autocomplete=cc-number]'),null);assert.match(d.body.textContent,/חד־פעמי/);assert.match(d.body.textContent,/דף תשלום מאובטח/);
 dom.window.close();
});
test('checkout for an existing trip identifies the selected destination before consent',()=>{const dom=new JSDOM('<main></main>'),root=dom.window.document.querySelector('main');accounts.mountOnboarding({root,state:{status:'active',emailVerified:true,profile:{}},api:{},refresh(){},signOut(){},tripId:'trip',destinationName:'יפן'});assert.equal(root.querySelector('[data-checkout] [name=destination]').value,'יפן');dom.window.close()});

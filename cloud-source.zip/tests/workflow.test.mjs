import {test} from 'node:test';
import assert from 'node:assert/strict';
import {workflowStatus,workflowStatistics,statisticsMarkup} from '../src/workflow.js';
import {validatePayload,exportTrip,parseBackup} from '../src/backup.js';
test('new workflow defaults and explicit agent statuses retain legacy completion',()=>{
 assert.equal(workflowStatus({kind:'booking',payload:{status:'לבדיקה'}}),'opened');
 assert.equal(workflowStatus({kind:'task',payload:{done:true}}),'completed');
 assert.equal(workflowStatus({kind:'task',payload:{done:true,workflowStatus:'awaiting_details'}}),'awaiting_details');
});
test('statistics cross category and workflow status with zero-count statuses',()=>{
 const rows=[{kind:'booking',payload:{type:'מלון',workflowStatus:'email_sent'}},{kind:'booking',payload:{type:'מלון',workflowStatus:'awaiting_approval'}},{kind:'booking',payload:{type:'טיסה',workflowStatus:'completed'}}];
 const stats=workflowStatistics(rows);assert.equal(stats.total,3);assert.equal(stats.counts.email_sent,1);assert.equal(stats.counts.opened,0);assert.equal(stats.categories.find(x=>x.category==='מלון').total,2);assert.equal(stats.categories.find(x=>x.category==='מלון').counts.awaiting_approval,1);assert.match(statisticsMarkup(rows),/ממתין לאישורך/);assert.equal(workflowStatistics([]).total,0);
});
test('validation preserves workflow updates from an agent and rejects unknown statuses',()=>{
 const input={title:'Book hotel',category:'מלונות',done:false,workflowStatus:'email_sent',workflowUpdatedAt:'2026-10-30T18:00:00Z',workflowUpdatedBy:'agent'};
 assert.deepEqual(validatePayload('task',input),input);
 assert.throws(()=>validatePayload('task',{...input,workflowStatus:'invented'}),/Invalid workflow/);
});

import test from 'node:test';import assert from 'node:assert/strict';
import {expenseRows,expenseStatistics,validateExpenses,expensesMarkup} from '../src/expenses.js';import {validateSettings,parseBackup,exportTrip} from '../src/backup.js';
const items=[{id:'hotel',kind:'booking',payload:{name:'Hotel',type:'מלון',cost:1000,paid:250}},{id:'bike',kind:'booking',payload:{name:'Bike',type:'אופנוע',cost:0,paid:100}},{id:'not-expense',kind:'task',payload:{title:'Task'}}];
const expenses=[{id:'food',name:'אוכל',category:'אוכל',cost:200,paid:25,notes:''},{id:'free',name:'ללא עלות',category:'אוכל',cost:0,paid:0,notes:''}];
test('expense totals distinguish unpaid commitments, remaining cash budget, planning balance and unknown prices without duplicates',()=>{
 const rows=expenseRows([...items,items[0]],{expenses}),s=expenseStatistics(rows,1500);assert.equal(rows.length,4);assert.equal(s.planned,1200);assert.equal(s.paid,375);assert.equal(s.projected,1300);assert.equal(s.unpaid,925);assert.equal(s.remainingBudget,1125);assert.equal(s.planningBalance,200);assert.equal(s.unknown,1);assert.equal(rows.find(r=>r.id==='free').cost,0);assert.equal(rows.find(r=>r.id==='bike').cost,null);
 const hotel=s.categories.find(c=>c.category==='מלון');assert.equal(hotel.unpaid,750);assert.equal(s.categories.find(c=>c.category==='אוכל').paid,25);
 const over=expenseStatistics([{id:'x',name:'x',category:'x',cost:10,paid:20}],15);assert.equal(over.unpaid,0);assert.equal(over.remainingBudget,-5);assert.equal(over.planningBalance,-5);assert.equal(expenseStatistics(rows,0).remainingBudget,null);
 const cents=expenseStatistics([{id:'x',category:'x',cost:.1,paid:.1},{id:'y',category:'x',cost:.2,paid:.2}],1);assert.equal(cents.paid,.3);
});
test('manual expenses are bounded, preserve unknown versus free and round-trip through settings and backup',()=>{
 const settings={start:'',days:21,budget:1500,currency:'ILS',expenses};assert.deepEqual(validateSettings(settings).expenses,expenses);assert.deepEqual(parseBackup(exportTrip({settings,items:[]})).settings.expenses,expenses);
 assert.throws(()=>validateExpenses([{...expenses[0],paid:-1}]));assert.throws(()=>validateExpenses([{...expenses[0],cost:Infinity}]));assert.throws(()=>validateExpenses([expenses[0],expenses[0]]));assert.throws(()=>validateExpenses([{...expenses[0],name:''}]));
});
test('finance page exposes category totals, partial-estimate warning, editable rows and safe text',()=>{
 const html=expensesMarkup({items,settings:{budget:1500,expenses:[{...expenses[0],name:'<script>bad</script>'}]}});assert.match(html,/תקציב והוצאות/);assert.match(html,/יתרת תקציב לאחר תשלומים/);assert.match(html,/יתרת תקציב לאחר התכנון/);assert.match(html,/חסרים מחירים/);assert.match(html,/סטטיסטיקות לפי קטגוריה/);assert.match(html,/data-add-expense/);assert.match(html,/data-expense-edit/);assert.doesNotMatch(html,/<script>/);assert.match(html,/&lt;script&gt;/);
});

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {popupDimensions} from '../src/map-popup-layout.js';
test('popup reserves room for its wrapper, close button and pointer inside a narrow map',()=>{
 for(const [width,height] of [[220,340],[320,340],[390,420],[900,620]]){
  const options=popupDimensions(width,height);
  assert.ok(options.maxWidth+70<=width);assert.ok(options.maxHeight+110<=height);assert.ok(options.minWidth<=options.maxWidth);
 }
 assert.ok(popupDimensions(900,620).maxWidth<=340);
});

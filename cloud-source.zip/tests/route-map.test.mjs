import {test} from 'node:test';
import assert from 'node:assert/strict';
import {routePoints,groupRoutePoints,navigationLinks} from '../src/route-points.js';
import {validatePayload} from '../src/backup.js';
test('precise stop coordinates and coordinate links take priority over general destination locations',()=>{
 const items=[{id:'a',kind:'stop',payload:{day:1,place:'צ׳אנג מאי',lat:'18.8',lng:'98.9'}},{id:'b',kind:'stop',payload:{day:2,place:'תחנה',url:'https://www.google.com/maps/search/?api=1&query=18.7%2C98.8'}}];
 const p=routePoints(items);assert.equal(p.length,2);assert.deepEqual([p[0].lat,p[0].lng,p[0].precision],[18.8,98.9,'exact']);assert.equal(p[1].lat,18.7);
});
test('general locations are marked approximate, repeated locations group their days and unknown stops stay unresolved',()=>{
 const items=[1,2].map(day=>({id:String(day),kind:'stop',payload:{day,place:'פאי'}}));items.push({id:'u',kind:'stop',payload:{day:3,place:'Some unknown stop'}});
 const p=routePoints(items);assert.equal(p.length,2);assert.equal(p[0].precision,'area');const g=groupRoutePoints(p);assert.equal(g.length,1);assert.deepEqual(g[0].points.map(x=>x.day),[1,2]);
});
test('navigation opens the chosen coordinates or destination, safely encoding special characters',()=>{
 const exact=navigationLinks({lat:18.8,lng:98.9,precision:'exact',label:'target'});assert.equal(new URL(exact.google).searchParams.get('destination'),'18.8,98.9');assert.equal(new URL(exact.waze).searchParams.get('ll'),'18.8,98.9');assert.equal(new URL(exact.waze).searchParams.get('navigate'),'yes');
 const area=navigationLinks({label:'<one & two>',query:'Pai, Thailand',precision:'area'});assert.equal(new URL(area.waze).searchParams.get('q'),'Pai, Thailand');assert.equal(new URL(area.waze).searchParams.has('ll'),false);
});
test('stop coordinates survive validation and reject partial or out of range inputs',()=>{
 const p=validatePayload('stop',{day:1,place:'target',lat:'18.8',lng:'98.9'});assert.equal(p.lat,'18.8');assert.equal(p.lng,'98.9');
 assert.throws(()=>validatePayload('stop',{day:1,place:'target',lat:'99',lng:'98.9'}));assert.throws(()=>validatePayload('stop',{day:1,place:'target',lat:'18.8'}));assert.equal('lat' in validatePayload('stop',{day:1,place:'target'}),false);
});
test('another destination does not inherit Thailand navigation context',()=>{const p=routePoints([{id:'v',kind:'stop',payload:{day:1,place:'Hanoi',lat:'21.0285',lng:'105.8542'}}],'וייטנאם')[0];assert.equal(p.destination.query,'Hanoi Vietnam');assert.equal(routePoints([{kind:'stop',payload:{day:1,place:'Pai'}}],'וייטנאם').length,0)});

import test from 'node:test';import assert from 'node:assert/strict';
import {dailyTargets,validateDailyResearch,dailyProviderRequest} from '../src/daily-research.js';
const items=[{id:'20000000-0000-4000-8000-000000000001',kind:'booking',title:'Hotel',category:'מלון',version:2,status:'לבדיקה',cost:500},{id:'20000000-0000-4000-8000-000000000002',kind:'booking',title:'Bike',category:'אופנוע',version:1,status:'לבדיקה'}];
const run={input:{budget:5000,budgetDeviationPct:0,start:'2027-01-20',days:2},snapshot:{destination_name:'Thailand',items,settings:{days:2,budget:5000}}};
const result=()=>({summary:'בדיקה ראשונית',warnings:[],checks:items.map((x,n)=>({bookingId:x.id,status:n?'needs_details':'option_found',explanation:'נבדק מידע ציבורי',offers:n?[]:[{supplier:'Hotel Example',label:'חדר לשני לילות',totalCost:700,url:'https://example.com/hotel',sourceUrl:'https://example.com/hotel',details:'מחיר משוער לכל השהייה'}]})),sources:[{url:'https://example.com/hotel',title:'Hotel',excerpt:'Indicative total',priceType:'estimate'}]});
test('daily research must cover each selected booking and cite researched evidence without claiming a booking',()=>{
 const p=validateDailyResearch(result(),run,['https://example.com/hotel']);assert.equal(p.kind,'daily_review');assert.equal(p.checks.length,2);assert.equal(p.checks[0].bookingVersion,2);assert.equal(p.coverage.checked,2);
 const missing=result();missing.checks.pop();assert.throws(()=>validateDailyResearch(missing,run,['https://example.com/hotel']));
 assert.throws(()=>validateDailyResearch(result(),run,[]));const high=result();high.checks[0].offers[0].totalCost=6000;assert.throws(()=>validateDailyResearch(high,run,['https://example.com/hotel']));
 const foreign=result();foreign.checks[0].bookingId='foreign';assert.throws(()=>validateDailyResearch(foreign,run,['https://example.com/hotel']));
});
test('bounded category-balanced target selection skips confirmed reservations and never adds private refs to prompts',()=>{
 const snapshot={...run.snapshot,items:[...items,{id:'done',kind:'booking',category:'מלון',status:'הוזמן',ref:'private-ref'}]};assert.equal(dailyTargets(snapshot).length,2);
 const req=dailyProviderRequest({...run,snapshot},{tools:[{type:'web_search'}],max_tool_calls:1});assert.equal(req.text.format.strict,true);assert.match(req.input,/No purchases/);assert.doesNotMatch(req.input,/private-ref/);
});
test('manual trip expenses reserve budget before supplier options can be offered',()=>{
 const changed={...run,snapshot:{...run.snapshot,settings:{...run.snapshot.settings,expenses:[{id:'food',name:'Food',category:'Food',cost:4500,paid:0,notes:''}]}}};assert.throws(()=>validateDailyResearch(result(),changed,['https://example.com/hotel']),/budget/);
});

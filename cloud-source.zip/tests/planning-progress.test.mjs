import test from 'node:test';import assert from 'node:assert/strict';
import {runProgress,progressClocks,renderRunProgress} from '../src/planning-progress.js';
const now=Date.parse('2026-10-31T10:03:00Z');
test('active monitoring shows elapsed, last real activity and deadline without invented completion percent',()=>{
 const run={state:'researching',created_at:'2026-10-31T10:00:00Z',updated_at:'2026-10-31T10:01:00Z',progress:{stage:'provider_working',checkedAt:'2026-10-31T10:02:00Z',events:[{stage:'submitted',at:'2026-10-31T10:01:00Z'}]}};
 const v=runProgress(run,now);assert.equal(v.active,true);assert.equal(v.stage,'provider_working');assert.equal(v.stale,false);assert.match(v.description,/זמן סיום מדויק/);assert.ok(!('percent' in v));
 const clock=progressClocks(run,now);assert.equal(clock.elapsed,'03:00');assert.equal(clock.deadline,'12:00');assert.equal(clock.lastActivity,'01:00');
 const stale=runProgress(run,now+4*60000);assert.equal(stale.stale,true);
});
test('cancelled work with unknown reserved costs is stopped, never presented as still researching',()=>{
 const r={state:'cancelled',reserved_agorot:445,created_at:'2026-10-31T10:00:00Z',updated_at:'2026-10-31T10:02:00Z',progress:{stage:'provider_working'}};
 const p=runProgress(r,now);assert.equal(p.active,false);assert.match(p.title,/בוטלה/);assert.match(p.notice,/4.45/);assert.equal(progressClocks(r,now+60000).elapsed,'02:00');assert.doesNotMatch(renderRunProgress(r,now),/העבודה מתבצעת בשרת/);
});
test('queued pause freezes its deadline and displays continue separately from cancellation',()=>{
 const r={state:'queued',created_at:'2026-10-31T10:00:00Z',paused_at:'2026-10-31T10:01:00Z',deadline_at:'2026-10-31T10:15:00Z'};
 assert.equal(progressClocks(r,now).deadline,'14:00');assert.equal(progressClocks(r,now).elapsed,'01:00');const html=renderRunProgress(r,now);assert.match(html,/data-resume-run/);assert.match(html,/data-cancel-run/);assert.doesNotMatch(html,/data-pause-run/);
});
test('resuming a queued pause uses its extended deadline instead of a false timeout warning',()=>{
 const r={state:'queued',created_at:'2026-10-31T09:40:00Z',updated_at:'2026-10-31T10:03:00Z',deadline_at:'2026-10-31T10:15:00Z'};assert.equal(progressClocks(r,now).deadline,'12:00');assert.equal(runProgress(r,now).notice,'');
});

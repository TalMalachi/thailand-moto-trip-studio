import test from 'node:test';
import assert from 'node:assert/strict';
import {createDependencies,handlePlannerRequest} from '../server/planning-worker.js';
test('overview accepts empty successful runtime RPC before reading owner overview',async()=>{
 const deps=createDependencies({SUPABASE_URL:'https://example.invalid',SUPABASE_SERVICE_ROLE_KEY:'test'},async url=>{
  if(url.endsWith('/auth/v1/user'))return Response.json({id:'owner'});
  if(url.endsWith('/planner_runtime_ready'))return new Response(null,{status:204});
  if(url.endsWith('/planner_overview'))return Response.json({ready:false,monthlyLimitAgorot:2000});
  throw Error('Unexpected request');
 });
 const r=await handlePlannerRequest(new Request('https://example.invalid',{method:'POST',headers:{authorization:'Bearer test'},body:JSON.stringify({action:'overview',tripId:'20000000-0000-4000-8000-000000000001'})}),deps);
 assert.equal(r.status,200);assert.equal((await r.json()).ready,false);
});
test('empty unsuccessful RPC still fails',async()=>{
 const deps=createDependencies({SUPABASE_URL:'https://example.invalid'},async()=>new Response(null,{status:503}));
 await assert.rejects(()=>deps.db('planner_runtime_ready',{}));
});

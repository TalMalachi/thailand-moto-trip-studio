import test from 'node:test';import assert from 'node:assert/strict';
import {tripCompletion} from '../src/trip-completion.js';
test('completion counts unique actionable records and never treats approval as a reservation',()=>{
 const rows=[{id:'b',kind:'booking',payload:{type:'מלון',status:'לבדיקה',workflowStatus:'completed'}},{id:'t',kind:'task',payload:{category:'מלון',done:true}},{id:'g',kind:'gear',payload:{category:'ציוד',status:'טרם נרכש'}},{id:'s',kind:'stop',payload:{day:1,place:'City'}}];
 const r=tripCompletion([...rows,rows[0]],{days:2});assert.equal(r.total,3);assert.equal(r.completed,1);assert.equal(r.percent,33.3);assert.equal(r.categories.find(x=>x.category==='מלון').percent,50);assert.equal(r.route.covered,1);assert.equal(r.route.percent,50);
});
test('empty preparation denominator is unknown and explicit booked and owned records are complete',()=>{
 assert.equal(tripCompletion([],{days:21}).percent,null);
 const r=tripCompletion([{id:'b',kind:'booking',payload:{status:'הוזמן'}},{id:'g',kind:'gear',payload:{status:'קיים'}}],{});assert.equal(r.percent,100);
});

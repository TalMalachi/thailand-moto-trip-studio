import {test} from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {mountHeaderPanel} from '../src/header-panel.js';
test('header collapses when scrolling and expands from its small accessible toggle',()=>{
 const dom=new JSDOM('<header class="site-header">Trip</header><div id="account">Account</div>'),w=dom.window,d=w.document;
 mountHeaderPanel(d,w,()=>true);const button=d.querySelector('.header-toggle'),panel=d.querySelector('#floating-header');
 w.scrollY=120;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'false');assert.ok(panel.inert);
 button.click();assert.equal(button.getAttribute('aria-expanded'),'true');assert.equal(panel.inert,false);
 w.scrollY=125;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'true');
 w.scrollY=170;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'false');
 w.scrollY=0;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'true');w.close();
});
test('compact banner overrides the old mobile menu widths so controls stay at touch-target size',async()=>{
 const {readFile}=await import('node:fs/promises');const dom=new JSDOM('<div id="floating-header"><div class="account-tools"><details class="account-menu"><summary>Account</summary></details><button>Refresh</button></div></div>');const w=dom.window,d=w.document;
 const style=d.createElement('style');style.textContent='.account-menu{min-width:100px}.account-tools{width:100%}.account-tools>button{flex:1}'+await readFile('src/ui.css','utf8');d.head.append(style);
 try{assert.equal(w.getComputedStyle(d.querySelector('.account-menu')).minWidth,'44px');assert.equal(w.getComputedStyle(d.querySelector('.account-tools')).width,'auto');assert.equal(w.getComputedStyle(d.querySelector('button')).flexGrow,'0')}finally{w.close()}
});

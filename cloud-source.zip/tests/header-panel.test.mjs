import {test} from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {mountHeaderPanel} from '../src/header-panel.js';
test('header collapses when scrolling and expands from its small accessible toggle',()=>{
 const dom=new JSDOM('<header class="site-header">Trip</header><div id="account">Account</div>'),w=dom.window,d=w.document;
 mountHeaderPanel(d,w,()=>true);const button=d.querySelector('.header-toggle'),panel=d.querySelector('#floating-header');
 w.scrollY=120;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'false');assert.ok(panel.inert);
 button.click();assert.equal(button.getAttribute('aria-expanded'),'true');assert.equal(panel.inert,false);
 w.scrollY=125;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'true');
 w.scrollY=170;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'false');
 w.scrollY=0;w.dispatchEvent(new w.Event('scroll'));assert.equal(button.getAttribute('aria-expanded'),'true');w.close();
});

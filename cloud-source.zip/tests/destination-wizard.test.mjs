import test from 'node:test';import assert from 'node:assert/strict';import {JSDOM} from 'jsdom';
import {openDestinationWizard} from '../src/destination-wizard.js';import {planningDraft,validatePlanningDraft} from '../src/planning-draft.js';import {validateSettings,exportTrip,parseBackup} from '../src/backup.js';
const destination={id:'t',version:3,destination_name:'תאילנד',is_active:true,settings:{start:'2027-01-20',days:21,budget:20000,currency:'ILS',bookingPolicies:[]}};
const tick=()=>new Promise(r=>setTimeout(r,5));
function setup(extra={}){const w=new JSDOM('<dialog></dialog>').window;w.confirm=()=>true;const dialog=w.document.querySelector('dialog');dialog.showModal=()=>dialog.open=true;dialog.close=()=>{dialog.open=false;dialog.dispatchEvent(new w.Event('close'))};let saved=[];openDestinationWizard({dialog,destination,onSave:async x=>{saved.push(x);return {...destination,destination_name:x.name,is_active:x.active,settings:x.settings,version:4}},...extra});return {w,d:w.document,saved,close:()=>{dialog.close();w.close()}}}
test('all planning categories are editable through accessible wizard tabs, with pending and saved colors and independent saving',async()=>{const c=setup();try{
 assert.equal(c.d.querySelectorAll('[role=tab]').length,8);for(const name of ['earlierDays','laterDays','shorterDays','longerDays','budgetDeviationPct','travelers','rooms','departure','transport','preference_pace','preference_lodging','preference_driving','preference_interests','preference_roads','preference_constraints','preferences','runLimit'])assert.ok(c.d.querySelector('[name="'+name+'"]'),name);
 const departure=c.d.querySelector('[name=departure]');departure.value='תל אביב';departure.dispatchEvent(new c.w.Event('input',{bubbles:true}));assert.equal(c.d.querySelector('[data-wizard-tab=travelers]').dataset.state,'dirty');
 c.d.querySelector('[data-wizard-tab=style]').click();c.d.querySelector('[name=preference_lodging]').value='boutique';c.d.querySelector('[name=preference_lodging]').dispatchEvent(new c.w.Event('change',{bubbles:true}));
 c.d.querySelector('[name=preferences]').value='בלי רכיבה בלילה';c.d.querySelector('[name=preferences]').dispatchEvent(new c.w.Event('input',{bubbles:true}));
 c.d.querySelector('[data-wizard-save]').click();await tick();assert.equal(c.saved.length,1);assert.equal(c.saved[0].settings.planningDraft.choices.lodging,'boutique');assert.equal(c.saved[0].settings.planningDraft.freeText,'בלי רכיבה בלילה');assert.equal(c.d.querySelector('[data-wizard-tab=travelers]').dataset.state,'complete');assert.equal(c.d.querySelector('dialog').open,true);assert.match(c.d.querySelector('[data-dialog-status]').textContent,/נשמר/);
 const draft=c.saved[0].settings.planningDraft;assert.deepEqual(validateSettings(c.saved[0].settings).planningDraft,draft);assert.deepEqual(parseBackup(exportTrip({...destination,settings:c.saved[0].settings,items:[]})).settings.planningDraft,draft);
 }finally{c.close()}});
test('legacy agent inputs restore selectable preferences and preserve free text while current dates and budget win',async()=>{
 const input={start:'2026-01-01',days:2,budget:100,departure:'TLV',preferences:'קצב הטיול: קצב רגוע\nמה מעניין אותך?: טבע ונופים\nהעדפות נוספות בטקסט חופשי: פאי'};const draft=planningDraft(destination.settings,input);assert.equal(draft.input.start,destination.settings.start);assert.equal(draft.input.budget,20000);assert.equal(draft.choices.pace,'relaxed');assert.deepEqual(draft.choices.interests,['nature']);assert.equal(draft.freeText,'פאי');
 const c=setup({api:{overview:async()=>({run:{input}})}});try{await tick();assert.equal(c.d.querySelector('[name=preference_pace]').value,'relaxed');assert.equal(c.d.querySelector('[name=preferences]').value,'פאי')}finally{c.close()}
 assert.throws(()=>validatePlanningDraft({...draft,freeText:'a'.repeat(2001)}));
});
test('failed save keeps draft, late hydration never overwrites edits, and next/previous retains fields',async()=>{
 let resolve;const c=setup({api:{overview:()=>new Promise(r=>resolve=r)},onSave:async()=>{throw Error('offline')}});try{const field=c.d.querySelector('[name=departure]');field.value='My edit';field.dispatchEvent(new c.w.Event('input',{bubbles:true}));resolve({run:{input:{departure:'old'}}});await tick();assert.equal(c.d.querySelector('[name=departure]').value,'My edit');c.d.querySelector('[data-wizard-next]').click();c.d.querySelector('[data-wizard-prev]').click();assert.equal(c.d.querySelector('[name=departure]').value,'My edit');c.d.querySelector('[data-wizard-save]').click();await tick();assert.equal(c.d.querySelector('[name=departure]').value,'My edit');assert.match(c.d.querySelector('[data-dialog-status]').textContent,/offline/);}finally{c.close()}
});
test('optional no-preference review saves green, keyboard navigation works and native close notifies once',async()=>{
 let closed=0;const c=setup({onClose:()=>closed++});try{const tab=c.d.querySelector('[data-wizard-tab=style]');tab.click();assert.equal(tab.dataset.state,'empty');c.d.querySelector('[data-wizard-mark=style]').click();assert.equal(tab.dataset.state,'dirty');c.d.querySelector('[data-wizard-save]').click();await tick();assert.equal(tab.dataset.state,'complete');tab.dispatchEvent(new c.w.KeyboardEvent('keydown',{key:'ArrowLeft',bubbles:true}));assert.equal(c.d.querySelector('[data-wizard-tab=interests]').getAttribute('aria-selected'),'true');c.d.querySelector('dialog').close();assert.equal(closed,1);}finally{c.w.close()}
});
test('a planning-open failure reports that settings were saved and permits a retry on the saved destination',async()=>{
 const c=setup({onPlan:async()=>{throw Error('temporary read failure')}});try{c.d.querySelector('[name=departure]').value='TLV';c.d.querySelector('#plan-destination').click();await tick();assert.equal(c.saved.length,1);assert.match(c.d.querySelector('[data-dialog-status]').textContent,/נשמרו.*לא ניתן לפתוח/);assert.equal(c.d.querySelector('#plan-destination').disabled,false);}finally{c.close()}
});
test('saving during previous-input loading waits and merges untouched preferences without overwriting the current edit',async()=>{
 let resolve;const c=setup({api:{overview:()=>new Promise(r=>resolve=r)}});try{const departure=c.d.querySelector('[name=departure]');departure.value='NEW';departure.dispatchEvent(new c.w.Event('input',{bubbles:true}));c.d.querySelector('[data-wizard-save]').click();await tick();assert.equal(c.saved.length,0);resolve({run:{input:{departure:'OLD',rooms:1,preferences:'סגנון לינה: מלונות בוטיק'}}});await tick();assert.equal(c.saved.length,1);assert.equal(c.saved[0].settings.planningDraft.input.departure,'NEW');assert.equal(c.saved[0].settings.planningDraft.choices.lodging,'boutique');}finally{c.close()}
});
test('compact mobile step picker follows next/previous, exposes completion and retains unsaved fields',async()=>{
 const c=setup();try{const picker=c.d.querySelector('[data-wizard-mobile-step]');assert.ok(picker);assert.equal(picker.options.length,8);picker.value='travelers';picker.dispatchEvent(new c.w.Event('change',{bubbles:true}));assert.equal(c.d.querySelector('[data-wizard-panel=travelers]').hidden,false);
 const field=c.d.querySelector('[name=departure]');field.value='TLV';field.dispatchEvent(new c.w.Event('input',{bubbles:true}));assert.equal(picker.dataset.state,'dirty');assert.match(picker.selectedOptions[0].textContent,/טרם נשמר/);
 c.d.querySelector('[data-mobile-next]').click();assert.equal(picker.value,'style');c.d.querySelector('[data-mobile-prev]').click();assert.equal(picker.value,'travelers');assert.equal(field.value,'TLV');
 c.d.querySelector('[data-wizard-save]').click();await tick();assert.equal(picker.dataset.state,'complete');assert.match(picker.selectedOptions[0].textContent,/נשמר/);
 }finally{c.close()}
});
test('wizard never shows the full step grid by default, even when phone viewport detection does not apply',()=>{
 const c=setup();try{const nav=c.d.querySelector('.wizard-tabs'),layout=c.d.querySelector('.wizard-layout'),picker=c.d.querySelector('.wizard-mobile-navigation');assert.equal(nav.hidden,true);assert.equal(c.w.getComputedStyle(nav).display,'none');assert.equal(c.w.getComputedStyle(layout).display,'block');assert.equal(c.w.getComputedStyle(picker).display,'flex');assert.equal(picker.querySelectorAll('select').length,1);assert.equal(c.d.querySelectorAll('[role=tabpanel]:not([hidden])').length,1);}finally{c.close()}
});
test('step arrows never focus the native picker or open its list during navigation',()=>{
 const c=setup();try{const picker=c.d.querySelector('[data-wizard-mobile-step]');let pickerFocus=0;picker.focus=()=>pickerFocus++;const scroll=[];c.d.querySelector('.wizard-content').scrollIntoView=opts=>scroll.push(opts);
 c.d.querySelector('[data-mobile-next]').click();assert.equal(picker.value,'dates');assert.equal(pickerFocus,0);assert.equal(c.d.querySelector('.wizard-tabs').hidden,true);assert.equal(scroll.at(-1)?.block,'nearest');
 c.d.querySelector('[data-mobile-prev]').click();assert.equal(picker.value,'destination');assert.equal(pickerFocus,0);
 }finally{c.close()}
});

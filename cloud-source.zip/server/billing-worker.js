import {handleCardSetup} from './card-setup.js';
const origin='https://talmalachi.github.io';
const site=origin+'/motor-trip-studio/';
const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, GET, OPTIONS','Cache-Control':'no-store'};
const uuid=s=>typeof s==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
export function billingConfig(env){const terminal=Number(env.CARDCOM_TERMINAL_NUMBER);if(env.BILLING_ENABLED!=='true'||!Number.isSafeInteger(terminal)||terminal<1||terminal>2147483647||!env.CARDCOM_API_NAME||env.CARDCOM_API_NAME.length>200||env.SUPABASE_URL!=='https://nxpvxsyiyigedmplsdnz.supabase.co')return null;
 return {terminal,apiName:env.CARDCOM_API_NAME,returnUrl:site,webhookUrl:env.SUPABASE_URL+'/functions/v1/trip-billing?action=webhook'};}
function amountAgorot(value){const s=String(value);if(!/^\d{1,9}(?:\.\d{1,2})?$/.test(s))throw Error('Invalid verified amount');const [a,b='']=s.split('.');return Number(a)*100+Number(b.padEnd(2,'0'));}
function transactionId(value){if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('Unsafe transaction number');const s=String(value);if(!/^[1-9][0-9]{0,19}$/.test(s))throw Error('Invalid transaction');return s;}
export function verifyPayment(data,expected,config){const info=data?.TranzactionInfo;
 if(data?.ResponseCode!==0||data.TerminalNumber!==config.terminal||data.LowProfileId?.toLowerCase()!==expected.lowProfileId?.toLowerCase()||data.ReturnValue!==expected.orderId||data.Operation!=='ChargeOnly'||info?.ResponseCode!==0||info.TerminalNumber!==config.terminal||info.CoinId!==1||info.IsRefund!==false||info.NumberOfPayments!==1||amountAgorot(info.Amount)!==expected.priceAgorot)throw Error('Payment verification mismatch');
 const id=transactionId(data.TranzactionId);if(transactionId(info.TranzactionId)!==id)throw Error('Transaction mismatch');return {transactionId:id,amountAgorot:expected.priceAgorot};}
function hostedUrl(value){const u=new URL(value);if(u.protocol!=='https:'||u.hostname!=='secure.cardcom.solutions'||u.port||u.username||u.password||!u.pathname.startsWith('/'))throw Error('Untrusted payment page');return u.href;}
async function requestData(req){const text=await req.text();if(text.length>12000)throw Error('Request too large');if(!text)return {};const type=req.headers.get('content-type')||'';if(type.includes('application/x-www-form-urlencoded'))return Object.fromEntries(new URLSearchParams(text));return JSON.parse(text);}
export async function handleBillingRequest(req,deps){const reply=(data,status=200)=>new Response(JSON.stringify(data),{status,headers});if(req.method==='OPTIONS')return new Response(null,{status:204,headers});if(!['POST','GET'].includes(req.method))return reply({error:'Method not allowed'},405);
 if(req.headers.get('origin')&&req.headers.get('origin')!==origin)return reply({error:'Origin not allowed'},403);
 try{
 const config=billingConfig(deps.env);if(!config)return reply({error:'חיבור ספק הסליקה טרם הוגדר. לא ניתן להתחיל תשלום.'},503);
 const url=new URL(req.url),data=req.method==='GET'?{}:await requestData(req),action=url.searchParams.get('action')||data.action;
 if(['cardWebhook','addCard','reconcileCard'].includes(action))return await handleCardSetup({req,data,url,config,deps,reply,action});
 if(action==='webhook'){
  // The callback is a hint only. Fetch and verify the actual charge with server credentials.
  const fields=Object.fromEntries([...url.searchParams,...Object.entries(data)].map(([k,v])=>[k.toLowerCase(),v]));
  if(!uuid(fields.returnvalue)||!uuid(fields.lowprofileid))return reply({error:'Invalid callback'},400);
  const claim=await deps.db('billing_claim',{p_order:fields.returnvalue,p_low_profile:fields.lowprofileid,p_user:null});
  if(!claim)return reply({error:'Unknown payment'},404);if(claim.paid)return reply({ok:true});if(claim.busy)return reply({error:'Verification pending'},409);
  const result=await deps.provider('GetLpResult',{TerminalNumber:config.terminal,ApiName:config.apiName,LowProfileId:claim.lowProfileId});
  const verified=verifyPayment(result,claim,config);
  await deps.db('billing_confirm',{p_order:claim.orderId,p_fence:claim.fence,p_low_profile:claim.lowProfileId,p_transaction:verified.transactionId,p_amount:verified.amountAgorot});return reply({ok:true});
 }
 if(req.method!=='POST')return reply({error:'Method not allowed'},405);
 const auth=req.headers.get('authorization'),user=auth?await deps.authenticate(auth):null;if(!user?.id)return reply({error:'יש להתחבר מחדש'},401);
 if(action==='status')return reply({enabled:true});
 if(action==='reconcile'){
  if(!uuid(data.orderId))return reply({error:'תשלום לא תקין'},400);
  const claim=await deps.db('billing_claim',{p_order:data.orderId,p_low_profile:null,p_user:user.id});if(!claim)return reply({error:'לא ניתן לבדוק את התשלום'},400);if(claim.paid)return reply({paid:true});if(claim.busy)return reply({pending:true});
  const result=await deps.provider('GetLpResult',{TerminalNumber:config.terminal,ApiName:config.apiName,LowProfileId:claim.lowProfileId});if(result.ResponseCode!==0)return reply({pending:true});
  const verified=verifyPayment(result,claim,config);return reply(await deps.db('billing_confirm',{p_order:claim.orderId,p_fence:claim.fence,p_low_profile:claim.lowProfileId,p_transaction:verified.transactionId,p_amount:verified.amountAgorot}));
 }
 if(action!=='checkout'||!uuid(data.packageId)||data.tripId!=null&&!uuid(data.tripId)||data.consentVersion!=='per-trip-v1')return reply({error:'נתוני תשלום לא תקינים'},400);
 const prepared=await deps.db('billing_prepare',{p_user:user.id,p_package:data.packageId,p_trip:data.tripId||null,p_destination:typeof data.destination==='string'?data.destination:'',p_consent:data.consentVersion});
 if(!prepared.new)return reply({orderId:prepared.order.id,url:hostedUrl(prepared.order.checkout_url)});
 const orderId=prepared.order.id;
 try{
  const result=await deps.provider('Create',{TerminalNumber:config.terminal,ApiName:config.apiName,Operation:'ChargeOnly',Amount:prepared.package.price_agorot/100,ISOCoinId:1,Language:'he',ReturnValue:orderId,ProductName:prepared.package.name.slice(0,50),SuccessRedirectUrl:site+'?billing_return='+orderId,FailedRedirectUrl:site+'?billing_return='+orderId,WebHookUrl:config.webhookUrl,AdvancedDefinition:{MinNumOfPayments:1,MaxNumOfPayments:1,SelectedNumOfPayments:1},UIDefinition:{CardOwnerNameValue:prepared.profile?.name||'',CardOwnerPhoneValue:prepared.profile?.phone||'',CardOwnerEmailValue:prepared.email||'',IsHideCardOwnerIdentityNumber:true}});
  if(result.ResponseCode!==0||!uuid(result.LowProfileId))throw Error('Page creation rejected');const paymentUrl=hostedUrl(result.Url);
  await deps.db('billing_page',{p_order:orderId,p_low_profile:result.LowProfileId,p_url:paymentUrl});return reply({orderId,url:paymentUrl});
 }catch{
  await deps.db('billing_attention',{p_order:orderId});throw Error('יצירת דף התשלום לא אושרה. יש לבדוק את מצב התשלום לפני ניסיון נוסף.');
 }
 }catch{return reply({error:'לא ניתן להשלים את בדיקת התשלום. בדוק את מצב התשלום או פנה למנהל לפני ניסיון נוסף.'},400);}
}
export function createBillingDependencies(env,fetcher=fetch){const url=env.SUPABASE_URL,key=env.SUPABASE_SERVICE_ROLE_KEY;
 async function jsonResponse(r){const text=await r.text();if(text.length>100000)throw Error('Oversized response');if(!r.ok)throw Error('Remote service error');return text?JSON.parse(text):null;}
 return {env,authenticate:async auth=>{const r=await fetcher(url+'/auth/v1/user',{headers:{apikey:key,Authorization:auth},signal:AbortSignal.timeout(10000)});return r.ok?jsonResponse(r):null;},db:async(name,p)=>jsonResponse(await fetcher(url+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify(p),signal:AbortSignal.timeout(20000)})),provider:async(action,p)=>{if(!['Create','GetLpResult'].includes(action))throw Error('Unsupported payment operation');return jsonResponse(await fetcher('https://secure.cardcom.solutions/api/v11/LowProfile/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p),redirect:'error',signal:AbortSignal.timeout(20000)}));}};
}

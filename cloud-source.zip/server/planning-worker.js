import {planningResponseSchema} from '../src/planning-schema.js';
import {validatePlanningInput,validatePlan,planningPrompt,publicUrl} from '../src/planning.js';
const MODEL='gpt-4.1-mini-2025-04-14',MAX_OUTPUT=24000,MAX_TOOLS=1,CONTEXT=1047576;
export function providerConfig(env,now=Date.now()){
 try{if(env.PLANNER_ENABLED!=='true'||env.PLANNER_COSTS_VERIFIED!=='true'||!env.OPENAI_API_KEY)return null;const p=JSON.parse(env.PLANNER_PRICING_JSON||'null');
 if(!p||p.model!==MODEL||!Number.isFinite(Date.parse(p.validUntil))||Date.parse(p.validUntil)<=now||Date.parse(p.validUntil)>now+31*86400000)return null;
 for(const [k,min,max] of [['inputUsdPerMillion',.4,10],['outputUsdPerMillion',1.6,30],['searchUsdPerCall',.01,1],['ilsPerUsdCeiling',1,10],['feeMultiplier',1.18,3]])if(typeof p[k]!=='number'||!Number.isFinite(p[k])||p[k]<min||p[k]>max)return null;
 // Upper bound: each model pass may fill the full documented context window.
 // One bounded tool call means at most two passes. No recursive server tools.
 const boundAgorot=Math.ceil((((CONTEXT*(MAX_TOOLS+1)+MAX_TOOLS*8000)/1e6*p.inputUsdPerMillion)+(MAX_OUTPUT/1e6*p.outputUsdPerMillion)+MAX_TOOLS*p.searchUsdPerCall)*p.ilsPerUsdCeiling*p.feeMultiplier*100);
 if(boundAgorot>500)return null;return {...p,boundAgorot};}catch{return null}
}
export function providerRequest(run,config){const input=validatePlanningInput(run.input),prompt=planningPrompt(run.snapshot,input);if(new TextEncoder().encode(prompt).length>60000)throw Error('Planning context too large');return {model:MODEL,input:prompt,background:true,store:false,text:{format:{type:'json_schema',name:'trip_plan',strict:true,schema:planningResponseSchema}},max_output_tokens:MAX_OUTPUT,max_tool_calls:MAX_TOOLS,tools:[{type:'web_search',search_context_size:'low'}],include:['web_search_call.action.sources']};}
export function usageCost(response,c){const u=response.usage;if(!u||!Number.isInteger(u.input_tokens)||!Number.isInteger(u.output_tokens)||u.input_tokens<0||u.output_tokens<0)throw Error('Unknown usage');const searches=(response.output||[]).filter(x=>x.type==='web_search_call').length;if(searches>MAX_TOOLS||u.input_tokens>CONTEXT*(MAX_TOOLS+1)||u.output_tokens>MAX_OUTPUT)throw Error('Unbounded provider usage');
 // Charge conservatively: do not take cache discounts; include fixed search-content tokens.
 return Math.ceil(((u.input_tokens+searches*8000)/1e6*c.inputUsdPerMillion+u.output_tokens/1e6*c.outputUsdPerMillion+searches*c.searchUsdPerCall)*c.ilsPerUsdCeiling*c.feeMultiplier*100);
}
export async function processJob(job,{db,config,provider,now=Date.now()}){
 if(!job)return;const {run,call}=job;const base={p_run:run.id,p_fence:call.fence};
 const progress=async(stage,status=null,searches=0,records=0,release=false)=>{try{await db('planner_worker_progress',{...base,p_stage:stage,p_provider_status:status,p_searches:searches,p_records:records,p_release:release})}catch{}};
 const finish=(state,spent,message,artifact=null)=>db('planner_worker_finish',{...base,p_state:state,p_artifact:artifact,p_spent:spent,p_message:message});
 if(!call.response_id){
  if(call.dispatched_at){await finish('failed',null,'לא התקבל אישור מהספק. התקציב נשאר שמור; לא יבוצע ניסיון נוסף אוטומטית.');return;}
  if(run.state==='cancelled'){await finish('failed',0,'ההרצה נעצרה לפני הפעלת הספק');return;}
  if(!config||now-Date.parse(run.created_at)>15*60000){await finish('failed',0,'הסוכן אינו זמין או שפג זמן ההמתנה. לא הופעלה קריאת AI.');return;}
  let request;try{request=providerRequest(run,config);if(config.boundAgorot>run.reserved_agorot)throw Error('Insufficient reserve');}catch{await finish('needs_details',0,'נתוני התכנון או התקציב אינם תקינים; יש לבדוק את השאלון.');return;}
  if(!await db('planner_worker_dispatch',{...base,p_pricing:config}))return;
  await progress('submitting');
  try{const response=await provider('create',request);if(!/^resp_[A-Za-z0-9_-]+$/.test(response.id||''))throw Error('Missing receipt');await progress('submitted',response.status||'queued');await db('planner_worker_response',{...base,p_response:response.id});}catch{await finish('failed',null,'לא ניתן לוודא את תוצאת הקריאה. התקציב נותר שמור לבדיקה, ללא ניסיון חוזר.');}return;
 }
 const pricing=call.pricing;if(!pricing){await finish('failed',null,'פרטי התמחור חסרים; נדרשת בדיקה מנהלית.');return;}
 const expired=now-Date.parse(run.created_at)>15*60000;
 let response;try{response=await provider('retrieve',{id:call.response_id});}catch{await progress('provider_retry','unavailable',0,0,!expired);if(expired)await finish('failed',null,'הספק לא החזיר תוצאה בזמן. ההרצה הסתיימה והעלות הלא ידועה נשארת שמורה לבדיקה.');return;} // Safe read can be retried by a future leased worker.
 if(['queued','in_progress'].includes(response.status)){
  if(run.state==='cancelled'||now-Date.parse(run.created_at)>15*60000){try{response=await provider('cancel',{id:call.response_id});}catch{if(expired)await finish('failed',null,'לא ניתן לאשר ביטול אצל הספק. ההרצה הסתיימה והעלות נשארת שמורה לבדיקה.');return;}if(['queued','in_progress'].includes(response.status)){if(expired)await finish('failed',null,'פג זמן ההרצה; העלות נשארת שמורה לבדיקה.');return;}}
  else {const calls=(response.output||[]).filter(x=>x.type==='web_search_call');const searches=calls.filter(x=>x.status==='completed').length;const phase=response.status==='queued'?'provider_queued':calls.some(x=>x.status==='in_progress'||x.status==='searching')?'researching':(response.output||[]).some(x=>x.type==='message')?'drafting':'provider_working';await progress(phase,response.status,searches,0,true);return;}
 }
 let spent;try{spent=usageCost(response,pricing);if(spent>run.reserved_agorot)throw Error('Cost above hold');}catch{await finish('budget_exhausted',null,'לא ניתן לאמת את העלות. התקציב נשאר שמור וההרצה נעצרה לבדיקה.');return;}
 if(run.state==='cancelled'){await finish('failed',spent,'ההרצה נעצרה; העלות עודכנה עבור הפעולות שכבר בוצעו');return;}
 if(response.status!=='completed'){await finish('failed',spent,'הספק לא השלים את התכנון. לא שונו נתוני הטיול.');return;}
 await progress('validating','completed',(response.output||[]).filter(x=>x.type==='web_search_call'&&x.status==='completed').length);
 try{
  const chunks=(response.output||[]).filter(x=>x.type==='message').flatMap(x=>x.content||[]).filter(x=>x.type==='output_text');
  const evidence=(response.output||[]).filter(x=>x.type==='web_search_call').flatMap(x=>x.action?.sources||[]).map(x=>x.url);
  for(const c of chunks)for(const a of c.annotations||[])if(a.type==='url_citation')evidence.push(a.url);
  const raw=chunks.map(c=>c.text).join('');if(raw.length>200000)throw Error('Response too large');
  const artifact=validatePlan(JSON.parse(raw.replace(/^```(?:json)?\s*|\s*```$/g,'')),run.input,evidence);
  const commitments=(run.snapshot.items||[]).filter(r=>r.kind==='booking'&&(['הוזמן','שולם'].includes(r.status)||Number(r.paid)>0)).reduce((sum,r)=>sum+Math.max(Number(r.cost)||0,Number(r.paid)||0),0);
  const additions=artifact.records.filter(r=>r.kind==='booking').reduce((sum,r)=>sum+r.payload.cost,0);
  if(commitments+additions>artifact.estimatedTotal+0.01)throw Error('Existing commitments exceed estimate');
  if(commitments>0)artifact.warnings.push('המחיר הכולל כולל התחייבויות קיימות בסך '+commitments+' ₪; יש לבדוק שאין הצעות כפולות.');
  const time=new Date(now).toISOString();artifact.sources=artifact.sources.map(s=>({...s,retrievedAt:time}));
  if(artifact.sources.length===0)artifact.warnings.push('לא התקבלו מקורות מחקר מאומתים; יש לבדוק את ההצעות ידנית.');
  await finish('ready',spent,'התכנון מוכן לבדיקה. טרם שונו נתוני הטיול.',artifact);
 }catch(e){
  const reason=e instanceof SyntaxError?'invalid_json':({'ערך לא תקין: סיכום':'invalid_summary','ערך לא תקין: הערה':'invalid_warning','אזהרות חסרות':'invalid_warnings','רשימת תכנון לא תקינה':'invalid_records','סוג רשומה אסור':'invalid_record_kind','תכנון אינו הזמנה מאושרת':'unsafe_booking_state','תכנון אינו פעולה שבוצעה':'unsafe_workflow_state','קישור לא תקין':'invalid_url','קישור אינו אתר ציבורי מאובטח':'unsafe_url'})[e.message]||(/מקור|מחקר/.test(e.message)?'source_mismatch':/מחיר|תקציב|cost|estimate/i.test(e.message)?'invalid_budget':/יום|ימי|משך|תאריך/.test(e.message)?'invalid_dates':/Invalid|Missing|Text too long|קואורדינטות/.test(e.message)?'invalid_record':'invalid_plan');
  await finish('needs_details',spent,'התכנון לא עבר אימות ['+reason+']. לא שונו נתוני הטיול.');
 }
}
const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':'https://talmalachi.github.io','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
const uuid=s=>typeof s==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);
export async function handlePlannerRequest(req,deps){const reply=(x,status=200)=>new Response(JSON.stringify(x),{status,headers});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});if(req.method!=='POST')return reply({error:'Method not allowed'},405);
 if(req.headers.get('origin')&&req.headers.get('origin')!=='https://talmalachi.github.io')return reply({error:'Origin not allowed'},403);
 try{
  const body=await req.text();if(body.length>16000)return reply({error:'Request too large'},413);const data=JSON.parse(body);
  if(data.action==='tick'){
   const token=req.headers.get('x-planner-worker');if(!token||!await deps.db('planner_worker_authorized',{p_token:token}))return reply({error:'Unauthorized'},401);
   if(data.inspectRunId){
    if(!uuid(data.inspectRunId))return reply({error:'Invalid run'},400);
    const job=await deps.db('planner_worker_inspect',{p_run:data.inspectRunId});
    if(!job?.call?.response_id)return reply({error:'Completed response unavailable'},404);
    job.run={...job.run,reserved_agorot:job.call.pricing?.boundAgorot||500};
    let result={state:'pending'};
    await processJob(job,{config:providerConfig(deps.env),provider:async(action,params)=>{if(action!=='retrieve')throw Error('Read-only inspection');return deps.provider(action,params)},db:async(name,p)=>{if(name==='planner_worker_progress')return true;if(name!=='planner_worker_finish')throw Error('Read-only inspection');result={state:p.p_state,message:p.p_message,records:p.p_artifact?.records?.length||0,sources:p.p_artifact?.sources?.length||0};return true;}});
    return reply(result);
   }
   const config=providerConfig(deps.env);await deps.db('planner_runtime_ready',{p_ready:Boolean(config),p_bound:config?.boundAgorot||500});
   const job=await deps.db('planner_worker_claim',{});await processJob(job,{db:deps.db,config,provider:deps.provider});return reply({ok:true});
  }
  const auth=req.headers.get('authorization');if(!auth||!await deps.authenticate(auth))return reply({error:'יש להתחבר מחדש'},401);
  if(!['overview','start','cancel','publish'].includes(data.action))return reply({error:'פעולה לא נתמכת'},400);
  const config=providerConfig(deps.env);
  if(['overview','start'].includes(data.action))await deps.db('planner_runtime_ready',{p_ready:Boolean(config),p_bound:config?.boundAgorot||500});
  if(data.action==='overview'){if(!uuid(data.tripId))return reply({error:'יעד לא תקין'},400);return reply(await deps.ownerDb(auth,'planner_overview',{p_trip:data.tripId}));}
  if(data.action==='start'){
   if(!config)return reply({error:'הסוכן עדיין אינו מחובר לספק AI עם תמחור מאומת. ההרצה חסומה.'},503);
   if(!uuid(data.tripId)||!uuid(data.key)||!Number.isSafeInteger(data.version))return reply({error:'נתוני יעד לא תקינים'},400);
   const input=validatePlanningInput(data.input);return reply(await deps.ownerDb(auth,'planner_start',{p_trip:data.tripId,p_version:data.version,p_input:input,p_key:data.key}));
  }
  if(!uuid(data.runId))return reply({error:'הרצה לא תקינה'},400);
  return reply(await deps.ownerDb(auth,data.action==='cancel'?'planner_cancel':'planner_publish',{p_run:data.runId,...(data.action==='publish'?{p_version:data.version}:{})}));
 }catch(e){const message=typeof e?.message==='string'&&(/תקציב|יתרה|היעד|התכנון|פריטי|הרצה|סוכן|נתונ|Version conflict/.test(e.message))?e.message:'לא ניתן להשלים את הפעולה. בדוק את הנתונים ונסה שוב.';return reply({error:message},400);}
}
export function createDependencies(env,fetcher=fetch){const url=env.SUPABASE_URL,secret=env.SUPABASE_SERVICE_ROLE_KEY;
 async function dbWith(auth,name,params){const r=await fetcher(url+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:secret,Authorization:auth,'Content-Type':'application/json'},body:JSON.stringify(params),signal:AbortSignal.timeout(20000)});const text=await r.text();const out=text.trim()?JSON.parse(text):null;if(!r.ok)throw Error(out?.message||'Database error');return out;}
 const db=(name,params)=>dbWith('Bearer '+secret,name,params);
 return {env,db,ownerDb:dbWith,authenticate:async auth=>{const r=await fetcher(url+'/auth/v1/user',{headers:{apikey:secret,Authorization:auth},signal:AbortSignal.timeout(10000)});return r.ok?await r.json():null;},provider:async(action,data)=>{
  if(!env.OPENAI_API_KEY)throw Error('Missing provider key');
  const path=action==='create'?'':('/'+encodeURIComponent(data.id)+(action==='cancel'?'/cancel':''));
  const r=await fetcher('https://api.openai.com/v1/responses'+path,{method:action==='retrieve'?'GET':'POST',headers:{Authorization:'Bearer '+env.OPENAI_API_KEY,'Content-Type':'application/json'},...(action==='create'?{body:JSON.stringify(data)}:{}),signal:AbortSignal.timeout(20000)});
  if(!r.ok)throw Error('Provider request failed');const out=await r.text();if(out.length>500000)throw Error('Provider response too large');return JSON.parse(out);
 }};
}

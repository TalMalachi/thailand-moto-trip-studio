const uuid=s=>typeof s==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
const site='https://talmalachi.github.io/motor-trip-studio/';
function safeUrl(value){const u=new URL(value);if(u.protocol!=='https:'||u.hostname!=='secure.cardcom.solutions'||u.port||u.username||u.password)throw Error('Invalid hosted card page');return u.href;}
export function verifyCardSetup(data,expected,config){const t=data?.TokenInfo;
 if(data?.ResponseCode!==0||data.TerminalNumber!==config.terminal||data.LowProfileId?.toLowerCase()!==expected.lowProfileId?.toLowerCase()||data.ReturnValue!==expected.setupId||data.Operation!=='CreateTokenOnly'||!uuid(t?.Token)||!Number.isInteger(t.CardMonth)||t.CardMonth<1||t.CardMonth>12||!Number.isInteger(t.CardYear)||t.CardYear<2026||t.CardYear>2200||!/^\d{8}$/.test(t.TokenExDate||''))throw Error('Card verification mismatch');
 const expires=t.TokenExDate.slice(0,4)+'-'+t.TokenExDate.slice(4,6)+'-'+t.TokenExDate.slice(6,8),date=new Date(expires+'T00:00:00Z');
 if(!Number.isFinite(date.valueOf())||date.toISOString().slice(0,10)!==expires||expires<new Date().toISOString().slice(0,10)||Date.UTC(t.CardYear,t.CardMonth,1)<=Date.now())throw Error('Expired card reference');
 if(data.TranzactionInfo&&(String(data.TranzactionInfo.JParameter)!=='2'||![0,700].includes(data.TranzactionInfo.ResponseCode)))throw Error('Expected J2 validation only');
 const last4=data.TranzactionInfo?.Last4CardDigitsString;return {token:t.Token,month:t.CardMonth,year:t.CardYear,expires,last4:typeof last4==='string'&&/^\d{4}$/.test(last4)?last4:null};
}
export async function handleCardSetup({req,data,url,config,deps,reply,action}){
 if(deps.env.CARD_STORAGE_ENABLED!=='true')return reply({error:'הוספת כרטיס עדיין אינה זמינה: חיבור ספק הסליקה לשמירת כרטיסים טרם הושלם.'},503);
 const webhook=action==='cardWebhook';let user=null;
 if(!webhook){if(req.method!=='POST')return reply({error:'Method not allowed'},405);const auth=req.headers.get('authorization');user=auth?await deps.authenticate(auth):null;if(!user?.id)return reply({error:'יש להתחבר מחדש'},401);}
 if(webhook||action==='reconcileCard'){
 const fields=Object.fromEntries([...url.searchParams,...Object.entries(data)].map(([k,v])=>[k.toLowerCase(),v]));
 const setupId=webhook?fields.returnvalue:data.setupId,lowProfile=webhook?fields.lowprofileid:null;
 if(!uuid(setupId)||webhook&&!uuid(lowProfile))return reply({error:'Invalid setup'},400);
 const claim=await deps.db('card_claim',{p_setup:setupId,p_low_profile:lowProfile,p_user:user?.id||null});if(!claim)return reply({error:'Unknown setup'},404);if(claim.completed)return reply({completed:true});if(claim.busy)return reply({pending:true},webhook?409:200);
 const result=await deps.provider('GetLpResult',{TerminalNumber:config.terminal,ApiName:config.apiName,LowProfileId:claim.lowProfileId});
 if(!webhook&&result.ResponseCode!==0)return reply({pending:true});const verified=verifyCardSetup(result,claim,config);
 return reply(await deps.db('card_confirm',{p_setup:setupId,p_fence:claim.fence,p_low_profile:claim.lowProfileId,p_token:verified.token,p_terminal:config.terminal,p_last4:verified.last4,p_month:verified.month,p_year:verified.year,p_expires:verified.expires}));
 }
 if(action!=='addCard'||data.consentVersion!=='store-card-only-v1')return reply({error:'Invalid card setup'},400);
 const prepared=await deps.db('card_prepare',{p_user:user.id,p_consent:data.consentVersion});if(!prepared.new)return reply({setupId:prepared.setupId,url:safeUrl(prepared.url)});
 try{
 const result=await deps.provider('Create',{TerminalNumber:config.terminal,ApiName:config.apiName,Operation:'CreateTokenOnly',Amount:1,ISOCoinId:1,Language:'he',ReturnValue:prepared.setupId,ProductName:'שמירת כרטיס בלבד — ללא רכישת חבילה',SuccessRedirectUrl:site+'?card_setup_return='+prepared.setupId,FailedRedirectUrl:site+'?card_setup_return='+prepared.setupId,WebHookUrl:deps.env.SUPABASE_URL+'/functions/v1/trip-billing?action=cardWebhook',AdvancedDefinition:{JValidateType:2,MinNumOfPayments:1,MaxNumOfPayments:1},UIDefinition:{IsHideCardOwnerIdentityNumber:true}});
 if(result.ResponseCode!==0||!uuid(result.LowProfileId))throw Error('Card page rejected');const hosted=safeUrl(result.Url);await deps.db('card_page',{p_setup:prepared.setupId,p_low_profile:result.LowProfileId,p_url:hosted});return reply({setupId:prepared.setupId,url:hosted});
 }catch{await deps.db('card_attention',{p_setup:prepared.setupId});throw Error('Card setup could not be confirmed');}
}

import {createClient} from '@supabase/supabase-js';
const origin='https://talmalachi.github.io',redirect=origin+'/motor-trip-studio/?mode=admin';
const headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS'};
const denied={error:'שם המשתמש או הסיסמה שגויים, החשבון אינו פעיל או שיש להמתין לפני ניסיון נוסף'};
export async function handleAdminAuth(req,deps){const reply=(data,status=200)=>new Response(JSON.stringify(data),{status,headers});if(req.method==='OPTIONS')return new Response(null,{status:204,headers});if(req.method!=='POST')return reply({error:'Method not allowed'},405);if(req.headers.get('origin')&&req.headers.get('origin')!==origin)return reply({error:'Origin not allowed'},403);
 let action;try{const text=await req.text();if(text.length>2048)return reply(denied,400);const body=JSON.parse(text);action=body.action;
 if(!['signin','reset'].includes(action)||typeof body.username!=='string'||body.username.length>50||action==='signin'&&(typeof body.password!=='string'||!body.password||body.password.length>512))return reply(denied,400);
 const caller=await deps.callerKey(req);if(!caller)return action==='reset'?reply({ok:true}):reply(denied,401);
 const target=await deps.target(body.username.trim().toLowerCase(),action,caller);
 if(action==='reset'){if(target)await deps.reset(target.email);return reply({ok:true});}
 if(!target)return reply(denied,401);
 const result=await deps.signIn(target.email,body.password);if(result.error||result.data?.user?.id!==target.userId||!result.data?.session?.access_token||!result.data?.session?.refresh_token)return reply(denied,401);
 return reply({access_token:result.data.session.access_token,refresh_token:result.data.session.refresh_token});
 }catch{return action==='reset'?reply({ok:true}):reply(denied,401);}}
export function createAdminAuthDependencies(env,fetcher=fetch){const url=env.SUPABASE_URL,service=env.SUPABASE_SERVICE_ROLE_KEY,key=env.SUPABASE_ANON_KEY||service;
 const safeFetch=(input,init={})=>fetcher(input,{...init,signal:AbortSignal.timeout(15000)});
 const authClient=()=>createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:safeFetch}});
 return {callerKey:async req=>{const raw=req.headers.get('cf-connecting-ip');if(!raw||raw.length>45)return null;let address;if(raw.includes(':')){try{address=new URL('http://['+raw+']/').hostname}catch{return null}}else{const parts=raw.split('.');if(parts.length!==4||parts.some(x=>!/^\d{1,3}$/.test(x)||Number(x)>255))return null;address=parts.map(Number).join('.')}const encoder=new TextEncoder(),key=await crypto.subtle.importKey('raw',encoder.encode(service),{name:'HMAC',hash:'SHA-256'},false,['sign']);return [...new Uint8Array(await crypto.subtle.sign('HMAC',key,encoder.encode(address)))].map(x=>x.toString(16).padStart(2,'0')).join('');},target:async(username,action,caller)=>{const r=await safeFetch(url+'/rest/v1/rpc/admin_auth_target',{method:'POST',headers:{apikey:service,Authorization:'Bearer '+service,'Content-Type':'application/json'},body:JSON.stringify({p_username:username,p_action:action,p_client_key:caller})});if(!r.ok)throw Error('Admin authentication unavailable');return r.json();},signIn:(email,password)=>authClient().auth.signInWithPassword({email,password}),reset:email=>authClient().auth.resetPasswordForEmail(email,{redirectTo:redirect})};}
